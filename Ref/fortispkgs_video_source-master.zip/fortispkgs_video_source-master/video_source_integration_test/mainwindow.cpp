#include <QtGui>
#include <QMessageBox>
#include <QMainWindow>
#include <QCoreApplication>
#include <QJsonArray>
#include <QThread>
#include <QFile>
#include <QList>
#include <QStandardPaths>
#include <QTime>
#include <QSharedPointer>
#include <QMetaType>
#include <QtPlugin>
#include <QDebug>
#include <QImage>
#include <QSharedMemory>
#include <QException>
#include <QCameraInfo>
#include <QCommandLineParser>
#include <QMetaEnum>
#include <QElapsedTimer>
#include <QScopedPointer>

#include <iostream>
#include <fstream>
#include <thread>
#include <memory>

#include "ui_mainwindow.h"

#include "videopipeline.h"

#include "nizzaexception.h"
#include "invalidconfigurationexception.h"
#include "invalidoperationexception.h"

#include "private/sourcepipeline_p.h"
#include "mainwindow.h"

#include <windows.h>

using namespace video::source;
using namespace video::source::test;

using namespace std;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_videoPipeline(new VideoPipeline)
    , m_selectedSourceIndex(0)
    , m_useOpenGLRendering(false)
{
    ui->setupUi(this);
    ui->sourceTabWidget->removeTab(1);
}

bool MainWindow::configure()
{
    QCommandLineParser parser;
    QString errorMessage;

    switch (parseCommandLine(parser, &errorMessage))
    {
    case CommandLineError:
        fputs(qPrintable(errorMessage), stderr);
        fputs("\n\n", stderr);
        fputs(qPrintable(errorMessage), stderr);

        QApplication::exit(1);
        return false;
    case CommandLineHelpRequested:
    {
        fputs(qPrintable(parser.helpText()), stdout);
        fputs("Available sources: ", stdout);

        auto metaEnum = QMetaEnum::fromType<SourcePipeline::SourcePipelineType>();
        for (int i=0; i < metaEnum.keyCount(); i++)
        {
            fputs(qPrintable(metaEnum.key(i)), stdout);
            fputs(" ", stdout);
        }

        fputs("\nAvailable backends: ", stdout);

        metaEnum = QMetaEnum::fromType<SourcePipelineConfig::Backend>();
        for (int i=0; i < metaEnum.keyCount(); i++)
        {
            fputs(qPrintable(metaEnum.key(i)), stdout);
            fputs(" ", stdout);
        }

        fputs("\n\n", stdout);

        QApplication::exit(0);
        return false;
    }
    case CommandLineOk:
        break;
    }

    if (m_videoPipeline->sources().count() == 0)
    {
        m_videoPipeline->addKnownSource(SourcePipeline::DownwardFacingCamera);
    }

    auto config = m_videoPipeline->outputSinkConfiguration();

    for (int i = 0; i < m_videoPipeline->sources().count(); i++)
    {
        m_previousZoomFactor.insert(i, 0);
        m_previousZoomFactor.insert(i, 0);

        if (i >= ui->sourceTabWidget->count())
        {
            auto widget = new VideoSourceWidget(this);
            ui->sourceTabWidget->addTab(widget, QString("Source %1").arg(i));
            connectTabToSource(widget, i);
        }
        else
        {
            connectTabToSource(ui->tab, i);
        }
    }

    connect(m_videoPipeline.data(), &VideoPipeline::stateChanged, this, &MainWindow::onVideoPipelineStateChanged);

    try
    {
        m_videoPipeline->start();

        qInfo() << "videoSource.success()";
    }
    catch (std::exception& ex)
    {
        qCritical() << "videoSource failed to start" << ex.what();
    }

    return true;
}

void MainWindow::onVideoPipelineStateChanged(VideoPipeline::VideoPipelineState state)
{
    qDebug() << "Video pipeline state changed to" << state;

    if (state == VideoPipeline::VideoPipelineState::Running)
    {
        if (!m_useOpenGLRendering) {
            auto cameraList = QCameraInfo::availableCameras();
            auto config = m_videoPipeline->outputSinkConfiguration();

            foreach (const QCameraInfo &cameraInfo, cameraList) {
                qInfo() << "Name: " << cameraInfo.description();

                if(cameraInfo.description() == config.name)
                {
                    qInfo() << "Setting viewfinder";

                    m_camera.swap(QScopedPointer<QCamera>(new QCamera(cameraInfo)));

                    m_camera->setViewfinder(ui->cameraViewFinder);
                    m_camera->start();                    

                    break;
                }
            }

        } else {
            for (auto source : m_videoPipeline->sources()) {
                ui->openGLWidget->connectToSource(source);
            }
        }
    } else if (state == VideoPipeline::VideoPipelineState::Stopping) {
        ui->openGLWidget->reset();
    }
}

MainWindow::CommandLineParseResult MainWindow::parseCommandLine(QCommandLineParser &parser, QString *errorMessage)
{
    parser.setApplicationDescription("Integration test of video_source package");
    const auto helpOption = parser.addHelpOption();

    QCommandLineOption centerOption(QStringList() << "c" << "center",
                                    "Source that should be displayed in center. Default value - DownwardFacingCamera", "source");
    parser.addOption(centerOption);

    QCommandLineOption topLeftOption(QStringList() << "tl" << "top-left",
                                     "Source that should be displayed in top-left corner.", "source");
    parser.addOption(topLeftOption);

    QCommandLineOption topRightOption(QStringList() << "tr" << "top-right",
                                      "Source that should be displayed in top-right corner.", "source");
    parser.addOption(topRightOption);

    QCommandLineOption bottomLeftOption(QStringList() << "bl" << "bottom-left",
                                        "Source that should be displayed in bottom-left corner.", "source");
    parser.addOption(bottomLeftOption);

    QCommandLineOption bottomRightOption(QStringList() << "br" << "bottom-right",
                                         "Source that should be displayed in bottom-right corner.", "source");
    parser.addOption(bottomRightOption);

    QCommandLineOption monitorOption(QStringList() << "m" << "monitor",
                                     "Defines Nizza monitor window size", "window_size");
    parser.addOption(monitorOption);

    QCommandLineOption grabFramesOption(QStringList() << "f" << "frames-per-second",
                                        "Allows frame grabbing to provide FPS");

    parser.addOption(grabFramesOption);

    QCommandLineOption compositorOption(QStringList() << "cs" << "compositor-size",
                                        "Defines compositor size", "window_size");

    parser.addOption(compositorOption);

    QCommandLineOption resolutionOption(QStringList() << "r" << "resolution",
                                        "Defines input source resolution", "resolution");

    parser.addOption(resolutionOption);

    QCommandLineOption rendererOption(QStringList() << "or" << "output-renderer",
                                      "Defines output frame renderer; options: DirectShow, OpenGL", "DirectShow");

    parser.addOption(rendererOption);

    QCommandLineOption backendOption(QStringList() << "b" << "backend",
                                     "Defines backend that should be used for pipeline. Default: IntelIPP", "backend");

    parser.addOption(backendOption);

    bool addFrameGrabber = false;
    SourcePipelineConfig::Backend backend = SourcePipelineConfig::Backend::IntelIPP;
    QSize resolution;

    if (!parser.parse(QCoreApplication::arguments())) {
        *errorMessage = parser.errorText();
        return CommandLineError;
    }

    if (parser.isSet(helpOption))
    {
        return CommandLineHelpRequested;
    }

    if (parser.isSet(monitorOption))
    {
        auto config = m_videoPipeline->outputSinkConfiguration();
        const auto parameter = parser.value(monitorOption);

        QRegExp regex("^(\\d+)x(\\d+)$");
        if (!regex.exactMatch(parameter))
        {
            *errorMessage = "Invalid window size: " + parameter + "expected size in format hxw, e.g. 800x600";
        }
        else
        {
            config.monitorWindowSize = QSize(regex.cap(1).toInt(), regex.cap(2).toInt());
            m_videoPipeline->setOutputSinkConfiguration(config);
        }
    }

    if (parser.isSet(compositorOption))
    {
        auto config = m_videoPipeline->outputSinkConfiguration();
        const auto parameter = parser.value(compositorOption);

        QRegExp regex("^(\\d+)x(\\d+)$");
        if (!regex.exactMatch(parameter))
        {
            *errorMessage = "Invalid compositor size: " + parameter + "expected size in format hxw, e.g. 800x600";
        }
        else
        {
            config.size = QSize(regex.cap(1).toInt(), regex.cap(2).toInt());
            m_videoPipeline->setOutputSinkConfiguration(config);
        }
    }

    if (parser.isSet(grabFramesOption))
    {
        addFrameGrabber = true;
    }

    if (parser.isSet(rendererOption)) {
        m_useOpenGLRendering = parser.value(rendererOption) == "OpenGL";
    }

    if (parser.isSet(backendOption)) {
        auto metaEnum = QMetaEnum::fromType<SourcePipelineConfig::Backend>();
        const auto parameter = parser.value(backendOption);
        bool ok;

        auto value = static_cast<SourcePipelineConfig::Backend>(metaEnum.keyToValue(parameter.toStdString().c_str(), &ok));

        if (!ok)
        {
            *errorMessage = "Invalid backend name: " + parameter;
        }
        else
        {
            backend = value;
        }
    }

    if (parser.isSet(resolutionOption))
    {
        const auto parameter = parser.value(resolutionOption);

        QRegExp regex("^(\\d+)x(\\d+)$");
        if (!regex.exactMatch(parameter))
        {
            *errorMessage = "Invalid resolution size: " + parameter + "expected size in format hxw, e.g. 800x600";
        }
        else
        {
            resolution = QSize(regex.cap(1).toInt(), regex.cap(2).toInt());
        }
    }

    addSourceFromCommandLineOption(parser, centerOption, errorMessage, QRectF(0, 0, 1, 1), addFrameGrabber, backend, resolution);
    if (!errorMessage->isEmpty())
    {
        return CommandLineError;
    }

    addSourceFromCommandLineOption(parser, topLeftOption, errorMessage, QRectF(0.05f, 0.55f, 0.40f, 0.40f), addFrameGrabber, backend, resolution);
    if (!errorMessage->isEmpty())
    {
        return CommandLineError;
    }

    addSourceFromCommandLineOption(parser, topRightOption, errorMessage, QRectF(0.55f, 0.55f, 0.40f, 0.40f), addFrameGrabber, backend, resolution);
    if (!errorMessage->isEmpty())
    {
        return CommandLineError;
    }

    addSourceFromCommandLineOption(parser, bottomLeftOption, errorMessage, QRectF(0.05f, 0.05f, 0.40f, 0.40f), addFrameGrabber, backend, resolution);
    if (!errorMessage->isEmpty())
    {
        return CommandLineError;
    }

    addSourceFromCommandLineOption(parser, bottomRightOption, errorMessage, QRectF(0.55f, 0.05f, 0.40f, 0.40f), addFrameGrabber, backend, resolution);
    if (!errorMessage->isEmpty())
    {
        return CommandLineError;
    }

    ui->cameraViewFinder->setVisible(!m_useOpenGLRendering);
    ui->openGLWidget->setVisible(m_useOpenGLRendering);

    return CommandLineOk;
}

void MainWindow::addSourceFromCommandLineOption(QCommandLineParser &parser,
                                                QCommandLineOption option,
                                                QString *errorMessage,
                                                QRectF destinationRectangle,
                                                bool addFrameGrabber,
                                                SourcePipelineConfig::Backend backend,
                                                QSize resolution)
{
    auto metaEnum = QMetaEnum::fromType<SourcePipeline::SourcePipelineType>();
    bool ok;

    if (parser.isSet(option))
    {
        const auto parameter = parser.value(option);
        auto value = static_cast<SourcePipeline::SourcePipelineType>(metaEnum.keyToValue(parameter.toStdString().c_str(), &ok));

        if (!ok)
        {
            *errorMessage = "Invalid source name: " + parameter + " for option " + option.valueName();
        }
        else
        {
            auto source = m_videoPipeline->addKnownSource(value, resolution);

            auto config = source->configuration();
            config.frameGrabber.included = addFrameGrabber;
            config.backend = backend;
            source->setConfiguration(config);

            m_buffer = std::vector<uchar>(config.inputVideoSource.size.width() * config.inputVideoSource.size.height() * 3);

            source->setFrameGrabberBuffer(m_buffer.data());

            source->setDestinationRectangle(destinationRectangle);

            if (addFrameGrabber) {
                connect(source.data(), &SourcePipeline::frameBufferReady, this, &MainWindow::onFrameBufferReady);
            }
        }
    }
}

void MainWindow::connectTabToSource(VideoSourceWidget* widget, int index)
{
    auto source = m_videoPipeline->sources().at(index);

    widget->setIsAutoWhiteBalanceIncluded(source->configuration().autoWhiteBalance.included || source->configuration().illuminationCorrection.included);
    widget->setIsIlluminationCorrectionIncluded(source->configuration().illuminationCorrection.included);
    widget->setColorCorrectionLampIncluded(source->configuration().colorCorrection.included);

    connect(m_videoPipeline.data(), &VideoPipeline::stateChanged, [this, source, widget](VideoPipeline::VideoPipelineState state) {
        if (state == VideoPipeline::VideoPipelineState::Running)
        {
            if (source->autoWhiteBalance())
            {
                widget->setIsAutoWhiteBalanceEnabled(source->autoWhiteBalance()->enabled());
            }
            else if (source->illuminationCorrection())
            {
                widget->setIsAutoWhiteBalanceEnabled(source->illuminationCorrection()->autoWhiteBalance());
            }

            if (source->illuminationCorrection())
            {
                widget->setIsIlluminationCorrectionEnabled(source->illuminationCorrection()->enabled());
            }
        }
    });

    connect(widget, &VideoSourceWidget::isIlluminationCorrectionEnabledChanged, [this, source](bool isEnabled) {
        if (source->illuminationCorrection())
        {
            source->illuminationCorrection()->setEnabled(isEnabled);
        }
        else
        {
            qWarning() << "Illumination correction filter is not in graph";
        }
    });

    connect(widget, &VideoSourceWidget::isAutoWhiteBalanceEnabledChanged, [this, source](bool isEnabled) {
        if (source->autoWhiteBalance())
        {
            source->autoWhiteBalance()->setEnabled(isEnabled);
        }
        else if (source->illuminationCorrection())
        {
            source->illuminationCorrection()->setAutoWhiteBalance(isEnabled);
        }
        else
        {
            qWarning() << "Auto white balance correction filter is not in graph";
        }
    });

    connect(widget, &VideoSourceWidget::colorCorrectionLampChanged, [this, source](bool isEnabled) {
        if (source->colorCorrection())
        {
            source->colorCorrection()->setMode(isEnabled ? ColorCorrectionFilter::LampOn : ColorCorrectionFilter::LampOff);
        }
        else
        {
            qWarning() << "Color correction filter is not in graph";
        }
    });

    connect(widget, &VideoSourceWidget::isEnabledChanged, [this, source](bool enabled){
        source->setEnabled(enabled);
    });

    connect(widget, &VideoSourceWidget::zoomChanged, [this, source](float factor){
        auto viewport = source->viewport();
        float x1 = viewport.left(), x2 = viewport.right(), y1 = viewport.top(), y2 = viewport.bottom();

        x1 = (x1 + factor <= 0.0f) ? 0.0f : (x1 + factor);
        y1 = (y1 + factor <= 0.0f) ? 0.0f : (y1 + factor);
        x2 = (x2 - factor >= 1.0f) ? 1.0f : (x2 - factor);
        y2 = (y2 - factor >= 1.0f) ? 1.0f : (y2 - factor);

        source->setViewport(QRectF (x1, y1, x2 - x1, y2 - y1));
    });

    connect(widget, &VideoSourceWidget::panChanged, [this, source](int vertical, int horizontal){
        const int tStep = 5;
        auto moveX = (horizontal * tStep) / 100.0;
        auto moveY = (vertical * tStep) / 100.0;
        auto viewport = source->viewport();

        float x1 = viewport.left(), x2 = viewport.right(), y1 = viewport.top(), y2 = viewport.bottom();

        x1 += moveX;
        x2 += moveX;

        if ( x1 < 0 )
        {
            double deltaX = abs(x1);
            x1 += deltaX;
            x2 += deltaX;
        }
        if ( x2 > 1.0 )
        {
            double deltaX = abs(x2 - 1.0);
            x1 -= deltaX;
            x2 -= deltaX;
        }

        y1 += moveY;
        y2 += moveY;
        if ( y1 < 0 )
        {
            double deltaY = abs(y1);
            y1 += deltaY;
            y2 += deltaY;
        }
        if ( y2 > 1.0 )
        {
            double deltaY = abs(y2 - 1.0);
            y1 -= deltaY;
            y2 -= deltaY;
        }

        source->setViewport(QRectF(x1, y1, x2 - x1, y2 - y1));
    });

    connect(widget, &VideoSourceWidget::resizeChanged, [this, source](int vertical, int horizontal){
        const int tStep = 5;
        auto moveX = (vertical * tStep) / 100.0;
        auto moveY = (horizontal * tStep) / 100.0;
        auto destination = source->destinationRectangle();

        float x1 = destination.left(), x2 = destination.right(), y1 = destination.top(), y2 = destination.bottom();
        x1 -= moveX;
        y1 -= moveY;

        x1 = qBound(0.0f, x1, 1.0f);
        x2 = qBound(0.0f, x2, 1.0f);
        y1 = qBound(0.0f, y1, 1.0f);
        y2 = qBound(0.0f, y2, 1.0f);

        source->setDestinationRectangle(QRectF(x1, y1, x2 - x1, y2 - y1));
    });

    connect(widget, &VideoSourceWidget::moveChanged, [this, source](int vertical, int horizontal){
        const int tStep = 5;
        auto moveX = (horizontal * tStep) / 100.0;
        auto moveY = (vertical * tStep) / 100.0;
        auto destination = source->destinationRectangle();

        float x1 = destination.left(), x2 = destination.right(), y1 = destination.top(), y2 = destination.bottom();
        x1 += moveX;
        x2 += moveX;

        y1 += moveY;
        y2 += moveY;

        x1 = qBound(0.0f, x1, 1.0f);
        x2 = qBound(0.0f, x2, 1.0f);
        y1 = qBound(0.0f, y1, 1.0f);
        y2 = qBound(0.0f, y2, 1.0f);

        source->setDestinationRectangle(QRectF(x1, y1, x2 - x1, y2 - y1));
    });
}

void MainWindow::captureFrameReleased()
{
    ::OutputDebugStringA(__FUNCTION__ " saveFrame");

    QElapsedTimer timer;
    timer.start();

    auto results = m_videoPipeline->capture();

    qInfo() << "Capture took" << timer.elapsed() << "ms";

    for (auto sensorData : results)
    {
        QJsonDocument doc(sensorData.metadata);
        qDebug() << doc.toJson(QJsonDocument::Indented);


        auto outputFile = QString("./img_%1_%2.raw").arg(sensorData.metadata["name"].toString()).arg(rand());
        QFile f(outputFile);
        if (f.open(QIODevice::WriteOnly))
        {
            f.write((const char*)sensorData.image.bits(), sensorData.image.byteCount());
        }

        srand(time(nullptr));

        outputFile = QString("./img_%1_%2.jpg").arg(sensorData.metadata["name"].toString()).arg(rand());
        sensorData.image.save(outputFile);
    }
}

void MainWindow::captureStillFrameReleased()
{
    ::OutputDebugStringA(__FUNCTION__ " captureStillFrame");

    QElapsedTimer timer;
    timer.start();

    try
    {
        auto results = m_videoPipeline->capture( { m_videoPipeline->sources()[0]->name() } );

        qInfo() << "Capture took" << timer.elapsed() << "ms";

        for (auto sensorData : results)
        {
            QJsonDocument doc(sensorData.metadata);
            qDebug() << doc.toJson(QJsonDocument::Indented);


            auto outputFile = QString("./img_still_%1_%2.raw").arg(sensorData.metadata["name"].toString()).arg(rand());
            QFile f(outputFile);
            if (f.open(QIODevice::WriteOnly))
            {
                f.write((const char*)sensorData.image.bits(), sensorData.image.byteCount());
            }

            srand(time(nullptr));

            outputFile = QString("./img_still_%1_%2.jpg").arg(sensorData.metadata["name"].toString()).arg(rand());
            sensorData.image.save(outputFile);
        }
    }
    catch(std::exception &ex)
    {
        QMessageBox::critical(this, QString(typeid(ex).name()), QString::fromStdString(ex.what()));
    }
}

void MainWindow::startPipelineReleased()
{
    try
    {
        m_videoPipeline->start();
    }
    catch (const std::exception& ex)
    {
        QMessageBox::critical(this, QString(typeid(ex).name()), QString::fromStdString(ex.what()));
    }
}

void MainWindow::stopPipelineReleased()
{
    try
    {
        m_camera.reset();

        m_videoPipeline->stop();
    }
    catch (const std::exception& ex)
    {
        QMessageBox::critical(this, QString(typeid(ex).name()), QString::fromStdString(ex.what()));
    }
}

MainWindow::~MainWindow()
{
    m_camera.reset();

    if (m_videoPipeline)
    {
        m_videoPipeline->stop();
    }
}

void MainWindow::onFrameBufferReady(int sourceIndex, const QSize size, int dataSize)
{
    Q_UNUSED(dataSize)

    if (!m_fpsTimer.contains(sourceIndex))
    {
        m_fpsTimer.insert(sourceIndex, QElapsedTimer());
        m_frames.insert(sourceIndex, 0);

        m_fpsTimer[sourceIndex].start();
    }

    if (m_fpsTimer[sourceIndex].elapsed() > 1000)
    {
        qInfo() << "FPS:" << sourceIndex << m_frames[sourceIndex] << size;

        m_fpsTimer[sourceIndex].restart();
        m_frames[sourceIndex] = 0;
    }

    m_frames[sourceIndex]++;
}
