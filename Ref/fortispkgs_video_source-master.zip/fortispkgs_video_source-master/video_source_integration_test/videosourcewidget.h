#ifndef VIDEOSOURCEWIDGET_H
#define VIDEOSOURCEWIDGET_H

#include <QWidget>

namespace Ui {
class VideoSourceWidget;
}

namespace video {
namespace source {
namespace test {

class VideoSourceWidget : public QWidget
{
    Q_OBJECT

public:
    explicit VideoSourceWidget(QWidget *parent = 0);
    ~VideoSourceWidget();

signals:
    void zoomChanged(float zoom);
    void panChanged(int vertical, int horizontal);
    void moveChanged(int vertical, int horizontal);
    void resizeChanged(int vertical, int horizontal);
    void isEnabledChanged(bool isEnabled);
    void isIlluminationCorrectionEnabledChanged(bool isEnabled);
    void isAutoWhiteBalanceEnabledChanged(bool isEnabled);
    void colorCorrectionLampChanged(bool isEnabled);

public slots:

    void setIsIlluminationCorrectionEnabled(bool isEnabled);
    void setIsIlluminationCorrectionIncluded(bool isIncluded);

    void setIsAutoWhiteBalanceEnabled(bool isEnabled);
    void setIsAutoWhiteBalanceIncluded(bool isIncluded);

    void setColorCorrectionLampEnabled(bool isEnabled);
    void setColorCorrectionLampIncluded(bool isIncluded);

private:
    Ui::VideoSourceWidget *ui;
    int lastZoomValue;


private slots:
    void isEnabledToggled(bool isEnabled);
    void zoomValueChanged(int value);

    void panUpReleased();
    void panDownReleased();
    void panLeftReleased();
    void panRightReleased();

    void moveUpReleased();
    void moveDownReleased();
    void moveLeftReleased();
    void moveRightReleased();

    void resizeShorterReleased();
    void resizeTallerReleased();
    void resizeWiderReleased();
    void resizeNarrowerReleased();

    void illuminationCorrectionToggled(bool isEnabled);
    void autoWhiteBalanceToggled(bool isEnabled);
    void colorCorrectionLampToggled(bool isEnabled);
};

} // test
} // source
} // video

#endif // VIDEOSOURCEWIDGET_H
