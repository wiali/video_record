#include <QApplication>
#include <QTimer>
#include <QException>
#include <QDebug>
#include "mainwindow.h"

using namespace video::source::test;

int main(int argc, char *argv[])
{
    try
    {
        QApplication app(argc, argv);
        QApplication::setApplicationName("video_source_integration_test");

        // create the main class
        MainWindow myMain;
        int result = 0;

        if (myMain.configure())
        {
            myMain.show();
            result = app.exec();
        }
        else
        {
            app.exit(0);
        }

        return result;
    }
    catch (const std::exception& ex)
    {
        qCritical() << "Catched" << typeid(ex).name() << ":" << ex.what();
    }
    catch (const std::string& ex)
    {
        qCritical() << "Catched std::string:" << QString::fromStdString(ex);
    }
    catch (...)
    {
        qCritical() << "Catched unknown exception";
    }
}

