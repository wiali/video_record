#ifndef MAINCLASS_H
#define MAINCLASS_H

#include <QObject>
#include <QMainWindow>
#include <QCoreApplication>
#include <QPointer>
#include <QCamera>
#include <QCommandLineParser>
#include <QElapsedTimer>

#include "videopipeline.h"
#include "videosourcewidget.h"

namespace Ui { class MainWindow; }

namespace video {
namespace source {
namespace test {

class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    QCoreApplication *app;

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    bool configure();

private slots:
    void onFrameBufferReady(int sourceIndex, const QSize size, int dataSize);
    void onVideoPipelineStateChanged(video::source::VideoPipeline::VideoPipelineState state);
    void captureFrameReleased();
    void startPipelineReleased();
    void stopPipelineReleased();
    void captureStillFrameReleased();

protected:

    enum CommandLineParseResult
    {
        CommandLineOk,
        CommandLineError,
        CommandLineVersionRequested,
        CommandLineHelpRequested
    };

    QSharedPointer<VideoPipeline> m_videoPipeline;

    QHash<int, int> m_previousZoomFactor;
    QHash<int, int> m_zoomFactor;
    std::vector<uchar> m_buffer;

    int m_selectedSourceIndex;

    Ui::MainWindow *ui;
    QScopedPointer<QCamera> m_camera;
    QHash<int, QElapsedTimer> m_fpsTimer;
    QHash<int, int> m_frames;
    bool m_useOpenGLRendering;

    void connectTabToSource(VideoSourceWidget* widget, int index);

    CommandLineParseResult parseCommandLine(QCommandLineParser &parser, QString *errorMessage);
    void addSourceFromCommandLineOption(QCommandLineParser &parser, QCommandLineOption option, QString *errorMessage, QRectF destinationRectangle, bool addFrameGrabber, SourcePipelineConfig::Backend backend, QSize resolution);
};

} // test
} // source
} // video

#endif // MAINCLASS_H
