#ifndef OPENGLRENDERWIDGET_H
#define OPENGLRENDERWIDGET_H

#include <QObject>
#include <QOpenGLWidget>
#include <QOpenGLTexture>
#include <QOpenGLShaderProgram>
#include <QOpenGLBuffer>
#include <QVideoFrame>
#include <QOpenGLFramebufferObject>
#include <QOpenGLVertexArrayObject>

#include <video_source/sourcepipeline.h>

class OpenGlRenderWidget : public QOpenGLWidget
{
    Q_OBJECT
public:
    explicit OpenGlRenderWidget(QWidget *parent = 0);

    void connectToSource(QSharedPointer<video::source::SourcePipeline> pipeline);
    void reset();

protected:

    virtual void resizeGL(int w, int h) override;
    virtual void paintGL() override;

private:

    QSharedPointer<QOpenGLFramebufferObject> m_frameBuffer;
    QSharedPointer<video::source::SourcePipeline> m_pipeline;

    QSize m_frameSize;
    bool m_frameReadyForUpdate;
    QMetaObject::Connection m_sourceConnection;

private slots:

    void updateFrame(int sourceIndex, const QSize& size);
};

#endif // OPENGLRENDERWIDGET_H
