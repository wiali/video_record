#include <QOpenGLContext>
#include <QOpenGLFunctions>
#include <QTimer>

#include "openglrenderwidget.h"

OpenGlRenderWidget::OpenGlRenderWidget(QWidget *parent)
    : QOpenGLWidget(parent)
    , m_frameReadyForUpdate(false)
{
}

void OpenGlRenderWidget::resizeGL(int width, int height)
{
    auto f = QOpenGLContext::currentContext()->functions();

    int side = qMin(width, height);
    f->glViewport((width - side) / 2, (height - side) / 2, side, side);

    QOpenGLWidget::resizeGL(width, height);
}

void OpenGlRenderWidget::updateFrame(int sourceIndex, const QSize &size) {
    Q_UNUSED(sourceIndex);
    if (m_pipeline) {
        m_frameSize = size;
        m_frameReadyForUpdate = true;
        update();
    }
}

void OpenGlRenderWidget::connectToSource(QSharedPointer<video::source::SourcePipeline> pipeline) {
    m_pipeline = pipeline;
    m_sourceConnection = connect(pipeline->combinedOpenGLFilter(), &video::source::CombinedOpenGLFilter::frameReady, this, &OpenGlRenderWidget::updateFrame);
}

void OpenGlRenderWidget::reset() {
    m_pipeline.reset();
    m_frameReadyForUpdate = false;
    disconnect(m_sourceConnection);

    m_frameSize = QSize();
    m_frameBuffer.reset();
}

void OpenGlRenderWidget::paintGL()
{
    auto f = QOpenGLContext::currentContext()->functions();

    if (m_frameSize.isValid() && !m_frameBuffer) {
        qDebug() << "Creating framebuffer" << m_frameSize;

        QOpenGLFramebufferObjectFormat format;
        format.setInternalTextureFormat(QOpenGLTexture::RGB);

        m_frameBuffer.reset(new QOpenGLFramebufferObject(m_frameSize, format));
    }

    if (m_frameBuffer && m_frameReadyForUpdate && m_pipeline) {
        m_pipeline->combinedOpenGLFilter()->convert(m_frameBuffer.data());
        m_frameReadyForUpdate = false;
    }

    f->glClearColor(0, 1, 1, 1);
    f->glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Blit to target framebuffer with inverted Y axis
    QOpenGLFramebufferObject::blitFramebuffer(0, QRect(0, 0, width(), height()),
                                              m_frameBuffer.data(), QRect(0, m_frameSize.height(), m_frameSize.width(), -m_frameSize.height()));
}
