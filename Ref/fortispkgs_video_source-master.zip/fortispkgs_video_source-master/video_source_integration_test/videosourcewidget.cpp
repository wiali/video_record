#include <QDebug>

#include "videosourcewidget.h"
#include "ui_videosourcewidget.h"

using namespace video::source::test;

VideoSourceWidget::VideoSourceWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::VideoSourceWidget)
    , lastZoomValue (0)
{
    ui->setupUi(this);
}

VideoSourceWidget::~VideoSourceWidget()
{
    delete ui;
}

void VideoSourceWidget::zoomValueChanged(int value)
{
    float factor = value - lastZoomValue;
    factor /= 40.0f;

    emit zoomChanged(factor);

    lastZoomValue = value;
}

void VideoSourceWidget::panUpReleased()
{
    emit panChanged(1, 0);
}

void VideoSourceWidget::panDownReleased()
{
    emit panChanged(-1, 0);
}

void VideoSourceWidget::panLeftReleased()
{
    emit panChanged(0, -1);
}

void VideoSourceWidget::panRightReleased()
{
    emit panChanged(0, 1);
}

void VideoSourceWidget::moveUpReleased()
{
    emit moveChanged(1, 0);
}

void VideoSourceWidget::moveDownReleased()
{
    emit moveChanged(-1, 0);
}

void VideoSourceWidget::moveLeftReleased()
{
    emit moveChanged(0, -1);
}

void VideoSourceWidget::moveRightReleased()
{
    emit moveChanged(0, 1);
}

void VideoSourceWidget::isEnabledToggled(bool isEnabled)
{
    emit isEnabledChanged(isEnabled);
}

void VideoSourceWidget::resizeShorterReleased()
{
    emit resizeChanged(0, -1);
}

void VideoSourceWidget::resizeTallerReleased()
{
    emit resizeChanged(0, 1);
}

void VideoSourceWidget::resizeWiderReleased()
{
    emit resizeChanged(1, 0);
}

void VideoSourceWidget::resizeNarrowerReleased()
{
    emit resizeChanged(-1, 0);
}

void VideoSourceWidget::setIsIlluminationCorrectionEnabled(bool isEnabled)
{
    ui->illuminationCorrectionCheckbox->setChecked(isEnabled);
}

void VideoSourceWidget::setIsIlluminationCorrectionIncluded(bool isIncluded)
{
    ui->illuminationCorrectionCheckbox->setEnabled(isIncluded);
}

void VideoSourceWidget::setIsAutoWhiteBalanceEnabled(bool isEnabled)
{
    ui->autoWhiteBalanceCheckbox->setChecked(isEnabled);
}

void VideoSourceWidget::setIsAutoWhiteBalanceIncluded(bool isIncluded)
{
    ui->autoWhiteBalanceCheckbox->setEnabled(isIncluded);
}

void VideoSourceWidget::setColorCorrectionLampEnabled(bool isEnabled)
{
    ui->colorCorrectionLampCheckbox->setChecked(isEnabled);
}

void VideoSourceWidget::setColorCorrectionLampIncluded(bool isIncluded)
{
    ui->colorCorrectionLampCheckbox->setEnabled(isIncluded);
}

void VideoSourceWidget::illuminationCorrectionToggled(bool isEnabled)
{
    emit isIlluminationCorrectionEnabledChanged(isEnabled);
}

void VideoSourceWidget::autoWhiteBalanceToggled(bool isEnabled)
{
    emit isAutoWhiteBalanceEnabledChanged(isEnabled);
}

void VideoSourceWidget::colorCorrectionLampToggled(bool isEnabled)
{
    emit colorCorrectionLampChanged(isEnabled);
}
