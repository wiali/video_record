#ifndef VIDEO_SOURCE_COMBINEDOPENGLFILTER_H_
#define VIDEO_SOURCE_COMBINEDOPENGLFILTER_H_

#include <QObject>
#include <QOpenGLFramebufferObject>
#include <memory>

#include "video_source/videopipeline_api.h"
#include "video_source/outputvideosinkconfig.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

class CombinedOpenGLFilterPrivate;

template <class CombinedOpenGLFilter>
struct NizzaTaskDeleter;

class VIDEO_PIPELINE_API CombinedOpenGLFilter : public QObject
{
    Q_OBJECT
public:

  bool convert(QOpenGLFramebufferObject* frameBuffer);

  /*! \brief Destroys this instance.
   */
  virtual ~CombinedOpenGLFilter();

signals:

 /*!
  * \brief Signal frameBufferReady is emitted when frame buffer is filled with new frame.
  * \param sourceIndex Source index.
  * \param sourceIndex Index of SourcePipeline that produced this frame.
  * \param size Size of the frame in pixels.
  * \param dataSize Size of the frame in bytes.
  */
 void frameReady(int sourceIndex, const QSize& size, int dataSize);

private:

  friend class SourcePipelinePrivate;
  template <class CombinedOpenGLFilter>
  friend struct NizzaTaskDeleter;

  Q_DECLARE_PRIVATE(CombinedOpenGLFilter)
  QScopedPointer<video::source::CombinedOpenGLFilterPrivate> d_ptr;

  explicit CombinedOpenGLFilter(ulong index,
                                const OutputVideoSinkConfig& outputConfig,
                                std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                QObject *parent = nullptr);
};

}  // namespace source
}  // namespace video

#endif // VIDEO_SOURCE_COMBINEDOPENGLFILTER_H_
