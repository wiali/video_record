/*! \file outputvideosinkconfig.h
     *  \brief Contains the definition of the ouput video sink parameters.
     *  \date November, 2016
     *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
     */

#ifndef VIDEO_SOURCE_OUTPUTVIDEOSINKCONFIG_H_
#define VIDEO_SOURCE_OUTPUTVIDEOSINKCONFIG_H_

#include <QDebug>
#include <QObject>
#include <QSize>

#include "video_source/videopipeline_api.h"
#include "video_source/finalframegrabberconfig.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired output sync params.
 */
class VIDEO_PIPELINE_API OutputVideoSinkConfig
{
  Q_GADGET
  Q_PROPERTY(QString name MEMBER name)
  Q_PROPERTY(QSize size MEMBER size)
  Q_PROPERTY(int viewportRedrawDelay MEMBER viewportRedrawDelay)
  Q_PROPERTY(QSize monitorWindowSize MEMBER monitorWindowSize)

public:

  /*! \brief Creates a default OutputVideoSinkConfig.
   *  \details All members are default constructed except for viewportRedrawDelay which is initialized with 25.
   */
  OutputVideoSinkConfig() : viewportRedrawDelay(25) {}

  /*! \brief Name of output video sync (camera).
   *  \details If no name is provided output sync will be ignored.
   */
  QString name;

  /*! \brief Image size.
   */
  QSize size;

  /*! \brief Indicates delay between redraws after viewport updates (pan or zoom operations).
   */
  int viewportRedrawDelay;

  /*! \brief Defined Nizza monitor window size.
   *  \details The monitor window is shown when this QSize is valid (false by default).
   */
  QSize monitorWindowSize;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if OutputVideoSinkConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::OutputVideoSinkConfig& lhs,
                         const video::source::OutputVideoSinkConfig& rhs)
{
  return (lhs.name == rhs.name && lhs.size == rhs.size &&
          lhs.viewportRedrawDelay == rhs.viewportRedrawDelay &&
          lhs.monitorWindowSize == rhs.monitorWindowSize);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if OutputVideoSinkConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::OutputVideoSinkConfig& lhs,
                         const video::source::OutputVideoSinkConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::OutputVideoSinkConfig& obj)
{
  debug << obj.name << "[" << obj.size << "]"
        << "Nizza monitor window size" << obj.monitorWindowSize << "with viewport redraw delay of "
        << obj.viewportRedrawDelay << "ms";
  return debug;
}

#endif  // VIDEO_SOURCE_OUTPUTVIDEOSINKCONFIG_H_
