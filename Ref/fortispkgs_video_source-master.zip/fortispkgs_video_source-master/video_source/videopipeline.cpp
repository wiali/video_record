#include "video_source/videopipeline.h"
#include "video_source/private/videopipeline_p.h"

namespace video {
namespace source {

/***********************************************************************************/

VideoPipeline::VideoPipeline(QObject* parent)
    : QObject(parent), d_ptr(new VideoPipelinePrivate(this)) {
  static struct Initialize {
    Initialize() {
      // Required for correct cross-thread signal propagation

      qRegisterMetaType<video::source::VideoPipeline::VideoPipelineState>();
      qRegisterMetaType<video::source::OutputVideoSinkConfig>();
      qRegisterMetaType<video::source::ColorCorrectionFilter::Mode>();
    }
  } initialize;
}

void VideoPipeline::setOutputSinkConfiguration(const OutputVideoSinkConfig& configuration) {
  Q_D(VideoPipeline);
  d->setOutputSinkConfiguration(configuration);
}

/***********************************************************************************/

VideoPipeline::~VideoPipeline() {}

/***********************************************************************************/

QVector<sensordata::SensorData> VideoPipeline::capture(QStringList stillFrameSources) {
  Q_D(VideoPipeline);
  return d->capture(stillFrameSources);
}

/***********************************************************************************/

void VideoPipeline::start() {
  Q_D(VideoPipeline);
  d->start();
}

/***********************************************************************************/

void VideoPipeline::stop() {
  Q_D(VideoPipeline);
  d->stop();
}

/***********************************************************************************/

video::source::OutputVideoSinkConfig VideoPipeline::outputSinkConfiguration() {
  Q_D(VideoPipeline);
  return d->outputSinkConfiguration();
}

/***********************************************************************************/

QVector<QSharedPointer<SourcePipeline>> VideoPipeline::sources() {
  Q_D(VideoPipeline);
  return d->sources();
}

/***********************************************************************************/

QSharedPointer<SourcePipeline> VideoPipeline::addSource(const QString& name,
                                                        SourcePipelineConfig config) {
  Q_D(VideoPipeline);
  return d->addSource(name, config);
}

/***********************************************************************************/

QSharedPointer<SourcePipeline> VideoPipeline::addKnownSource(
    SourcePipeline::SourcePipelineType sourceType, QSize resolution) {
  Q_D(VideoPipeline);
  return d->addKnownSource(sourceType, resolution);
}

/***********************************************************************************/

void VideoPipeline::removeSource(const QString& name) {
  Q_D(VideoPipeline);
  d->removeSource(name);
}

/***********************************************************************************/

VideoPipeline::VideoPipelineState VideoPipeline::state() {
  Q_D(VideoPipeline);
  return d->state();
}

/***********************************************************************************/

void VideoPipeline::setLogPath(const QString& name) {
  Q_D(VideoPipeline);
  d->setLogPath(name);
}

/***********************************************************************************/

QString VideoPipeline::logPath() {
  Q_D(VideoPipeline);
  return d->logPath();
}

/***********************************************************************************/

QVector<QSize> VideoPipeline::knownResolutions(SourcePipeline::SourcePipelineType sourceType) {
  Q_D(VideoPipeline);
  return d->knownResolutions(sourceType);
}

}  // namespace source
}  // namespace video
