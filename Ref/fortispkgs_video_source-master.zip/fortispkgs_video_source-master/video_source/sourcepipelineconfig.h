/*! \file sourcepipelineconfig.h
 *  \brief Contains the definition of the source pipeline configuration up to the compositor.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_SOURCEPIPELINECONFIG_H_
#define VIDEO_SOURCE_SOURCEPIPELINECONFIG_H_

#include <QObject>
#include <QString>
#include <QStringList>

#include "video_source/videopipeline_api.h"

#include "video_source/colorcorrectionfilterconfig.h"
#include "video_source/desktopcapturesourceconfig.h"
#include "video_source/genericfilterconfig.h"
#include "video_source/illuminationcorrectionfilterconfig.h"
#include "video_source/inputvideosourceconfig.h"
#include "video_source/keystonecorrectionfilterconfig.h"
#include "video_source/mirrorfilterconfig.h"
#include "video_source/outputvideosinkconfig.h"

namespace video {
namespace source {

/*! \brief Wraps configuration of single video pipeline source.
 */
class VIDEO_PIPELINE_API SourcePipelineConfig
{
  Q_GADGET

  Q_PROPERTY(video::source::InputVideoSourceConfig inputVideoSource MEMBER inputVideoSource)
  Q_PROPERTY(video::source::DesktopSourceConfig desktopCaptureSource MEMBER desktopCaptureSource)
  Q_PROPERTY(video::source::KeystoneCorrectionFilterConfig keystoneCorrection MEMBER keystoneCorrection)
  Q_PROPERTY(video::source::IlluminationCorrectionFilterConfig illuminationCorrection MEMBER illuminationCorrection)
  Q_PROPERTY(video::source::GenericFilterConfig sharpen MEMBER sharpen)
  Q_PROPERTY(SourcePipelineConfig::SourceType sourceType MEMBER sourceType)
  Q_PROPERTY(video::source::FinalFrameGrabberConfig frameGrabber MEMBER frameGrabber)
  Q_PROPERTY(video::source::GenericFilterConfig autoWhiteBalance MEMBER autoWhiteBalance)
  Q_PROPERTY(video::source::ColorCorrectionFilterConfig colorCorrection MEMBER colorCorrection)
  Q_PROPERTY(video::source::MirrorFilterConfig mirror MEMBER mirror)
  Q_PROPERTY(video::source::FinalFrameGrabberConfig stillCapture MEMBER stillCapture)
  Q_PROPERTY(QSizeF deviceDimensions MEMBER deviceDimensions)
  Q_PROPERTY(QString captureType MEMBER captureType)
  Q_PROPERTY(SourcePipelineConfig::Backend backend MEMBER backend)

 public:

  /*! \brief Defines possible source type.
   */
  enum SourceType
  {
      DirectShow = 0x00, /*!< The source is a camera, e.g one of Sprout's camera, external Webcam, etc. used through DirectShow */
      Desktop = 0x10, /*!< The source is one of the Desktops. */
      OpenNI = 0x20 /*!< The source is streaming from OpenNI device. */
  };

  Q_ENUM(SourceType)

  /*! \brief Defines possible source type.
   */
  enum Backend
  {
      IntelIPP = 0x00, /*!< The backend is Intel Integrated Performance Primitives (CPU based) */
      OpenGL = 0x01 /*!< The backend is OpenGL (shaders running on GPU). */
  };

  Q_ENUM(Backend)

  /*! \brief Creates a default constructed source pipeline configuration.
   *  \details All members are default constructed, except for `captureType` which is set as "hiresrgb".
   */
  SourcePipelineConfig() : captureType("hiresrgb"), backend(SourcePipelineConfig::IntelIPP) {}

  /*! \brief Contains information about video input source of this pipeline.
   */
  video::source::InputVideoSourceConfig inputVideoSource;

  /*! \brief Contains information about desktop capture source of this pipeline.
   */
  video::source::DesktopSourceConfig desktopCaptureSource;

  /*! \brief Contains information for keystone-correction filter.
   */
  video::source::KeystoneCorrectionFilterConfig keystoneCorrection;

  /*! \brief Contains information for illumination-correction filter.
   */
  video::source::IlluminationCorrectionFilterConfig illuminationCorrection;

  /*! \brief Contains information for sharpen filter.
   */
  video::source::GenericFilterConfig sharpen;

  /*! \brief Defines source type.
   */
  SourcePipelineConfig::SourceType sourceType;

  /*! \brief Contains information for frame-grabber filter.
   */
  video::source::FinalFrameGrabberConfig frameGrabber;

  /*! \brief Contains information for auto white balance filter.
   */
  video::source::GenericFilterConfig autoWhiteBalance;

  /*! \brief Contains information for color-correction filter.
   */
  video::source::ColorCorrectionFilterConfig colorCorrection;

  /*! \brief Contains information for mirror filter.
   */
  video::source::MirrorFilterConfig mirror;

  /*! \brief Contains information for still capture.
   */
  video::source::FinalFrameGrabberConfig stillCapture;

  /*! \brief Contains information about the physical size of the input device in meters, used for DPI calculation.
   *  \details If set to (0x0) then DPI will not be calculated and inserted to final image.
   */
  QSizeF deviceDimensions;

  /*! \brief Declares capture type that will be passed into SensorData.
   */
  QString captureType;

  /*! \brief Declared type of backend to be used.
   */
  SourcePipelineConfig::Backend backend;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if SourcePipelineConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::SourcePipelineConfig& lhs,
                         const video::source::SourcePipelineConfig& rhs)
{
  return (lhs.inputVideoSource == rhs.inputVideoSource &&
          lhs.desktopCaptureSource == rhs.desktopCaptureSource &&
          lhs.keystoneCorrection == rhs.keystoneCorrection &&
          lhs.illuminationCorrection == rhs.illuminationCorrection &&
          lhs.frameGrabber == rhs.frameGrabber && lhs.sharpen == rhs.sharpen &&
          lhs.autoWhiteBalance == rhs.autoWhiteBalance &&
          lhs.colorCorrection == rhs.colorCorrection && lhs.mirror == rhs.mirror &&
          lhs.stillCapture == rhs.stillCapture &&
          lhs.deviceDimensions == rhs.deviceDimensions &&
          lhs.captureType == rhs.captureType &&
          lhs.backend == rhs.backend);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if SourcePipelineConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::SourcePipelineConfig& lhs,
                         const video::source::SourcePipelineConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::SourcePipelineConfig& obj)
{
  debug << "Type" << obj.sourceType << "using" << obj.backend << ", device dimensions"
        << obj.deviceDimensions << "[meters], capture type" << obj.captureType;

  switch (obj.sourceType) {
    case video::source::SourcePipelineConfig::DirectShow:
      debug << "DirectShow video source" << obj.inputVideoSource;
      break;
    case video::source::SourcePipelineConfig::Desktop:
      debug << "Desktop capture source" << obj.desktopCaptureSource;
      break;
    case video::source::SourcePipelineConfig::OpenNI:
      debug << "OpenNI capture source";
      break;
  }

  debug << "Keystone correction" << obj.keystoneCorrection << "Illumination correction"
        << obj.illuminationCorrection << "Sharpen" << obj.sharpen << "Auto white balance"
        << obj.autoWhiteBalance << "Color correction" << obj.colorCorrection << "Frame grabber"
        << obj.frameGrabber << "Mirror" << obj.mirror << "Still capture" << obj.stillCapture;

  return debug;
}

#endif  // VIDEO_SOURCE_SOURCEPIPELINECONFIG_H_
