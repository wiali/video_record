#include "video_source/illuminationcorrectionfilter.h"

#include "video_source/private/illuminationcorrectionfilter_p.h"
#include "video_source/private/combinedopenglfilter_p.h"

namespace video {
namespace source {

/******************************************************************************/

IlluminationCorrectionFilter::IlluminationCorrectionFilter(ulong index, bool autoWhiteBalance,
    QGenericMatrix<1, 6, float>& illuminationCoefficients,
    std::shared_ptr<image_filters::ImageFilter> imageFilter, QObject *parent)
    : QObject(parent),
      d_ptr(new IlluminationCorrectionFilterPrivate(index, autoWhiteBalance, illuminationCoefficients, imageFilter, this)),
      m_combinedOpenGLFilter(nullptr) {}

/******************************************************************************/

IlluminationCorrectionFilter::~IlluminationCorrectionFilter() {}

/******************************************************************************/

bool IlluminationCorrectionFilter::enabled() {
  if (m_combinedOpenGLFilter) {
    return m_combinedOpenGLFilter->illuminationCorrection();
  } else {
    Q_D(IlluminationCorrectionFilter);
    return d->enabled();
  }
}

/******************************************************************************/

void IlluminationCorrectionFilter::setEnabled(bool enabled) {
  if (m_combinedOpenGLFilter) {
    m_combinedOpenGLFilter->setIlluminationCorrection(enabled);
  } else {
    Q_D(IlluminationCorrectionFilter);
    d->setEnabled(enabled);
  }
}

/******************************************************************************/

bool IlluminationCorrectionFilter::autoWhiteBalance() {
  if (m_combinedOpenGLFilter) {
    return m_combinedOpenGLFilter->autoWhiteBalance();
  } else {
    Q_D(IlluminationCorrectionFilter);
    return d->autoWhiteBalance();
  }
}

/******************************************************************************/

void IlluminationCorrectionFilter::setAutoWhiteBalance(bool autoWhiteBalance) {
  if (m_combinedOpenGLFilter) {
    m_combinedOpenGLFilter->setAutoWhiteBalance(autoWhiteBalance);
  } else {
    Q_D(IlluminationCorrectionFilter);
    d->setAutoWhiteBalance(autoWhiteBalance);
  }
}

}  // namespace source
}  // namespace video
