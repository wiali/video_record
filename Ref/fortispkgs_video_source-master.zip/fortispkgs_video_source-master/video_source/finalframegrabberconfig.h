/*! \file finalframegrabberconfig.h
 *  \brief Contains the definition of the final frame-grabber filter parameters.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_FINALFRAMEGRABBERCONFIG_H_
#define VIDEO_SOURCE_FINALFRAMEGRABBERCONFIG_H_

#include <QDebug>
#include <QObject>

#include "video_source/genericfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Contains the configuration for the final frame-grabber filter.
 *  \details If enabled, it allows final frames to be grabbed by calling SourcePipeline::setFrameGrabberBuffer and
 *           monitoring new frames through signal SourcePipeline::frameBufferReady.
 */
class VIDEO_PIPELINE_API FinalFrameGrabberConfig
    : public GenericFilterConfig
{
  Q_GADGET
  Q_PROPERTY(Format format MEMBER format)

public:

  /*! Declares possible output formats of final frame-grabber.
   */
  enum Format
  {
      RGB888, /*!< \brief The image is stored using a 24-bit RGB format (8-8-8). */
      BGR888, /*!< \brief The image is stored using a 24-bit BGR format (8-8-8). */
      BGR32   /*!< \brief The image is stored using a 32-bit BGR format (0xffRRGGBB). */
  };

  Q_ENUM(Format)

  /*! \brief Creates a default FinalFrameGrabberConfig.
   *  \details The default format is BGR888, which is the format outputed by the pipeline.
   *           Other formats require conversion from BGR888 to desired format.
   */
  FinalFrameGrabberConfig() : format(BGR888) {}

  /*! \brief Desired output format.
   *  \details The pipeline natively provide frames as BGR888.
   *           Different formats will require a conversion before copying the frame to the user supplied buffer.
   */
  Format format;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if FinalFrameGrabberConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::FinalFrameGrabberConfig& lhs,
                         const video::source::FinalFrameGrabberConfig& rhs)
{
  return (static_cast<const video::source::GenericFilterConfig&>(lhs) ==
              static_cast<const video::source::GenericFilterConfig&>(rhs) &&
          lhs.format == rhs.format);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if FinalFrameGrabberConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::FinalFrameGrabberConfig& lhs,
                         const video::source::FinalFrameGrabberConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::FinalFrameGrabberConfig& obj)
{
  debug << static_cast<const video::source::GenericFilterConfig&>(obj) << obj.format;
  return debug;
}

#endif  // VIDEO_SOURCE_FINALFRAMEGRABBERCONFIG_H_
