/*! \file mirrorfilterconfig.h
 *  \brief Contains the definition of the mirror filter parameters.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_MIRRORFILTERCONFIG_H_
#define VIDEO_SOURCE_MIRRORFILTERCONFIG_H_

#include <QDebug>
#include <QGenericMatrix>
#include <QObject>

#include "video_source/genericfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired illumination-correction filter parameters.
 */
class VIDEO_PIPELINE_API MirrorFilterConfig
    : public GenericFilterConfig
{
  Q_GADGET
  Q_PROPERTY(MirrorType type MEMBER type)

public:
  /*! \brief The MirrorType enum declares possible mirroring types.
   */
  enum MirrorType
  {
    None, /*! \brief No mirroring */
    Horizontal, /*! \brief Mirror about horizontal axis. */
    Vertical, /*! \brief Mirror about vertical axis. */
    Both /*! \brief Mirror about both axes. */
  };

  Q_ENUM(MirrorType)

  /*! \brief Creates a default MirrorFilterConfig.
   *  \details By default the type is set as Horizontal.
   */
  MirrorFilterConfig() : type(Horizontal) {}

  /*! \brief Indicates if the output image should be mirrored.
   */
  MirrorType type;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if MirrorFilterConfig values are the same, otherwise false.
 */
inline bool operator==(const video::source::MirrorFilterConfig& lhs,
                       const video::source::MirrorFilterConfig& rhs)
{
  return (static_cast<const video::source::GenericFilterConfig&>(lhs) ==
          static_cast<const video::source::GenericFilterConfig&>(rhs) &&
          lhs.type == rhs.type);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if MirrorFilterConfig values are not the same, otherwise false.
 */
inline bool operator!=(const video::source::MirrorFilterConfig& lhs,
                       const video::source::MirrorFilterConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator<<(QDebug debug, const video::source::MirrorFilterConfig& obj)
{
  debug << static_cast<const video::source::GenericFilterConfig&>(obj) << obj.type;
  return debug;
}

#endif  // VIDEO_SOURCE_MIRRORFILTERCONFIG_H_
