/*! \file keystonecorrectionfilterconfig.h
 *  \brief Contains the definition of the keystone-correction filter parameters.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_KEYSTONECORRECTIONFILTERCONFIG_H_
#define VIDEO_SOURCE_KEYSTONECORRECTIONFILTERCONFIG_H_

#include <QDebug>
#include <QObject>
#include <QRect>
#include <QString>

#include "video_source/genericfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired keystone-correction filter parameters.
 */
class VIDEO_PIPELINE_API KeystoneCorrectionFilterConfig
    : public GenericFilterConfig
{
  Q_GADGET
  Q_PROPERTY(QString homographyMatrixName MEMBER homographyMatrixName)
  Q_PROPERTY(Quality quality MEMBER quality)

public:
  /*! \brief Declares the possible quality settings when performing keystone-correction.
   */
  enum Quality
  {
    Nearest = 1, /*!< \brief Fastest algorithm but low quality. */
    Linear = 2 /*!< \brief Linear interpolation algorithm. */
  };

  Q_ENUM(Quality)

  /*! \brief Creates a default KeystoneCorrectionFilterConfig.
   *  \details By default the quality is set as Linear.
   */
  KeystoneCorrectionFilterConfig() : quality(Linear) {}

  /*! \brief Transformation matrix.
   */
  QString homographyMatrixName;

  /*! \brief Filter quality.
   */
  Quality quality;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if KeystoneCorrectionFilterConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::KeystoneCorrectionFilterConfig& lhs,
                         const video::source::KeystoneCorrectionFilterConfig& rhs)
{
  return (static_cast<const video::source::GenericFilterConfig&>(lhs) ==
              static_cast<const video::source::GenericFilterConfig&>(rhs) &&
          lhs.homographyMatrixName == rhs.homographyMatrixName && lhs.quality == rhs.quality);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if KeystoneCorrectionFilterConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::KeystoneCorrectionFilterConfig& lhs,
                         const video::source::KeystoneCorrectionFilterConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::KeystoneCorrectionFilterConfig& obj)
{
  debug << static_cast<const video::source::GenericFilterConfig&>(obj) << obj.quality
        << obj.homographyMatrixName;
  return debug;
}

#endif  // VIDEO_SOURCE_KEYSTONECORRECTIONFILTERCONFIG_H_
