/*! \file invalidconfigurationexception.h
 *  \brief Defines the exception thrown when the video pipeline configuration is invalid.
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_INVALIDCONFIGURATIONEXCEPTION_H_
#define VIDEO_SOURCE_INVALIDCONFIGURATIONEXCEPTION_H_

#include <QException>
#include <QObject>

#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief This exception is thrown when the video pipeline configuration is invalid.
 */
class InvalidConfigurationException
    : public QException
{
public:
  /*! \brief Constructs a new exception using the supplied parameters.
   *  \param message Error message detailing the exception.
   */
  explicit InvalidConfigurationException(const QString& message) : m_message(message) {}

  /*! \brief Returns the error message.
   *  \return QString with the message passed to the constrcutor.
   */
  QString message() const { return m_message; }

  /*! \brief Raises this exception.
   */
  void raise() const { throw * this; }

  /*! \brief Returns the cloned exception.
   *  \return Pointer to new instance that is a copy of this one.
   */
  InvalidConfigurationException* clone() const { return new InvalidConfigurationException(*this); }

  /*! \brief Returns the description of this exception.
   *  \return Exception description as C-string.
   */
  virtual char const* what() const { return message().toStdString().c_str(); }

 protected:

  /*! \brief Error message. */
  QString m_message;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_INVALIDCONFIGURATIONEXCEPTION_H_
