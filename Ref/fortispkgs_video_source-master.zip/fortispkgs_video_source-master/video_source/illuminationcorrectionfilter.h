/*! \file illuminationcorrectionfilter.h
 *  \brief Contains the public interface of the illumination-correction filter.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTER_H_
#define VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTER_H_

#include <QObject>
#include <QScopedPointer>
#include <memory>

#include "video_source/illuminationcorrectionfilterconfig.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

class IlluminationCorrectionFilterPrivate;
class CombinedOpenGLFilterPrivate;

template <class IlluminationCorrectionFilter>
struct NizzaTaskDeleter;

/*! \brief Uses illumination-correction algorithm to enhance the image passing through video pipeline.
 *  \details Optionally, this filter can also perform auto white balance in one pass.
 */
class VIDEO_PIPELINE_API IlluminationCorrectionFilter
    : public QObject
{
  Q_OBJECT

  /*! \brief Property indicating if this filter is enabled.
   */
  Q_PROPERTY(bool enabled READ enabled WRITE setEnabled NOTIFY enabledChanged)

  /*! \brief Property indicating if auto white balance algorithm is enabled.
   */
  Q_PROPERTY(bool autoWhiteBalance READ autoWhiteBalance WRITE setAutoWhiteBalance NOTIFY autoWhiteBalanceChanged)

public:

  /*! \brief Destroys this instance.
   */
  virtual ~IlluminationCorrectionFilter();

  /*! \brief Returns if this filter is enabled or not.
   *  \return True if enabled, false otherwise.
   */
  bool enabled();

  /*! \brief Returns if optional auto white balance algorithm is enabled.
   *  \return True if auto white balance is enabled, false otherwise.
   */
  bool autoWhiteBalance();

Q_SIGNALS:

  /*! \brief Signal emitted when filter is enabled or disabled.
   *  \param enabled Indicates if this filter is enabled or not.
   */
  void enabledChanged(bool enabled);

  /*! \brief Signal emitted when auto white balance is enabled or disabled.
   *  \param autoWhiteBalance Indicates if auto-white balance on this filter is enabled or not.
   */
  void autoWhiteBalanceChanged(bool autoWhiteBalance);

public Q_SLOTS:

  /*! \brief Sets if this filter is enabled or not.
   *  \param enabled New value indicating if this filter is enabled or not.
   */
  void setEnabled(bool enabled);

  /*! \brief Sets if auto white balance algorithm should be used.
   *  \param autoWhiteBalance Indicates if auto white balance algorithm should be used.
   */
  void setAutoWhiteBalance(bool autoWhiteBalance);

private:

  friend class SourcePipelinePrivate;
  template <class AutoWhiteBalanceFilter>
  friend struct NizzaTaskDeleter;

  Q_DECLARE_PRIVATE(IlluminationCorrectionFilter)
  QScopedPointer<IlluminationCorrectionFilterPrivate> d_ptr;
  CombinedOpenGLFilterPrivate* m_combinedOpenGLFilter;

  explicit IlluminationCorrectionFilter(ulong index,
                                        bool autoWhiteBalance, QGenericMatrix<1, 6, float> &illuminationCoefficients,
                                        std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                        QObject *parent = 0);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTER_H_
