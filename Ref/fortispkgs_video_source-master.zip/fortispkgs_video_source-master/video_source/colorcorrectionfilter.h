/*! \file colorcorrectionfilter.h
 *  \brief Contains the implementation of the color-correction filter.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_COLORCORRECTIONFILTER_H_
#define VIDEO_SOURCE_COLORCORRECTIONFILTER_H_

#include <QObject>
#include <QScopedPointer>
#include <memory>

#include "video_source/colorcorrectionfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

class ColorCorrectionFilterPrivate;
class CombinedOpenGLFilterPrivate;

template <class ColorCorrectionFilter>
struct NizzaTaskDeleter;

/*! \brief Uses proprietary color-correction algorithm to enhance the image passing through video pipeline.
 */
class VIDEO_PIPELINE_API ColorCorrectionFilter
    : public QObject
{
  Q_OBJECT

  /*! \brief Property indicating if this filter is enabled.
   */
  Q_PROPERTY(bool enabled READ enabled WRITE setEnabled NOTIFY enabledChanged)

  /*! \brief Property indicating color-correction mode.
   */
  Q_PROPERTY(ColorCorrectionFilter::Mode mode READ mode WRITE setMode NOTIFY modeChanged)

  /*! \brief Property returning current Lamp On coefficients.
   */
  Q_PROPERTY(QGenericMatrix<3, 8, float> lampOnCoefficients READ lampOnCoefficients WRITE setLampOnCoefficients)

    /*! \brief Property returning current Lamp Off coefficients.
     */
  Q_PROPERTY(QGenericMatrix<3, 8, float> lampOffCoefficients READ lampOffCoefficients WRITE setLampOffCoefficients)

public:

  /*! \brief Mode represent the possible scenarios that have calibration data available for color-correction.
   */
  enum Mode
  {
      /*! \brief This mode expects a completely white window projected over the entire Mat.
       *  \details This forces the projector to go to maximum nominal brightness.
       */
      LampOn,

      /*! \brief This mode expects the projector to be off.
       *  \details Projector off is equivalent to having a completely black window projected over the entire Mat.
       *           This forces the projector to go to minimum nominal brightness.
       */
      LampOff
  };

  Q_ENUM(Mode)

  /*! \brief Destroys this instance.
   */
  virtual ~ColorCorrectionFilter();

  /*! \brief Returns if this filter is enabled or not.
   *  \return True if enabled, false otherwise.
   */
  bool enabled();

  /*! \brief Returns color-correction mode.
   *  \return Enum with current mode.
   */
  ColorCorrectionFilter::Mode mode();

  /*!
   * \brief Returns Lamp On coefficients;
   * \return Matrix with current Lamp On coefficients.
   */
  QGenericMatrix<3, 8, float> lampOnCoefficients();

  /*!
   * \brief Returns Lamp Off coefficients;
   * \return Matrix with current Lamp Off coefficients.
   */
  QGenericMatrix<3, 8, float> lampOffCoefficients();

Q_SIGNALS:

  /*! \brief Signal emitted whenever the filter is enabled or disabled.
   *  \param enabled Indicates if this filter is enabled or not.
   */
  void enabledChanged(bool enabled);

  /*! \brief Signal emitted whenever the color-correction mode is changed.
   *  \param mode Indicates new mode.
   */
  void modeChanged(ColorCorrectionFilter::Mode mode);

public Q_SLOTS:

  /*! \brief Sets if this filter is enabled or not.
   *  \param enabled New value indicating if this filter is enabled or not.
   */
  void setEnabled(bool enabled);

  /*! \brief Sets new color-correction mode.
   *  \param mode New mode value.
   */
  void setMode(ColorCorrectionFilter::Mode mode);

  /*! \brief Sets new Lamp On coefficients.
   *  \param coefficients New Lamp On coefficients.
   */
  void setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

  /*! \brief Sets new Lamp Off coefficients.
   *  \param coefficients New Lamp Off coefficients.
   */
  void setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

private:

  friend class SourcePipelinePrivate;
  template <class ColorCorrectionFilter>
  friend struct NizzaTaskDeleter;

  Q_DECLARE_PRIVATE(ColorCorrectionFilter)
  QScopedPointer<ColorCorrectionFilterPrivate> d_ptr;
  CombinedOpenGLFilterPrivate* m_combinedOpenGLFilter;

  explicit ColorCorrectionFilter(ulong index,
                                 std::shared_ptr<image_filters::ImageFilter> imageFilter, QObject *parent = 0);
};

}  // namespace source
}  // namespace video

Q_DECLARE_METATYPE(video::source::ColorCorrectionFilter *)

#endif  // VIDEO_SOURCE_COLORCORRECTIONFILTER_H_
