#include "video_source/combinedopenglfilter.h"

#include "video_source/private/combinedopenglfilter_p.h"

namespace video {
namespace source {

/******************************************************************************/

CombinedOpenGLFilter::CombinedOpenGLFilter(ulong index, const OutputVideoSinkConfig &outputConfig,
                                           std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                           QObject *parent)
    : QObject(parent), d_ptr(new CombinedOpenGLFilterPrivate(index, outputConfig, imageFilter, this)) {}

/******************************************************************************/

CombinedOpenGLFilter::~CombinedOpenGLFilter() {}

/******************************************************************************/

bool CombinedOpenGLFilter::convert(QOpenGLFramebufferObject *frameBuffer) {
    Q_D(CombinedOpenGLFilter);
    return d->convert(frameBuffer);
}

/******************************************************************************/

}  // namespace source
}  // namespace video
