/*! \file nizzaexception.h
 *  \brief Defines the exception thrown when an operation fails in the Nizza framework.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_NIZZAEXCEPTION_H_
#define VIDEO_SOURCE_NIZZAEXCEPTION_H_

#include <QException>
#include <QObject>

#include <string>

#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief This exception is thrown when an operation fails in the Nizza framework.
 */
class NizzaException
    : public QException
{
public:
  /*! \brief Constructor
   *  \param message Error message.
   *  \param innerError Message coming from Nizza framework.
   */
  NizzaException(const QString& message, std::string innerError)
      : m_message(message)
      , m_innerError(QString::fromStdString(innerError))
  {}

  /*! \brief Returns the error message.
   *  \return QString with the original message passed to constructor.
   */
  QString message() const { return m_message; }

  /*! \brief Returns the Nizza error message.
   *  \return QString with inner error passed to constrcutor.
   */
  QString innerError() const { return m_innerError; }

  /*! \brief Raises this exception.
   */
  void raise() const { throw * this; }

  /*! \brief Returns a cloned exception.
   *  \return Pointer to new instance that's a copy of this one.
   */
  NizzaException* clone() const { return new NizzaException(*this); }

  /*! \brief Returns a description of this exception.
   *  \return Exception description as C-string.
   */
  virtual char const* what() const
  {
    return QString("%1 [inner error: %2]").arg(message()).arg(innerError()).toStdString().c_str();
  }

protected:

  /*! \brief Error message. */
  QString m_message;

  /*! \brief Error innner error message. */
  QString m_innerError;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_NIZZAEXCEPTION_H_
