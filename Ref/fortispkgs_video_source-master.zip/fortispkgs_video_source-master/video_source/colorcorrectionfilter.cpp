#include "video_source/colorcorrectionfilter.h"

#include "video_source/private/colorcorrectionfilter_p.h"
#include "video_source/private/combinedopenglfilter_p.h"

namespace video {
namespace source {

/******************************************************************************/

ColorCorrectionFilter::ColorCorrectionFilter(ulong index,
                                             std::shared_ptr<image_filters::ImageFilter> imageFilter, QObject *parent)
    : QObject(parent)
    , d_ptr(new ColorCorrectionFilterPrivate(index, imageFilter, this))
    , m_combinedOpenGLFilter(nullptr) {}

/******************************************************************************/

ColorCorrectionFilter::~ColorCorrectionFilter() {}

/******************************************************************************/

bool ColorCorrectionFilter::enabled() {
  if (m_combinedOpenGLFilter) {
    return m_combinedOpenGLFilter->colorCorrection();
  } else {
    Q_D(ColorCorrectionFilter);
    return d->enabled();
  }
}

/******************************************************************************/

void ColorCorrectionFilter::setEnabled(bool enabled) {
  if (m_combinedOpenGLFilter) {
    m_combinedOpenGLFilter->setColorCorrection(enabled);
  } else {
    Q_D(ColorCorrectionFilter);
    d->setEnabled(enabled);
  }
}

/******************************************************************************/

ColorCorrectionFilter::Mode ColorCorrectionFilter::mode() {
  Q_D(ColorCorrectionFilter);
  return d->mode();
}

/******************************************************************************/

void ColorCorrectionFilter::setMode(ColorCorrectionFilter::Mode mode) {
  if (m_combinedOpenGLFilter) {
      m_combinedOpenGLFilter->setColorCorrectionMode(mode);
  } else {
    Q_D(ColorCorrectionFilter);
    d->setMode(mode);
  }
}

/******************************************************************************/

QGenericMatrix<3, 8, float> ColorCorrectionFilter::lampOnCoefficients() {
  if (m_combinedOpenGLFilter) {
    return m_combinedOpenGLFilter->lampOnCoefficients();
  } else {
    Q_D(ColorCorrectionFilter);
    return d->lampOnCoefficients();
  }
}

/******************************************************************************/

void ColorCorrectionFilter::setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (m_combinedOpenGLFilter) {
      m_combinedOpenGLFilter->setLampOnCoefficients(coefficients);
  } else {
    Q_D(ColorCorrectionFilter);
    d->setLampOnCoefficients(coefficients);
  }
}

/******************************************************************************/

QGenericMatrix<3, 8, float> ColorCorrectionFilter::lampOffCoefficients() {
  if (m_combinedOpenGLFilter) {
    return m_combinedOpenGLFilter->lampOffCoefficients();
  } else {
    Q_D(ColorCorrectionFilter);
    return d->lampOffCoefficients();
  }
}

/******************************************************************************/

void ColorCorrectionFilter::setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (m_combinedOpenGLFilter) {
      m_combinedOpenGLFilter->setLampOffCoefficients(coefficients);
  } else {
    Q_D(ColorCorrectionFilter);
    d->setLampOffCoefficients(coefficients);
  }
}

}  // namespace source
}  // namespace video
