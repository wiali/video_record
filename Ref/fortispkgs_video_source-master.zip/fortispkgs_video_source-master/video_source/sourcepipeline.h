/*! \file sourcepipeline.h
 *  \brief Contains the definition of the source pipeline.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_SOURCEPIPELINE_H_
#define VIDEO_SOURCE_SOURCEPIPELINE_H_

#include <QObject>
#include <QSharedPointer>

#include <sensor_data.h>

#include <memory>

#include "video_source/autowhitebalancefilter.h"
#include "video_source/colorcorrectionfilter.h"
#include "video_source/illuminationcorrectionfilter.h"
#include "video_source/combinedopenglfilter.h"
#include "video_source/sourcepipelineconfig.h"
#include "video_source/videopipeline_api.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

class SourcePipelinePrivate;

/*! \brief The SourcePipeline class encapsulates part of video pipeline until it reaches the compositor.
 */
class VIDEO_PIPELINE_API SourcePipeline
    : public QObject
{
  Q_OBJECT

  /*! \brief Property indicating if this input source is enabled.
   */
  Q_PROPERTY(bool enabled READ enabled WRITE setEnabled NOTIFY enabledChanged)

  /*! \brief Viewport coordinates.
   */
  Q_PROPERTY(QRectF viewport READ viewport WRITE setViewport NOTIFY viewportChanged)

  /*! \brief Coordinates of destination rectangle within a composited image.
   */
  Q_PROPERTY(QRectF destinationRectangle READ destinationRectangle WRITE setDestinationRectangle
             NOTIFY destinationRectangleChanged)

  /*! \brief Name of this input source.
   */
  Q_PROPERTY(QString name READ name)

  /*! \brief Size of the image.
   */
  Q_PROPERTY(QSize size READ size NOTIFY sizeChanged)

  /*! \brief Pointer to illumination-correction filter.
   */
  Q_PROPERTY(IlluminationCorrectionFilter* illuminationCorrection READ illuminationCorrection CONSTANT)

  /*! \brief Pointer to auto white balance filter.
   */
  Q_PROPERTY(AutoWhiteBalanceFilter* autoWhiteBalance READ autoWhiteBalance CONSTANT)

  /*! \brief Pointer to color-correction filter.
   */
  Q_PROPERTY(ColorCorrectionFilter* colorCorrection READ colorCorrection CONSTANT)

  /*! \brief Private constructor. SourcePipeline instances are created through VideoSource instances.
   *  \param imageFilter Pointer to image filters instance that should be used.
   *  \param parent Optional parent of this QObject.
   */
  explicit SourcePipeline(std::shared_ptr<image_filters::ImageFilter> imageFilter, QObject* parent = 0);

public:

  /*! \brief Defines default video pipeline configuration.
   */
  enum SourcePipelineType
  {
    DownwardFacingCamera = 0x00, /*!< The High Resolution camera close to the projector mirror that faces the Mat. */
    ForwardFacingCamera = 0x01, /*!< The Webcam located in the main monitor that faces the user. */
    SproutCamera = 0x02, /*!< The standalone High Resolution camera from SproutCamera device. */
    PrimaryDesktop = 0x10, /*!< The desktop of the primary monitor. */
    MatDesktop = 0x11, /*!< The desktop being presented by the projector on the Mat. */
    SecondaryDesktop = 0x12, /*!< A secondary desktop from a Monitor connected using the HDMI output. */
    OrbbecRGB = 0x20 /*!< The 3D camera located close to the High Resolution camera. */
  };

  Q_ENUM(SourcePipelineType)

  /*! \brief Destroys this instance.
   */
  virtual ~SourcePipeline();

  /*! \brief Sets the new configuration.
   *  \details This method has to be called before pipeline is used, otherwise it returns an error.
   *  \param configuration New configuration to be used.
   */
  Q_INVOKABLE void setConfiguration(const video::source::SourcePipelineConfig& configuration);

  /*! \brief Returns the current pipeline configuration of this source.
   *  \return The current configuration.
   */
  Q_INVOKABLE video::source::SourcePipelineConfig configuration();

  /*! \brief Returns if this input source is enabled.
   *  \return True if enabled, false otherwise.
   */
  Q_INVOKABLE bool enabled();

  /*! \brief Sets if this input source is enabled.
   *  \param enabled Value indicating if this input source should be enabled.
   */
  Q_INVOKABLE void setEnabled(bool enabled);

  /*! \brief Returns image size after all enhancement filters before entering compositor.
   *  \return Final size of this source.
   */
  Q_INVOKABLE QSize size();

  /*! \brief Returns name of this input source pipeline.
   *  \return String with the name of this pipeline.
   */
  Q_INVOKABLE QString name();

  /*! \brief Returns current zoom/pan viewport.
   *  \details Units are a fraction of the image size. They are in the (0,0) to (1,1) range, where (0,0) represents lower
   *           left corner and (1,1) represents the upper right corner of image rectangle.
   * \return The current zoom/pan viewport.
   */
  Q_INVOKABLE QRectF viewport();

  /*! \brief Sets the new value of the viewport for this source pipeline.
   *  \param viewport Viewport coordinates in fractions of image size.
   *  \sa viewport()
   */
  Q_INVOKABLE void setViewport(QRectF viewport);

  /*! \brief Returns destination coordinates for this source.
   *  \details Units are a fraction of the image size. They are in the (0,0) to (1,1) range, where (0,0) represents lower
   *           left corner and (1,1) represents the upper right corner of image rectangle.
   *  \return The destination coordinates.
   */
  Q_INVOKABLE QRectF destinationRectangle();

  /*! \brief Sets the new value of the destination rectangle for this source pipeline.
   *  \param destinationRectangle Destination rectangle using fractions of image size.
   *  \sa destinationRectangle()
   */
  Q_INVOKABLE void setDestinationRectangle(QRectF destinationRectangle);

  /*! \brief Captures the next video frame from this source pipeline.
   *  \details Please note that since this is capturing only a single input source of the whole pipeline, it is the caller's
   *           responsiblity to fill out calibration data for the returned sensor data.
   *  \details This method of capture is supported on all types of sources.
   */
  Q_INVOKABLE sensordata::SensorData captureVideoFrame();

  /*! \brief Captures next still frame from this source pipeline.
   *  \details Please note that since this is capturing only a single input source of the whole pipeline, it is the caller's
   *           responsiblity to fill out the calibration data for the returned sensor data.
   *  \details This method of capture is supported only on capture sources that supports the still capture method.
   *  \exception InvalidOperationException Thrown when this source doesn't support still capture.
   */
  Q_INVOKABLE sensordata::SensorData captureStillFrame();

  /*! \brief Returns the pointer to the illumination-correction filter.
   *  \details Illumination-correction filter needs to be included in the pipeline (property
   *           SourcePipelineConfig::illuminationCorrection.included) otherwise this method returns nullptr.
   *  \remarks The filters are recreated between restarts of the pipeline so results of this method should not be stored.
   *  \return The illumination filter associated with current execution.
   */
  Q_INVOKABLE IlluminationCorrectionFilter* illuminationCorrection();

  /*! \brief Returns the pointer to the auto white balance filter.
   *  \details Illumination correction filter needs to be included in the pipeline (property
   *           SourcePipelineConfig::autoWhiteBalance.included), otherwise this method returns nullptr.
   *  \remarks The filters are recreated between restarts of the pipeline so results of this method should not be stored.
   *  \return The auto white balance filter associated with current execution.
   */
  Q_INVOKABLE AutoWhiteBalanceFilter* autoWhiteBalance();

  /*! \brief Returns the pointer to the color-correction filter.
   *  \details Color-correction filter needs to be included in the pipeline (property
   *           SourcePipelineConfig::colorCorrection.included) otherwise this method returns nullptr.
   *  \remarks The filters are recreated between restarts of the pipeline so results of this method should not be stored.
   *  \return The color-correction filter associated with current execution.
   */
  Q_INVOKABLE ColorCorrectionFilter* colorCorrection();

  /*! \brief Returns the pointer to the combined OpenGL filter.
   *  \remarks The filters are recreated between restarts of the pipeline so results of this method should not be stored.
   *  \return The combined OpenGL filter associated with current execution.
   */
  Q_INVOKABLE CombinedOpenGLFilter* combinedOpenGLFilter();

  /*! \brief Allows to set frame-grabber buffer that will receive raw data from FrameGrabber filter.
   *  \details This method has to be called before the video pipeline is started.
   *           It is the caller's responsibility to allocate and deallocate the buffer to the proper size to accomodate raw frame data.
   *  \param buffer Pointer to a valid buffer with appropriate size.
   */
  void setFrameGrabberBuffer(uchar* buffer);

Q_SIGNALS:

  /*! \brief Signal emitted when this source pipeline changes its enabled status.
   *  \param enabled New value of isEnabled status.
   */
  void enabledChanged(bool enabled);

  /*! \brief Signal emitted when the viewport coordinates of this source pipeline has changed.
   *  \param viewport New viewport coordinates.
   */
  void viewportChanged(QRectF viewport);

  /*! \brief Signal emitted when the destination rectangle of this source pipeline has changed.
   *  \param destinationRectangle New destination rectangle.
   */
  void destinationRectangleChanged(QRectF destinationRectangle);

  /*! \brief Signal emitted when the image size of this input pipeline has changed.
   *  \param size New image size.
   */
  void sizeChanged(QSize size);

  /*! \brief Signal emitted when the frame buffer from video pipeline was updated.
   *  \details _**Warning**_: This is a blocking call to the video pipeline, so any operation performed by a consumer of
   *           this signal should be as fast as possible in order not to block processing.
   * \param sourceIndex Index of SourcePipeline that produced this frame.
   * \param size Size of the image.
   * \param dataSize Size of the data.
   */
  void frameBufferReady(int sourceIndex, const QSize size, int dataSize);

private:

  friend class VideoPipelinePrivate;
  Q_DECLARE_PRIVATE(SourcePipeline)
  QScopedPointer<SourcePipelinePrivate> const d_ptr;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_SOURCEPIPELINE_H_
