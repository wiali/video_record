#include "video_source/sourcepipeline.h"

#include <QDateTime>
#include <QMetaEnum>
#include <QSharedMemory>

#include <memory>

#include "video_source/private/sourcepipeline_p.h"

namespace video {
namespace source {

/***********************************************************************************/

SourcePipeline::SourcePipeline(std::shared_ptr<image_filters::ImageFilter> imageFilter,
                               QObject* parent)
    : QObject(parent), d_ptr(new SourcePipelinePrivate(imageFilter, this)) {
    static struct Initialize {
      Initialize() {
        // Required for correct cross-thread signal propagation

        qRegisterMetaType<video::source::SourcePipeline::SourcePipelineType>();
      }
    } initialize;
}

/***********************************************************************************/

SourcePipeline::~SourcePipeline() {}

/***********************************************************************************/

bool SourcePipeline::enabled() {
  Q_D(SourcePipeline);
  return d->enabled();
}

/***********************************************************************************/

void SourcePipeline::setConfiguration(const SourcePipelineConfig& configuration) {
  Q_D(SourcePipeline);
  d->setConfiguration(configuration);
}

/***********************************************************************************/

SourcePipelineConfig SourcePipeline::configuration() {
  Q_D(SourcePipeline);
  return d->configuration();
}

/***********************************************************************************/

QString SourcePipeline::name() {
  Q_D(SourcePipeline);
  return d->name();
}

/***********************************************************************************/

QRectF SourcePipeline::destinationRectangle() {
  Q_D(SourcePipeline);
  return d->destinationRectangle();
}

/***********************************************************************************/

void SourcePipeline::setDestinationRectangle(QRectF destinationRectangle) {
  Q_D(SourcePipeline);
  d->setDestinationRectangle(destinationRectangle);
}

/***********************************************************************************/

QSize SourcePipeline::size() {
  Q_D(SourcePipeline);
  return d->size();
}

/***********************************************************************************/

sensordata::SensorData SourcePipeline::captureVideoFrame() {
  Q_D(SourcePipeline);
  return d->captureVideoFrame();
}

/***********************************************************************************/

void SourcePipeline::setEnabled(bool enabled) {
  Q_D(SourcePipeline);
  d->setEnabled(enabled);
}

/***********************************************************************************/

QRectF SourcePipeline::viewport() {
  Q_D(SourcePipeline);
  return d->viewport();
}

/***********************************************************************************/

void SourcePipeline::setViewport(QRectF viewport) {
  Q_D(SourcePipeline);
  return d->setViewport(viewport);
}

/***********************************************************************************/

IlluminationCorrectionFilter* SourcePipeline::illuminationCorrection() {
  Q_D(SourcePipeline);
  return d->illuminationCorrection();
}

/***********************************************************************************/

AutoWhiteBalanceFilter* SourcePipeline::autoWhiteBalance() {
  Q_D(SourcePipeline);
  return d->autoWhiteBalance();
}

/***********************************************************************************/

CombinedOpenGLFilter* SourcePipeline::combinedOpenGLFilter() {
  Q_D(SourcePipeline);
  return d->combinedOpenGLFilter();
}

/***********************************************************************************/

ColorCorrectionFilter* SourcePipeline::colorCorrection() {
  Q_D(SourcePipeline);
  return d->colorCorrection();
}

/***********************************************************************************/

void SourcePipeline::setFrameGrabberBuffer(uchar* buffer) {
  Q_D(SourcePipeline);
  d->setFrameGrabberBuffer(buffer);
}

/***********************************************************************************/

sensordata::SensorData SourcePipeline::captureStillFrame() {
  Q_D(SourcePipeline);
  return d->captureStillFrame();
}

}  // namespace source
}  // namespace video
