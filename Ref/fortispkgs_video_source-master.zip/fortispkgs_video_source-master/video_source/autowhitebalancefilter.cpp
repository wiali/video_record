#include "video_source/autowhitebalancefilter.h"

#include "video_source/private/autowhitebalancefilter_p.h"

namespace video {
namespace source {

/******************************************************************************/

AutoWhiteBalanceFilter::AutoWhiteBalanceFilter(
    ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter, QObject *parent)
    : QObject(parent), d_ptr(new AutoWhiteBalanceFilterPrivate(index, imageFilter, this)) {}

/******************************************************************************/

AutoWhiteBalanceFilter::~AutoWhiteBalanceFilter() {}

/******************************************************************************/

bool AutoWhiteBalanceFilter::enabled() {
  Q_D(AutoWhiteBalanceFilter);
  return d->enabled();
}

/******************************************************************************/

void AutoWhiteBalanceFilter::setEnabled(bool enabled) {
  Q_D(AutoWhiteBalanceFilter);
  d->setEnabled(enabled);
}

}  // namespace source
}  // namespace video
