/*! \file videopipelinestatemismatchexception.h
 *  \brief Defines the exception thrown when the video pipeline fails to move to another state.
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_VIDEOPIPELINESTATEMISMATCHEXCEPTION_H_
#define VIDEO_SOURCE_VIDEOPIPELINESTATEMISMATCHEXCEPTION_H_

#include <QException>
#include <QMetaEnum>
#include <QObject>

#include "video_source/videopipeline.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief This exception is thrown when the video pipeline fails to move to another state.
 */
class VideoPipelineStateMismatchException
    : public QException
{
public:
  /*! \brief Constructs a new exception using the supplied parameters.
   *  \param currentState Current pipeline state.
   *  \param expectedState Expected pipeline state.
   *  \param operation Name of operation where the state was checked.
   */
  VideoPipelineStateMismatchException(VideoPipeline::VideoPipelineState currentState,
                                      VideoPipeline::VideoPipelineState expectedState,
                                      const QString& operation)
    : m_currentState(currentState)
    , m_expectedState(expectedState)
    , m_operation(operation)
  {}

  /*! \brief Returns the current pipeline state.
   *  \return Current pipeline state.
   */
  VideoPipeline::VideoPipelineState currentState() const  { return m_currentState; }

  /*! \brief Returns the expected pipeline state.
   *  \return Expected pipeline state.
   */
  VideoPipeline::VideoPipelineState expectedState() const { return m_expectedState; }

  /*! \brief Returns the name of operation where state was checked.
   *  \return QString describing operation.
   */
  QString operation() const { return m_operation; }

  /*! \brief Raises this exception.
   */
  void raise() const { throw *this; }

  /*! \brief Returns a cloned exception.
   *  \return Pointer to new instance that's a copy of this one.
   */
  VideoPipelineStateMismatchException* clone() const
  {
    return new VideoPipelineStateMismatchException(*this);
  }

  /*! \brief Returns the description of this exception.
   *  \return Exception description as C-string.
   */
  virtual char const* what() const
  {
    auto metaEnum = QMetaEnum::fromType<VideoPipeline::VideoPipelineState>();
    auto expectedStateName = QString(metaEnum.valueToKey(static_cast<int>(expectedState())));
    auto currentStateName = QString(metaEnum.valueToKey(static_cast<int>(currentState())));

    return QString(
               "Video pipeline state %1 doesn't match expected state %2 while performing operation "
               "%3")
        .arg(currentStateName)
        .arg(expectedStateName)
        .arg(operation())
        .toStdString()
        .c_str();
  }

protected:

  /*! \brief Current state. */
  VideoPipeline::VideoPipelineState m_currentState;

  /*! \brief Expected state. */
  VideoPipeline::VideoPipelineState m_expectedState;

  /*! \brief Operation where state was checked. */
  QString m_operation;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_VIDEOPIPELINESTATEMISMATCHEXCEPTION_H_
