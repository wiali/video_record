/*! \file colorcorrectionfilterconfig.h
 *  \brief Contains the definition of the color-correction filter parameters.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_COLORCORRECTIONFILTERCONFIG_H_
#define VIDEO_SOURCE_COLORCORRECTIONFILTERCONFIG_H_

#include <QDebug>
#include <QGenericMatrix>
#include <QObject>

#include "video_source/genericfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired illumination-correction filter parameters.
 */
class VIDEO_PIPELINE_API ColorCorrectionFilterConfig
    : public GenericFilterConfig
{
  Q_GADGET
  Q_PROPERTY(QString lampOnCalibrationDatasetName MEMBER lampOnCalibrationDatasetName)
  Q_PROPERTY(QString lampOffCalibrationDatasetName MEMBER lampOffCalibrationDatasetName)

public:
  /*! \brief Creates a default ColorCorrectionFilterConfig.
   *  \details The default configuration is invalid and should not be used as-is.
   */
  ColorCorrectionFilterConfig() {}

  /*! \brief Calibration color-correction data name for Lamp On.
   */
  QString lampOnCalibrationDatasetName;

  /*! \brief Calibration color-correction data name for Lamp Off.
   */
  QString lampOffCalibrationDatasetName;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if ColorCorrectionFilterConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::ColorCorrectionFilterConfig& lhs,
                         const video::source::ColorCorrectionFilterConfig& rhs)
{
  return (static_cast<const video::source::GenericFilterConfig&>(lhs) ==
              static_cast<const video::source::GenericFilterConfig&>(rhs) &&
          lhs.lampOnCalibrationDatasetName == rhs.lampOnCalibrationDatasetName &&
          lhs.lampOffCalibrationDatasetName == rhs.lampOffCalibrationDatasetName);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if ColorCorrectionFilterConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::ColorCorrectionFilterConfig& lhs,
                         const video::source::ColorCorrectionFilterConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::ColorCorrectionFilterConfig& obj)
{
  debug << static_cast<const video::source::GenericFilterConfig&>(obj) << "Lamp on"
        << obj.lampOnCalibrationDatasetName << "Lamp Off" << obj.lampOffCalibrationDatasetName;
  return debug;
}

#endif  // VIDEO_SOURCE_COLORCORRECTIONFILTERCONFIG_H_
