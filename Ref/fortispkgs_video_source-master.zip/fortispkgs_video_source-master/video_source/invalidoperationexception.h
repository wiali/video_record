/*! \file invalidoperationexception.h
 *  \brief Defines the exception thrown when the requested operation cannot be executed.
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_INVALIDOPERATIONEXCEPTION_H_
#define VIDEO_SOURCE_INVALIDOPERATIONEXCEPTION_H_

#include <QException>
#include <QObject>

#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief This exception is thrown when the requested operation cannot be executed.
 */
class InvalidOperationException
    : public QException
{
public:
  /*! \brief Constructs a new exception using the supplied parameters.
   *  \param message Error message detailing the exception.
   */
  explicit InvalidOperationException(const QString& message)
    : m_message(message)
  {}

  /*! \brief Returns the error message.
   *  \return QString with the message passed to the constrcutor.
   */
  QString message() const { return m_message; }

  /*! \brief Raises this exception.
   */
  void raise() const { throw * this; }

  /*! \brief Returns a cloned exception.
   *  \return Pointer to a new instance that is a copy of this one.
   */
  InvalidOperationException* clone() const { return new InvalidOperationException(*this); }

  /*! \brief Returns the description of this exception.
   *  \return Exception description as C-string.
   */
  virtual char const* what() const { return message().toStdString().c_str(); }

protected:

  /*! \brief Error message. */
  QString m_message;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_INVALIDOPERATIONEXCEPTION_H_
