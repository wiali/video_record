/*! \file autowhitebalancefilter.h
 *  \brief Contains implementation of auto white balance filter.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_AUTOWHITEBALANCEFILTER_H_
#define VIDEO_SOURCE_AUTOWHITEBALANCEFILTER_H_

#include <QObject>
#include <QScopedPointer>
#include <memory>

#include "video_source/videopipeline_api.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

class AutoWhiteBalanceFilterPrivate;

template <class AutoWhiteBalanceFilter>
struct NizzaTaskDeleter;

/*! \brief Uses auto white balance algorithm to enhance the image passing through video pipeline.
 */
class VIDEO_PIPELINE_API AutoWhiteBalanceFilter
    : public QObject
{
  Q_OBJECT

  /*! \brief Property indicating if this filter is enabled.
   */
  Q_PROPERTY(bool enabled READ enabled WRITE setEnabled NOTIFY enabledChanged)

public:

  /*! \brief Destroys this instance.
   */
  virtual ~AutoWhiteBalanceFilter();

  /*! \brief Returns if this filter is enabled or not.
   *  \return True if enabled, false otherwise.
   */
  bool enabled();

Q_SIGNALS:

  /*! \brief Signal emitted whenever filter is enabled or disabled.
   *  \param enabled Indicates if this filter is enabled or not.
   */
  void enabledChanged(bool enabled);

public Q_SLOTS:

  /*! \brief Sets if this filter is enabled or not.
   *  \param enabled New value indicating if this filter is enabled or not.
   */
  void setEnabled(bool enabled);

private:

  friend class SourcePipelinePrivate;
  template <class AutoWhiteBalanceFilter>
  friend struct NizzaTaskDeleter;

  Q_DECLARE_PRIVATE(AutoWhiteBalanceFilter)
  QScopedPointer<video::source::AutoWhiteBalanceFilterPrivate> d_ptr;

  explicit AutoWhiteBalanceFilter(ulong index,
                                  std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                  QObject *parent = 0);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_AUTOWHITEBALANCEFILTER_H_
