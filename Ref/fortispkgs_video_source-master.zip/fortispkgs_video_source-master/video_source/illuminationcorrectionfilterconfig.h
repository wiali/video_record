/*! \file illuminationcorrectionfilterconfig.h
 *  \brief Contains the definition of the illumination-correction filter parameters.
 *  \date November, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTERCONFIG_H_
#define VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTERCONFIG_H_

#include <QDebug>
#include <QGenericMatrix>
#include <QObject>

#include "video_source/genericfilterconfig.h"
#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired illumination-correction filter parameters.
 */
class VIDEO_PIPELINE_API IlluminationCorrectionFilterConfig
    : public GenericFilterConfig
{
  Q_GADGET
  Q_PROPERTY(bool isAutoWhiteBalanceEnabled MEMBER isAutoWhiteBalanceEnabled)
  Q_PROPERTY(QString calibrationDatasetName MEMBER calibrationDatasetName)

public:

  /*! \brief Creates a default IlluminationCorrectionFilterConfig.
   *  \details By default isAutoWhiteBalanceEnabled is false and calibrationDatasetName is empty.
   */
  IlluminationCorrectionFilterConfig() {}

  /*! \brief Indicates if auto white balance should be executed as well.
   */
  bool isAutoWhiteBalanceEnabled;

  /*! \brief Calibration illumination data name.
   */
  QString calibrationDatasetName;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if IlluminationCorrectionFilterConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::IlluminationCorrectionFilterConfig& lhs,
                         const video::source::IlluminationCorrectionFilterConfig& rhs) {
  return (static_cast<const video::source::GenericFilterConfig&>(lhs) ==
              static_cast<const video::source::GenericFilterConfig&>(rhs) &&
          lhs.isAutoWhiteBalanceEnabled == rhs.isAutoWhiteBalanceEnabled &&
          lhs.calibrationDatasetName == rhs.calibrationDatasetName);
}

/*! Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if IlluminationCorrectionFilterConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::IlluminationCorrectionFilterConfig& lhs,
                         const video::source::IlluminationCorrectionFilterConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::IlluminationCorrectionFilterConfig& obj)
{
  debug << static_cast<const video::source::GenericFilterConfig&>(obj) << "with auto white balance"
        << obj.isAutoWhiteBalanceEnabled << obj.calibrationDatasetName;
  return debug;
}

#endif  // VIDEO_SOURCE_ILLUMINATIONCORRECTIONFILTERCONFIG_H_
