/*! \file desktopcapturesourceconfig.h
 *  \brief Contains the definition of the Desktop input source parameters class.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_DESKTOPCAPTURESOURCECONFIG_H_
#define VIDEO_SOURCE_DESKTOPCAPTURESOURCECONFIG_H_

#include <QDebug>
#include <QObject>
#include <QRect>
#include <QString>

#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Contains the configuration for the Desktop input source.
 *  \details Specify the content to capture (particular area, given screen, window, etc) and the refresh delay.
 */
class VIDEO_PIPELINE_API DesktopSourceConfig
{
  Q_GADGET
  Q_PROPERTY(QRect captureArea MEMBER captureArea)
  Q_PROPERTY(int screen MEMBER screen)
  Q_PROPERTY(QString windowName MEMBER windowName)
  Q_PROPERTY(QString className MEMBER className)
  Q_PROPERTY(int windowSizeRefreshDelay MEMBER windowSizeRefreshDelay)

public:

  /*! \brief Creates a default DesktopSourceConfig.
   *  \details The default configuration is invalid and should not be used as is.
   */
  DesktopSourceConfig() : windowSizeRefreshDelay(0), screen(-1) {}

  /*! \brief Specifies an area to be captured.
   *  \details This value is overwritten if a valid screen index is supplied.
   *           It is ignored if windowName is supplied.
   */
  QRect captureArea;

  /*! \brief Name of a window to capture.
   *  \details If this value is empty then desktop is captured; otherwise window with given name is
   *           captured and captureArea is ignored.
   */
  QString windowName;

  /*! \brief Window class name to capture.
   *  \details This value is optional and can be used to specify capture window with more detail.
   *           See https://msdn.microsoft.com/en-us/library/windows/desktop/ms633574(v=vs.85).aspx.
   */
  QString className;

  /*! \brief Defines refresh delay in milliseconds for desktop window capture.
   *  \details The default is zero, which means that size monitoring is disabled for performance reasons.
   */
  int windowSizeRefreshDelay;

  /*! \brief Defines screen index to capture.
   *  \details This will set captureArea using the system screen number as reported by the OS.
   */
  int screen;
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if DesktopSourceConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::DesktopSourceConfig& lhs,
                         const video::source::DesktopSourceConfig& rhs)
{
  return (lhs.captureArea == rhs.captureArea && lhs.className == rhs.className &&
          lhs.windowName == rhs.windowName &&
          lhs.windowSizeRefreshDelay == rhs.windowSizeRefreshDelay && lhs.screen == rhs.screen);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if DesktopSourceConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::DesktopSourceConfig& lhs,
                       const video::source::DesktopSourceConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::DesktopSourceConfig& obj)
{
  debug << obj.captureArea << "[" << obj.screen << "]"
        << "window:" << obj.windowName << "[class " << obj.className << "]";
  return debug;
}

#endif  // VIDEO_SOURCE_DESKTOPCAPTURESOURCECONFIG_H_
