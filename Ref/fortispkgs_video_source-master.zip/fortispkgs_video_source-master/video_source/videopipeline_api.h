/*! \file videopipeline_api.h
 *  \brief Contains the definition of the VIDEO_PIPELINE_API macro.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_VIDEOPIPELINE_API_H_
#define VIDEO_SOURCE_VIDEOPIPELINE_API_H_

#include <QtCore/qglobal.h>

#if defined(VIDEO_SOURCE_LIBRARY)
#define VIDEO_PIPELINE_API Q_DECL_EXPORT
#else
/*! \brief Defines if classes should be exported. */
#define VIDEO_PIPELINE_API Q_DECL_IMPORT
#endif

#endif  // VIDEO_SOURCE_VIDEOPIPELINE_API_H_
