/*! \file autowhitebalancefilter_p.cpp
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include "video_source/private/autowhitebalancefilter_p.h"

namespace video {
namespace source {

/*!
 * \brief The AutoWhiteBalanceFilter::State struct contains internal auto white balance filter data.
 */
struct AutoWhiteBalanceFilterPrivate::State {
 public:
  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;
};

AutoWhiteBalanceFilterPrivate::AutoWhiteBalanceFilterPrivate(
    ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter,
    AutoWhiteBalanceFilter* parent)
    : OptionalImageFilterNizzaTask(QString("%1:Auto white balance").arg(index).toStdString(),
                                   imageFilter),
      q_ptr(parent) {
  m_state = std::make_unique<State>();
}

/***********************************************************************************/

Mir* AutoWhiteBalanceFilterPrivate::process(Mir* in) {
  MirFormat format = in->format;
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();
  auto imageSize = m_state->imageSize;
  m_state->mutex.unlock();

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));
    m_state->mutex.unlock();
  }

  image_filters::SourceImage sourceImage{m_state->imageSize, QImage::Format_RGB888, inputBuffer};

  Mir* outputImage = new Mir(w, h, format);
  outputImage->timestamp = in->timestamp;

  auto outputBuf = outputImage->getBuffer(Mir::imageBuffer);

  m_imageFilter->autoWhiteBalance(sourceImage, outputBuf);

  return outputImage;  // continue
}

}  // namespace source
}  // namespace video
