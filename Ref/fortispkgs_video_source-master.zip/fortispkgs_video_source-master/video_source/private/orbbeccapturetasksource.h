/*! \file orbbeccapturetasksource.h
 *  \brief Contains implementation of orbbec capture as Nizza task source.
 *  \date June, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef ORBBECCAPTURETASKSOURCE_H
#define ORBBECCAPTURETASKSOURCE_H

#include <NizzaBeans.h>
#include <QSharedPointer>

class OrbbecCapture;

#include "OpenNI.h"
#include <QSharedDataPointer>

class OrbbecCaptureState {
protected:
    uint32 m_numToSend, m_numSent;

    int m_prevWidth, m_prevHeight;

    unsigned int timerResolution;

    void start();
    void stop();

    Media_Image_Raw* captureImage();

    friend class OrbbecCapture;

    OrbbecCaptureState(OrbbecCapture *ownr, const std::string &name);
    virtual ~OrbbecCaptureState();

    // All this is for frameRate timing control
    float             frameRate;
    Rock::Thread*     timerThread;

    Rock::Semaphore   timerStart;
    float             timerRate;
    uint32            timerMilliseconds;
    std::deque<int64> timerTimes;  // history of production times
    void              issueScheduleNextProduction();
    OrbbecCapture* const owner;

    /*!
    * \brief Initializes OpenNI and the device on the system that supports it. In this case the Orbbec camera.
    * \return True if successful, false otherwise. Method error() will provide extended error information.
    */
    void initialize();

    /*!
    * \brief initOpenNI - Initializes OpenNI library/SDK.
    * \return True if successful. False otherwise.
    */
    void initOpenNI();

    /*!
    * \brief initDevice - Initializes the device (Orbbec camera) associated with OpenNI
    * \return
    */
    void initDevice();

    /*!
    * \brief Closes the open handle to device and shuts down OpenNI
    * \return True if successful, false otherwise
    */
    void shutdown();

    /*!
    * \brief m_initialized - True if OpennNI has been initialized, false otherwise
    */
    bool m_initialized;

    /*!
    * \brief m_device - OpenNI device handle
    */
    openni::Device m_device;

    QSharedPointer<openni::VideoStream> m_stream;

public:
    void              timerThreadMain();
};

class OrbbecCapture : public Nizza::TaskSource
{
public:
    OrbbecCapture(const std::string& name); //constructor
protected:
    OrbbecCaptureState* state; //internal structure

    OrbbecCapture(const std::string& name, OrbbecCaptureState* st); //constructor

public:
    void produceFrame();

protected:
    void conclude();
    void commence();

    // Set maximum capture rate in frames per second
    // Default of 0.0 results in running as fast as possible
    // Rate of -1.0 means only produce when triggered by produceFrame
    void setMaxCaptureRate(float rate = 0.0);

    bool produce(Nizza::Output& output);

    ~OrbbecCapture();

    friend class OrbbecCaptureState;
};

#endif // ORBBECCAPTURETASKSOURCE_H
