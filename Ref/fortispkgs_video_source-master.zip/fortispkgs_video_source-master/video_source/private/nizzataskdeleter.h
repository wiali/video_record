/*! \file nizzataskdeleter.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_NIZZATASKDELETER_H_
#define VIDEO_SOURCE_PRIVATE_NIZZATASKDELETER_H_

namespace video {
namespace source {

/*!
 * \brief Helper template to delete instances of Nizza filters.
 */
template <typename T>
struct NizzaTaskDeleter {
  /*!
   * \brief operator () Used to delete std::unique_ptr pointers.
   * \param sink Pointer to unmanaged instance.
   */
  void operator()(T *sink) const;

  /*!
   * \brief operator () Used to delete QScopedPointer pointers.
   * \param sink Pointer to unmanaged instance.
   */
  static void cleanup(T *sink);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_NIZZATASKDELETER_H_
