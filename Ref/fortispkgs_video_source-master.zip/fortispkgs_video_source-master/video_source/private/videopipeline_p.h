/*! \file videopipeline_p.h
 *  \brief Contains definition of video source class plug-in package super cool.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_VIDEOPIPELINE_P_H_
#define VIDEO_SOURCE_PRIVATE_VIDEOPIPELINE_P_H_

#include <QList>
#include <QMap>
#include <QObject>
#include <QPointer>
#include <QString>
#include <QUuid>

#include <calibration_data.h>
#include <sensor_data.h>

#include <opencv2/opencv.hpp>

#include <DSSource.h>
#include <DSVideoSink.h>
#include <Nizza.h>
#include <NizzaBeans.h>
#include <NizzaMonitor.h>

#include <atomic>
#include <chrono>
#include <memory>
#include <string>

#include <settings.h>

#include "video_source/sourcepipeline.h"
#include "video_source/videopipeline.h"
#include "video_source/videopipeline_api.h"

#include "video_source/private/nizzataskdeleter.h"
#include "video_source/private/nullsinktask.h"

namespace video {
namespace source {

/*!
 * \brief The VideoPipeline class wraps single Nizza video pipeline and manages it's lifetime.
 */
class VideoPipelinePrivate : public QObject {
  Q_OBJECT
  Q_DECLARE_PUBLIC(VideoPipeline)

  VideoPipeline* const q_ptr;

 public:
  /*! \brief Creates the instance of VideoSource.
   *  \details Not exposed and internally used by the VideoSource Factory.
   */
  explicit VideoPipelinePrivate(VideoPipeline* parent);

  /*! \brief Destroys the instance of VideoSource. */
  virtual ~VideoPipelinePrivate();

  /*! \brief Initializes the pipeline with given configuration.
   *  \param configuration Video pipeline configuration object.
   */
  void setOutputSinkConfiguration(const video::source::OutputVideoSinkConfig& configuration);

  /*! \brief Starts video pipeline.
   *  \details Starts existing video pipeline (Nizza graph). The pipeline must be in "stopped"
   * state.
   *  This is blocking function.
   *  \returns Boolean to indicate success or failure
   */
  void start();

  /*! \brief Starts video pipeline.
   *  \details Stops Nizza pipeline.
   */
  void stop();

  /*! \brief Get current configuration of Nizza pipeline.
   */
  video::source::OutputVideoSinkConfig outputSinkConfiguration() const;

  /*! \brief Get current state of Nizza pipeline.
   *  \details Returns current state, eg. "running", "stopped", "error".
   *  \returns String representing current state of video pipeline object
   */
  VideoPipeline::VideoPipelineState state();

  /*! \brief Captures a frame from video pipeline with all sensor data.   
   *  \param stillFrameSources Indicates which sources should use still frame capture method
   * (SourcePipeline::captureStillFrame). Remaining sources will use
   * video frame capture method (SourcePipeline::captureVideoFrame).
   *  \details Get a frame from each input source in pipeline.
   *  \return Capture result where the information will be stored.
   */
  QVector<sensordata::SensorData> capture(QStringList stillFrameSources);

  /*! \brief Returns list of configured input sources.
   */
  QVector<QSharedPointer<video::source::SourcePipeline>> sources();

  /*!
   * \brief Adds new input source with known configuration into video pipeline.
   * \param sourceType Known type of the input source.
   * \param resolution Known resolution of the input source.
   */
  QSharedPointer<video::source::SourcePipeline> addKnownSource(SourcePipeline::SourcePipelineType sourceType,
                                                               QSize resolution);

  /*!
   * \brief Adds new input source with configuration into video pipeline.
   * \param name Name of the new input source.
   * \param config Configuration of new input source.
   */
  QSharedPointer<video::source::SourcePipeline> addSource(
      const QString& name, video::source::SourcePipelineConfig config);

  /*!
   * \brief Removes input source from video pipeline.
   * \param name Name of the input source to remove.
   */
  void removeSource(const QString& name);

  /*!
   * \brief Returns the path to the log files.
   */
  QString logPath();

  /*!
   * \brief Sets new path to the log files.
   * \param logPath Path to the log files.
   */
  void setLogPath(const QString& logPath);

  /*!
   * \brief Returns known resolutions for given source type.
   * \param sourceType Known type of the input source.
   */
  QVector<QSize> knownResolutions(SourcePipeline::SourcePipelineType sourceType);

 protected:
  /*! \brief Indicates if Nizza was already started/
   */
  static std::atomic<bool> m_isNizzaStarted;

  /*! \brief Contains configuration of this video pipeline.
   */
  video::source::OutputVideoSinkConfig m_configuration;

  /*! \brief Contains video pipeline state.
   */
  std::atomic<VideoPipeline::VideoPipelineState> m_state;

  /*! \brief Nizza DirectShow output sink task.
   */
  std::unique_ptr<DSVideoSink, NizzaTaskDeleter<DSVideoSink>> m_dsVideoSink;

  /*! \brief Null sink task.
   */
  std::unique_ptr<NullSinkTask, NizzaTaskDeleter<NullSinkTask>> m_nullSink;

  /*! \brief Pointer to DirectShow video source Nizza task.
   */
  std::unique_ptr<DSSource, NizzaTaskDeleter<DSSource>> m_dsSource;

  /*! \brief Nizza GPU compositor task.
   *  \details Responsible for zoom/pan and combining multiple input streams into 1 output stream.
   */
  std::unique_ptr<CompositorGPU, NizzaTaskDeleter<CompositorGPU>> m_compositorGpu;

  /*! \brief Contains timestamp of last zoom/pan redraw.
   *  \details used to decide when output image should be re-drawn(during zoom/pan operations).
   */
  std::chrono::system_clock::time_point m_lastZoomPanRedraw;

  /*! \brief Pointer to Image filters library.
   */
  std::shared_ptr<image_filters::ImageFilter> m_imageFilters;

  /*! \brief Calibration Data structure.
   */
  calibration::CalibrationData m_calibrationData;

  /*! \brief Contains dictionary of all configured input source pipelines.
   */
  QList<QSharedPointer<SourcePipeline>> m_sources;

  /*! \brief Contains mapping between source pipeline and compositor pin number.
   */
  QHash<QString, uint32> m_sourceToCompositorPinMapping;

  /*!
   * \brief Contains path to the log files.
   */
  QString m_logPath;

  /*!
   * \brief Checks the time of last redraw and throttles the forced redraws in order to maintain
   * performance.
   */
  void tryPerformRedraw(QSharedPointer<SourcePipeline> source);

  /*! \brief Resets the video pipeline.
   */
  void reset();

  /*!
   * \brief Sets new state and emits the signal.
   * \param state New state.
   */
  void setState(const VideoPipeline::VideoPipelineState& state);

  /*!
   * \brief Checks if current pipeline state matches the expected state and reports error if not.
   * \param expectedState Expected state.
   * \param operation Name of the operation that is checking for state.
   */
  void verifyState(const VideoPipeline::VideoPipelineState& expectedState,
                   const QString& operation);

  /*! \brief Nizza graph stop callback.
   *  \details Calls by Nizza after graph was stopped (either because of an error or normal stop).
   *  \param callbackUserData Pointer to corresponding Impl object.
   *  \param hadError Indicates if Nizza pipeline encountered an error.
   *  \param errorString Nizza error string.
   *  \param errorCode Nizza error code.
   */
  static void concludeCallbackUserData(void* callbackUserData, bool hadError,
                                       const std::string& errorString, int errorCode);

  /*!
   * \brief Returns the instance of configured sink.
   */
  Nizza::Task* sink();

  /*! \brief Returns a valid CalibrationData instance.
   */
  const calibration::CalibrationData& calibrationData();

  /*!
   * \brief Contains reference to Nizza monitor.
   */
  std::unique_ptr<NizzaMonitor> m_nizzaMonitor;

  QHash<QString, QList<QMetaObject::Connection>> m_sourceConnectionMap;

  /*!
   * \brief Reads configuration of pipeline.
   * \param pipeline Pipeline identifier.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   */
  void readSourcePipelineConfiguration(const SourcePipeline::SourcePipelineType& pipeline, SourcePipelineConfig* config);

  /*!
   * \brief Reads input source configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   * \param sourceType Known type of the input source.
   */
  void readInputSourceConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                    const QString& pipelineName, SourcePipelineConfig* config, QSize resolution);

  /*!
   * \brief Reads keystone correction configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   * \param sourceType Known type of the input source.
   * \param resolution Resolution for determining calibration data.
   */
  void readKeystoneCorrectionConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                           const QString& pipelineName,
                                           SourcePipelineConfig* config, QSize resolution);

  /*!
   * \brief Reads illumination correction configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   * \param sourceType Known type of the input source.
   * \param resolution Resolution for determining calibration data.
   */
  void readIlluminationCorrectionConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                               const QString& pipelineName,
                                               SourcePipelineConfig* config, QSize resolution);

  /*!
   * \brief Reads sharpen filter configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   */
  void readSharpenConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                const QString& pipelineName, SourcePipelineConfig* config);

  /*!
   * \brief Reads auto white balance filter configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   */
  void readAutoWhiteBalanceConfiguration(const QString& pipelineName, SourcePipelineConfig* config);

  /*!
   * \brief Reads color correction configuration.
   * \param pipelineName Name of the pipeline.
   * \param config Reference to configuration object to which read data should be stored.
   * \param sourceType Known type of the input source.
   * \param resolution Resolution for determining calibration data.
   */
  void readColorCorrectionConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                        const QString& pipelineName, SourcePipelineConfig* config,
                                        QSize resolution);

  /*!
   * \brief Reads frame grabber filter configuration.
   * \param config Reference to configuration object to which read data should be stored.
   * \param pipelineName Name of the pipeline.
   */
  void readFrameGrabberConfiguration(const QString& pipelineName, SourcePipelineConfig* config);

  /*!
   * \brief Reads mirror filter configuration.
   * \param config Reference to configuration object to which read data should be stored.
   * \param pipelineName Name of the pipeline.
   * \param sourceType Known type of the input source.
   */
  void readMirrorConfiguration(SourcePipeline::SourcePipelineType sourceType,
                               const QString& pipelineName, SourcePipelineConfig* config);  

  /*!
   * \brief Reads still capture configuration.
   * \param config Reference to configuration object to which read data should be stored.
   * \param pipelineName Name of the pipeline.
   * \param sourceType Known type of the input source.
   */
  void readStillCaptureConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                     const QString& pipelineName, SourcePipelineConfig* config);

  /*!
   * \brief Returns settings object for video source.
   * \return
   */
  QSharedPointer<hp::fortis::Settings> settings(QString group);

 private slots:

  void onDsSourceIsEnabledChanged(QString sourceName, bool isEnabled);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_VIDEOPIPELINE_P_H_
