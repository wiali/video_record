/*! \file nullsinktask.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QDebug>

#include <NizzaBeans.h>

#include "video_source/private/nullsinktask.h"

namespace video {
namespace source {

static bool gVerbose = false;

/*!
 * \brief The AutoWhiteBalanceFilter::State struct contains internal auto white balance filter data.
 */
struct NullSinkTask::State {
 public:
  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;
};

NullSinkTask::NullSinkTask(std::string name, int sourceCount)
    : Task(name, "NullSink") {
  for (int i = 0; i < sourceCount; i++) {
    // Create input media pin
    addInputPin(stringf("image %d", i), "image", "Image_Raw");
  }

  m_state = std::make_unique<State>();
}

/***********************************************************************************/

void NullSinkTask::commence() {
  // do pre-streaming initialization
  if (gVerbose) Rock::Thread::logf("%s::commence: Entered.\n", name.c_str());
}

/***********************************************************************************/

void NullSinkTask::conclude() {
  // do post-streaming cleanup
  if (gVerbose) Rock::Thread::logf("%s::conclude: Entered.\n", name.c_str());
}

/***********************************************************************************/

bool NullSinkTask::process(const std::string&, const std::vector<Nizza::Media*>& media,
                           Nizza::Output&) {
  for (uint32 i = 0; i < media.size(); i++) {
    Nizza::endMediaUsage(media[i]);
  }

  return true;
}

}  // namespace source
}  // namespace video
