/*! \file finalframegrabbertask.cpp
 *  \brief Contains implementation of frame grabber task as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include "video_source/private/finalframegrabbertask.h"

#include <NizzaMedia.h>

namespace video {
namespace source {

/*!
 * \brief The FinalFrameGrabberTask::State struct contains internal frame grabber data.
 */
struct FinalFrameGrabberTask::State {
 public:
  /*!
   * \brief Frame buffer.
   */
  uchar *frameBuffer;

  /*!
   * \brief Size of the frame buffer.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  size_t bufferSize;

  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;

  /*! \brief Output format.
   */
  FinalFrameGrabberConfig::Format format;

  /*! \brief index Video source index for naming purposes.
   */
  int index;
};

FinalFrameGrabberTask::FinalFrameGrabberTask(
    ulong index, uchar *buffer, std::shared_ptr<image_filters::ImageFilter> imageFilter,
    const FinalFrameGrabberConfig &configuration, QObject *parent)
    : QObject(parent),
      OptionalImageFilterNizzaTask(QString("%1:Final Frame Grabber").arg(index).toStdString(),
                                   imageFilter) {
  m_state = std::make_unique<State>();

  m_state->index = index;
  m_state->format = configuration.format;
  m_state->frameBuffer = buffer;
}

/***********************************************************************************/

Mir *FinalFrameGrabberTask::process(Mir *in) {
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();

  auto imageSize = m_state->imageSize;
  auto format = m_state->format;
  auto index = m_state->index;
  auto bufferSize = m_state->bufferSize;
  auto frameBuffer = m_state->frameBuffer;

  m_state->mutex.unlock();

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));

    switch (format) {
      case FinalFrameGrabberConfig::BGR888:
      case FinalFrameGrabberConfig::RGB888:
        bufferSize = in->getBufferSize(Mir::imageBuffer);
        break;
      case FinalFrameGrabberConfig::BGR32:
        bufferSize = w * h * 4;
        break;
    }

    m_state->bufferSize = bufferSize;

    m_state->mutex.unlock();
  }

  switch (format) {
    case FinalFrameGrabberConfig::BGR888:
      // No change, just copy data
      memcpy(frameBuffer, inputBuffer, bufferSize);
      break;
    case FinalFrameGrabberConfig::RGB888: {
      // Swap B&R
      image_filters::SourceImage sourceImage{imageSize, QImage::Format_RGB888, inputBuffer};

      m_imageFilter->convertBGRtoRGB(sourceImage, frameBuffer);
      break;
    }
    case FinalFrameGrabberConfig::BGR32: {
      // Add alpha channel
      image_filters::SourceImage sourceImage{imageSize, QImage::Format_RGB888, inputBuffer};

      m_imageFilter->convertRGBtoRGBA(sourceImage, frameBuffer);
      break;
    }
  }

  emit frameBufferReady(index, imageSize, static_cast<int>(bufferSize));

  return in;
}

}  // namespace source
}  // namespace video
