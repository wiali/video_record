/*! \file sourcepipeline_p.cpp
 *  \brief Contains definition of source pipeline.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QDateTime>
#include <QJsonArray>
#include <QMetaEnum>
#include <QSharedMemory>

#include <string>
#include <vector>

#include "video_source/invalidconfigurationexception.h"
#include "video_source/invalidoperationexception.h"
#include "video_source/nizzaexception.h"

#include "video_source/private/autowhitebalancefilter_p.h"
#include "video_source/private/colorcorrectionfilter_p.h"
#include "video_source/private/illuminationcorrectionfilter_p.h"

#ifdef Q_OS_WIN
#include <windows.h>
#endif

#include "video_source/private/sourcepipeline_p.h"

void glfwErrorCallback(int error, const char* description)
{
    qCritical() << "GLFW error:" << error << description;
}

namespace video {
namespace source {

/**************************************************************************************************/

void DeleteImageData(void* data) {
  auto buffer = static_cast<unsigned char*>(data);
  delete buffer;
}

/***********************************************************************************/

SourcePipelinePrivate::SourcePipelinePrivate(
    std::shared_ptr<image_filters::ImageFilter> imageFilter, SourcePipeline* parent)
    : q_ptr(parent),
      m_enabled(true),
      m_lastTask(nullptr),
      m_imageFilters(imageFilter),
      m_viewport(QRectF(0, 0, 1, 1)),
      m_destinationRectangle(QRectF(0, 0, 1, 1))
#ifdef Q_OS_WIN
      ,
      m_desktopWindowHandle(nullptr)
      ,
      m_orbbecCapture(nullptr)
#endif
      ,
      m_frameGrabberBuffer(nullptr),
      m_touchmat(new proapi::touchmat::Touchmat) {
  connect(&m_windowSizeRefreshTimer, &QTimer::timeout,
          [this]() { setSize(retrieveWindowSize(false)); });
}

/***********************************************************************************/

SourcePipelinePrivate::~SourcePipelinePrivate() {
    reset();
}

/***********************************************************************************/

QSize SourcePipelinePrivate::retrieveWindowSize(bool throwException) {
  QSize result;

#ifdef Q_OS_WIN

  auto& className = m_configuration.desktopCaptureSource.className;
  auto& windowName = m_configuration.desktopCaptureSource.windowName;

  if (m_desktopWindowHandle == nullptr) {
    m_desktopWindowHandle =
        FindWindow(className.toStdWString().c_str(), windowName.toStdWString().c_str());
  }

  if (m_desktopWindowHandle == nullptr) {
    auto error = GetLastError();
    auto message = QString("Cannot find window with name %1 and class name %2. GetLastError = %3")
                       .arg(windowName)
                       .arg(className)
                       .arg(error);

    if (throwException) {
      throw InvalidConfigurationException(message);
    } else {
      qWarning() << this << message;
    }
  } else {
    RECT rect;

    if (GetWindowRect(m_desktopWindowHandle, &rect)) {
      qInfo() << this << "Window coordinates for" << windowName << className << "are" << rect.left
              << rect.top << rect.right << rect.bottom;

      result.setHeight(rect.bottom - rect.top);
      result.setWidth(rect.right - rect.left);
    } else {
      auto error = GetLastError();

      auto message = QString(
                         "Cannot retrieve window size for window with name %1 and class name %2. "
                         "GetLastError = %3")
                         .arg(windowName)
                         .arg(className)
                         .arg(error);

      if (throwException) {
        throw InvalidConfigurationException(message);
      } else {
        qWarning() << this << message;
      }
    }
  }
#elif
#error Not defined for other OSes yet
#endif

  return result;
}

/***********************************************************************************/

bool SourcePipelinePrivate::enabled() const { return m_enabled; }

/***********************************************************************************/

void SourcePipelinePrivate::setConfiguration(const SourcePipelineConfig& configuration) {
  if (m_lastTask != nullptr) {
    throw InvalidOperationException(tr("Cannot configure source pipeline after it was started."));
  } else {
    m_configuration = configuration;
  }
}

/***********************************************************************************/

SourcePipelineConfig SourcePipelinePrivate::configuration() const { return m_configuration; }

/***********************************************************************************/

QString SourcePipelinePrivate::name() const { return m_name; }

/***********************************************************************************/

void SourcePipelinePrivate::setName(const QString& name) { m_name = name; }

/***********************************************************************************/

QRectF SourcePipelinePrivate::destinationRectangle() { return m_destinationRectangle; }

/***********************************************************************************/

void SourcePipelinePrivate::setDestinationRectangle(QRectF destinationRectangle) {
  destinationRectangle = destinationRectangle.normalized();

  if (destinationRectangle != m_destinationRectangle) {
    m_destinationRectangle = destinationRectangle;
    Q_Q(SourcePipeline);

    emit q->destinationRectangleChanged(m_destinationRectangle);
  }
}

/***********************************************************************************/

void SourcePipelinePrivate::setSize(QSize size) {
  if (size != m_size) {
    m_size = size;

    Q_Q(SourcePipeline);
    emit q->sizeChanged(size);
  }
}

/***********************************************************************************/

QSize SourcePipelinePrivate::size() const { return m_size; }

/***********************************************************************************/

void SourcePipelinePrivate::setupKeystoneCorrection(
    unsigned long sourceIndex, const calibration::CalibrationData& calibrationData) {
  if (m_configuration.keystoneCorrection.included) {
    auto keystoneCorrection = m_configuration.keystoneCorrection;
    qInfo() << this << "Adding keystone correction filter";

    if (calibrationData.timeStamp == 0) {
      throw InvalidConfigurationException(
          "Calibration data are required for keystone correction but calibration was not "
          "performed yet.");
    }

    calibration::HomographyMatrix homography;

    if (keystoneCorrection.homographyMatrixName == "cameraFullResToHighResMat") {
      homography = calibrationData.cameraFullResToHighResMat;
    } else if (keystoneCorrection.homographyMatrixName == "cameraQtrResToHDVideoResMat") {
      homography = calibrationData.cameraQtrResToHDVideoResMat;
    } else {
      throw InvalidConfigurationException(QString("Homography matrix %1 is not supported")
                                              .arg(keystoneCorrection.homographyMatrixName));
    }

    QTransform matrix(static_cast<qreal>(homography.matrix(0,0)), static_cast<qreal>(homography.matrix(0,1)),
                      static_cast<qreal>(homography.matrix(0,2)), static_cast<qreal>(homography.matrix(1,0)),
                      static_cast<qreal>(homography.matrix(1,1)), static_cast<qreal>(homography.matrix(1,2)),
                      static_cast<qreal>(homography.matrix(2,0)), static_cast<qreal>(homography.matrix(2,1)),
                      static_cast<qreal>(homography.matrix(2,2)));

    QRect outputRect(0, 0, homography.destinationResolution.width(),
                     homography.destinationResolution.height());

    if (m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
        m_keystoneCorrectionFilter.reset(new KeystoneCorrectionFilter(
            sourceIndex, matrix, outputRect, keystoneCorrection.quality, m_imageFilters));
    } else {
        m_combinedOpenGLFilter->d_ptr->setupKeystoneCorrection(outputRect.size(), matrix, m_configuration.keystoneCorrection.quality);
        m_combinedOpenGLFilter->d_ptr->setKeystoneCorrection(true);
    }

    if (!m_configuration.deviceDimensions.isValid() && !m_configuration.deviceDimensions.isNull()) {
        // We know capture mat dimensions (white part) however capture contains more information
        // so we need to enlarge it proportionally so we get correct DPM when capturing

        const float inchesToMeters = 0.0254f;
        auto hardwareInfo = m_touchmat->hardwareInfo();

        QSizeF matDimensions(hardwareInfo.size.width, hardwareInfo.size.height);
        matDimensions *= inchesToMeters;

        qreal widthUnit = matDimensions.width() / outputRect.width();
        qreal heightUnit = matDimensions.height() / outputRect.height();

        m_configuration.deviceDimensions = QSizeF(widthUnit * homography.sourceResolution.width(),
                                                  heightUnit * homography.sourceResolution.height());
    }
  }
}

/***********************************************************************************/

void SourcePipelinePrivate::setupIlluminationCorrection(
    unsigned long sourceIndex, const calibration::CalibrationData& calibrationData) {
  if (m_configuration.illuminationCorrection.included) {
    qInfo() << this << "Adding illumination correction filter";

    if (calibrationData.timeStamp == 0) {
      throw InvalidConfigurationException(
          "Calibration data are required for illumination correction but calibration was not "
          "performed yet.");
    }

    QGenericMatrix<1, 6, float> illuminationCoefficients;

    illuminationCoefficients(0, 0) = static_cast<float>(calibrationData.illuminationData(0,0));
    illuminationCoefficients(1, 0) = static_cast<float>(calibrationData.illuminationData(1,0));
    illuminationCoefficients(2, 0) = static_cast<float>(calibrationData.illuminationData(2,0));
    illuminationCoefficients(3, 0) = static_cast<float>(calibrationData.illuminationData(3,0));
    illuminationCoefficients(4, 0) = static_cast<float>(calibrationData.illuminationData(4,0));
    illuminationCoefficients(5, 0) = static_cast<float>(calibrationData.illuminationData(5,0));


    m_illuminationCorrectionFilter.reset(new IlluminationCorrectionFilter(
        sourceIndex, m_configuration.illuminationCorrection.isAutoWhiteBalanceEnabled,
        illuminationCoefficients, m_imageFilters));

    if (m_combinedOpenGLFilter) {
        m_illuminationCorrectionFilter->m_combinedOpenGLFilter = m_combinedOpenGLFilter->d_ptr.data();
        m_combinedOpenGLFilter->d_ptr->setupIlluminationCorrection(illuminationCoefficients);
        m_combinedOpenGLFilter->d_ptr->setIlluminationCorrection(m_illuminationCorrectionFilter->d_ptr->enabled());
    }
  }
}

/***********************************************************************************/

QGenericMatrix<3, 8, float> SourcePipelinePrivate::getColorCorrectionCoefficients(
    const calibration::CalibrationData& calibrationData, const QString& datasetName) {

    QGenericMatrix<3, 8, float> result;

    calibration::ColorCorrectionData colorCorrectionData;
    if (datasetName == "colorCorrectionLampOn") {
        colorCorrectionData = calibrationData.colorCorrectionData("lampOn", "4K");
    } else if (datasetName == "colorCorrectionLampOff") {
        colorCorrectionData = calibrationData.colorCorrectionData("lampOff", "4K");
    } else if (datasetName == "colorCorrectionLampOn2K") {
        colorCorrectionData = calibrationData.colorCorrectionData("lampOn", "2K");
    } else if (datasetName == "colorCorrectionLampOff2K") {
        colorCorrectionData = calibrationData.colorCorrectionData("lampOff", "2K");
    } else {
        throw InvalidConfigurationException(
            QString("Color correction type %1 is not supported").arg(datasetName));
    }

    // Internal video pipeline works with BRG so we will swap it out here
    for (int i = 0; i < 8; ++i)
    {
        result(i, 0) = static_cast<float>(colorCorrectionData.blue(i, 0));
        result(i, 1) = static_cast<float>(colorCorrectionData.green(i, 0));
        result(i, 2) = static_cast<float>(colorCorrectionData.red(i, 0));
    }

  return result;
}

/***********************************************************************************/

void SourcePipelinePrivate::setupColorCorrection(
    unsigned long sourceIndex, const calibration::CalibrationData& calibrationData) {
  auto colorCorrection = m_configuration.colorCorrection;

  if (colorCorrection.included) {
    qInfo() << this << "Adding color correction filter";

    if (calibrationData.timeStamp == 0) {
      throw InvalidConfigurationException(
          "Calibration data are required for color correction but calibration was not performed "
          "yet.");
    }

    auto lampOnCoefficients = getColorCorrectionCoefficients(
        calibrationData, colorCorrection.lampOnCalibrationDatasetName);
    auto lampOffCoefficients = getColorCorrectionCoefficients(
        calibrationData, colorCorrection.lampOffCalibrationDatasetName);

    m_colorCorrectionFilter.reset(new ColorCorrectionFilter(sourceIndex, m_imageFilters));

    if (m_combinedOpenGLFilter) {
        m_colorCorrectionFilter->m_combinedOpenGLFilter = m_combinedOpenGLFilter->d_ptr.data();
        m_combinedOpenGLFilter->d_ptr->setColorCorrection(m_colorCorrectionFilter->d_ptr->enabled());
        m_combinedOpenGLFilter->d_ptr->setColorCorrectionMode(m_colorCorrectionFilter->d_ptr->mode());
    }

    m_colorCorrectionFilter->setLampOnCoefficients(lampOnCoefficients);
    m_colorCorrectionFilter->setLampOffCoefficients(lampOffCoefficients);
  }
}

/***********************************************************************************/

Nizza::Task* SourcePipelinePrivate::lastTask(DSSource* dsSource, unsigned long sourceIndex,
                                             const OutputVideoSinkConfig& outputConfig,
                                             const calibration::CalibrationData& calibrationData) {
  m_dsSource = dsSource;
  m_sourceIndex = sourceIndex;

  if (m_lastTask == nullptr) {
    qInfo() << this << "Constructing source pipeline for index" << sourceIndex;

    const auto cameraName = setupCamera();

    QVector<Nizza::Task*> pipeline;

    qInfo() << this << "Adding frame grabber";

    m_rawFrameGrabber.reset(
        new RawFrameGrabberTask(QString("%1:Raw Frame Grabber").arg(sourceIndex).toStdString()));
    pipeline << m_rawFrameGrabber.get();

    if (m_configuration.backend == SourcePipelineConfig::Backend::OpenGL) {        
        m_combinedOpenGLFilter.reset(new CombinedOpenGLFilter(sourceIndex, outputConfig, m_imageFilters));

        pipeline << m_combinedOpenGLFilter->d_ptr.data();
    }

    setupIlluminationCorrection(sourceIndex, calibrationData);

    if (m_illuminationCorrectionFilter && m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
      pipeline << m_illuminationCorrectionFilter->d_ptr.data();
    }

    setupColorCorrection(sourceIndex, calibrationData);

    if (m_colorCorrectionFilter && m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
      pipeline << m_colorCorrectionFilter->d_ptr.data();
    }

    setupKeystoneCorrection(sourceIndex, calibrationData);

    if (m_keystoneCorrectionFilter && m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
      pipeline << m_keystoneCorrectionFilter.get();
    }

    if (m_configuration.autoWhiteBalance.included) {
      qInfo() << this << "Adding auto white balance filter";

      m_autoWhiteBalanceFilter.reset(new AutoWhiteBalanceFilter(sourceIndex, m_imageFilters));

      if (m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
        pipeline << m_autoWhiteBalanceFilter->d_ptr.data();
      }
    }

    if (m_configuration.sharpen.included) {
      qInfo() << this << "Adding sharpen filter";

      if (m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
        m_sharpenFilter.reset(new SharpenFilter(sourceIndex, m_imageFilters));
        pipeline << m_sharpenFilter.get();
      } else {
        m_combinedOpenGLFilter->d_ptr->setSharpen(true);
      }
    }

    if (m_configuration.mirror.included) {
      qInfo() << this << "Adding mirroring filter";

      if (m_configuration.backend == SourcePipelineConfig::Backend::IntelIPP) {
        m_mirrorFilter.reset(new MirrorTask(sourceIndex, m_imageFilters, m_configuration.mirror));
        pipeline << m_mirrorFilter.get();
      } else {
        m_combinedOpenGLFilter->d_ptr->setMirror(m_configuration.mirror.type);
      }
    }

    if (m_configuration.frameGrabber.included) {
      qInfo() << this << "Adding final frame grabber";

      if (m_frameGrabberBuffer == nullptr) {
        throw InvalidOperationException(
            "setFrameGrabberBuffer must be called prior to video pipeline start in order to use "
            "FrameGrabber");
      }

      m_finalFrameGrabber.reset(new FinalFrameGrabberTask(
          sourceIndex, m_frameGrabberBuffer, m_imageFilters, m_configuration.frameGrabber));
      pipeline << m_finalFrameGrabber.data();

      connect(m_finalFrameGrabber.data(), &FinalFrameGrabberTask::frameBufferReady, this,
              &SourcePipelinePrivate::onFrameBufferReady);
    }

    switch (m_configuration.sourceType) {
      case SourcePipelineConfig::DirectShow: {
        auto const sourceName = cameraName.toStdWString();
        auto const sourceOutPinName = name().toStdString();
        auto const formatIndex = m_inputSourceFormatIndex.toStdString();
        auto const isRgbSource = DSSource::isMediaFormatRGB(m_inputSourceMediaFormat.toStdString());
        unsigned int sourcePinNumber;

        qDebug() << this << m_configuration.inputVideoSource.name << "Is source format #"
                 << m_inputSourceFormatIndex << m_inputSourceMediaFormat << "considered RGB?"
                 << isRgbSource;

        if (isRgbSource) {
          sourcePinNumber = dsSource->addRGBVideoSource(
              sourceName.c_str(), sourceOutPinName.c_str(), "image", formatIndex);
        } else {
          sourcePinNumber = dsSource->addVideoSource(sourceName.c_str(), sourceOutPinName.c_str(),
                                                     "image", formatIndex);
        }

        if (m_configuration.stillCapture.included) {
          dsSource->addStillCaptureOutput(sourceOutPinName.c_str(), "still_image", sourcePinNumber);

          m_stillCaptureFrameGrabber.reset(new RawFrameGrabberTask(
              QString("%1:Still Frame Grabber").arg(sourceIndex).toStdString()));
          m_stillCaptureSink =
              std::unique_ptr<NullSinkTask, NizzaTaskDeleter<NullSinkTask>>(new NullSinkTask(
                  QString("%1: Still capture sink").arg(sourceIndex).toStdString(), 1));

          Nizza::connect(dsSource, sourceOutPinName.c_str(), "still_image", "image", "in",
                         m_stillCaptureFrameGrabber.get());

          Nizza::connect(m_stillCaptureFrameGrabber.get(), "out", "image", "image", "image 0",
                         m_stillCaptureSink.get());
        }

        // This is required to prevent Nizza memory utilization to grow beyond control.
        dsSource->setLatencyReduction(sourcePinNumber, true);

        const auto rgbConverterName = QString("%1: Converter to RGB").arg(sourceIndex);
        m_rgbConverter.reset(new ImageConverter(rgbConverterName.toStdString()));
        std::vector<MirFormat> rgbFormats(3);
        rgbFormats[0] = MirFormat(mirBGR, mirUINT8, mirPixel, mirAlign1, mirProgressive);
        rgbFormats[1] = MirFormat(mirBGR, mirUINT8, mirPixel, mirAlign1, mirTopFieldFirst);
        rgbFormats[2] = MirFormat(mirBGR, mirUINT8, mirPixel, mirAlign1, mirBottomFieldFirst);
        m_rgbConverter->setFormats(rgbFormats);

        Nizza::connect(dsSource, sourceOutPinName.c_str(), "image", "image", "in",
                       m_rgbConverter.get());

        if (m_configuration.keystoneCorrection.included) {
            if (m_keystoneCorrectionFilter) {
               setSize(m_keystoneCorrectionFilter->outputRect().size());
            } else if (m_combinedOpenGLFilter) {
               setSize(m_combinedOpenGLFilter->d_ptr->keystoneCorrectedSize());
            }
        } else {
          setSize(m_configuration.inputVideoSource.size);
        }

        m_lastTask = m_rgbConverter.get();
        break;
      }
      case SourcePipelineConfig::OpenNI: {
        QString sourceName = "OrbbecRGB";
        m_orbbecCapture.reset(new OrbbecCapture(sourceName.toStdString()));
        setSize(QSize(640, 480));
        m_lastTask = m_orbbecCapture.get();
        break;
      }
      case SourcePipelineConfig::Desktop: {
        auto desktopCapture = m_configuration.desktopCaptureSource;
        auto area = desktopCapture.captureArea;
        QString windowName = desktopCapture.windowName, className = desktopCapture.className,
                sourceName;

        if (windowName.isNull() && className.isNull()) {
          // Full desktop capture
          sourceName = QString("Desktop [%1;%2 %3x%4]")
                           .arg(area.left())
                           .arg(area.top())
                           .arg(area.width())
                           .arg(area.height());
          windowName = "FULLDESKTOP";
          className = "internal";
        } else {
          sourceName = QString("%1 [%2]").arg(windowName).arg(className);
          area.setCoords(0, 0, -1, -1);
        }

        qInfo() << this << "Setting desktop capture parameters to" << windowName << className
                << area;

        m_desktopCaptureWindows.reset(new DesktopCaptureWindows(sourceName.toStdString()));
        m_desktopCaptureWindows->setWindow(windowName.toStdString(), className.toStdString());

        if (area.width() > 0 && area.height() > 0) {
          m_desktopCaptureWindows->setCaptureArea(
              static_cast<uint16>(area.left()), static_cast<uint16>(area.top()),
              static_cast<uint16>(area.width()), static_cast<uint16>(area.height()));

          setSize(area.size());
        } else {
          setSize(retrieveWindowSize(true));

          Q_Q(SourcePipeline);

          connect(q, &SourcePipeline::sizeChanged, [this](const QSize& size) {
            m_desktopCaptureWindows->setWidth(static_cast<uint16>(size.width()));
            m_desktopCaptureWindows->setHeight(static_cast<uint16>(size.height()));
          });

          if (desktopCapture.windowSizeRefreshDelay > 0) {
            m_windowSizeRefreshTimer.setInterval(desktopCapture.windowSizeRefreshDelay);
            m_windowSizeRefreshTimer.start();
          }
        }

        m_lastTask = m_desktopCaptureWindows.get();

        break;
      }
    }

    for (auto& filter : pipeline) {
      Nizza::connect(m_lastTask, "out", "image", "image", "in", filter);
      m_lastTask = filter;
    }
  }

  return m_lastTask;
}

/***********************************************************************************/

sensordata::SensorData SourcePipelinePrivate::captureVideoFrame() {
  return convertCaptureToSensorData(m_rawFrameGrabber->getFrame());
}

/***********************************************************************************/

sensordata::SensorData SourcePipelinePrivate::convertCaptureToSensorData(cv::Mat* capture) {
  sensordata::SensorData result;

  try {
    if (capture == nullptr) {
      throw std::exception("Wait delay for get frame loop timed out");
    } else {
      qInfo() << this << "Channels" << capture->channels() << capture->cols << capture->rows;

      image_filters::SourceImage sourceImage{
          {capture->cols, capture->rows},
          capture->channels() == 3 ? QImage::Format_RGB888 : QImage::Format_ARGB32,
          capture->data};

      auto outputBuffer = new uchar[capture->cols * capture->rows * capture->channels()];

      m_imageFilters->convertBGRtoRGB(sourceImage, outputBuffer);

      auto pixelFormat =
          (capture->channels() == 4 ? QImage::Format::Format_RGB32 : QImage::Format::Format_RGB888);

      QImage image(outputBuffer, capture->cols, capture->rows, capture->cols * capture->channels(),
                   pixelFormat, DeleteImageData, outputBuffer);

      const auto deviceDimensions = m_configuration.deviceDimensions;

      if (!deviceDimensions.isNull()) {
          image.setDotsPerMeterX(static_cast<int>(round(static_cast<qreal>(image.width()) / deviceDimensions.width())));
          image.setDotsPerMeterY(static_cast<int>(round(static_cast<qreal>(image.height()) / deviceDimensions.height())));

          qDebug() << this << "Setting dots per meter to" << image.dotsPerMeterX() << ";" << image.dotsPerMeterY();
      }

      auto metaEnum = QMetaEnum::fromType<SourcePipelineConfig::SourceType>();
      auto typeName = metaEnum.valueToKey(m_configuration.sourceType);

      QJsonObject filters;

      if (m_configuration.keystoneCorrection.included) {
        QJsonObject data{
            {"quality", QVariant::fromValue(m_configuration.keystoneCorrection.quality).toString()},
            {"homographyMatrixName", m_configuration.keystoneCorrection.homographyMatrixName}};

        filters.insert("keystoneCorrection", data);
      }

      auto isAutoWhiteBalanceEnabled = autoWhiteBalance() ? autoWhiteBalance()->enabled() : false;

      if (m_configuration.illuminationCorrection.included && illuminationCorrection()->enabled()) {
        isAutoWhiteBalanceEnabled =
            isAutoWhiteBalanceEnabled ||
            m_configuration.illuminationCorrection.isAutoWhiteBalanceEnabled;

        filters.insert("illuminationCorrection",
                       m_configuration.illuminationCorrection.calibrationDatasetName);
      }

      if (isAutoWhiteBalanceEnabled) {
        filters.insert("autoWhiteBalance", QJsonObject());
      }

      if (m_configuration.colorCorrection.included && colorCorrection()->enabled()) {
        auto dataset = colorCorrection()->mode() == ColorCorrectionFilter::Mode::LampOn
                           ? m_configuration.colorCorrection.lampOnCalibrationDatasetName
                           : m_configuration.colorCorrection.lampOffCalibrationDatasetName;

        filters.insert("colorCorrection", dataset);
      }

      if (m_configuration.sharpen.included) {
        filters.insert("sharpen", QJsonObject());
      }

      if (m_configuration.mirror.included) {
        filters.insert("mirror", QVariant::fromValue(m_configuration.mirror.type).toString());
      }

      QJsonObject metaData{{"type", typeName},
                           {"width", size().width()},
                           {"height", size().height()},
                           {"filters", filters},
                           {"viewport", RectToJson(m_viewport)},
                           {"destinationRectangle", RectToJson(m_destinationRectangle)}};

      if (m_configuration.sourceType == SourcePipelineConfig::Desktop) {
        metaData["captureArea"] = RectToJson(m_configuration.desktopCaptureSource.captureArea);
      }

      result = sensordata::SensorData(image, name(), m_configuration.captureType,
                                      QDateTime::currentDateTime(), {}, metaData);
    }

    delete capture;
  } catch (const std::exception& ex) {
    throw NizzaException("Unexpected error occured when trying to capture frame.", ex.what());
  }

  return result;
}

/***********************************************************************************/

sensordata::SensorData SourcePipelinePrivate::captureStillFrame() {
  if (!m_stillCaptureFrameGrabber) {
    throw InvalidOperationException("Source pipeline is not configured for still capture");
  }

  m_dsSource->captureStillFrame(m_sourceIndex);

  return convertCaptureToSensorData(m_stillCaptureFrameGrabber->getFrame());
}

/***********************************************************************************/

void SourcePipelinePrivate::setEnabled(bool enabled) {
  if (m_enabled != enabled) {
    m_enabled = enabled;

    // Stop streaming from source
    if (m_desktopCaptureWindows) {
      m_desktopCaptureWindows->setMaxCaptureRate(m_enabled ? 0.0 : -1.0);
      m_desktopCaptureWindows->produceFrame();
    } else if(m_orbbecCapture) {
        //m_orbbecCapture->setMaxCaptureRate(isEnabled ? 0.0 : -1.0);
        m_orbbecCapture->produceFrame();
    } else {
      emit dsSourceIsEnabledChanged(name(), m_enabled);
    }

    Q_Q(SourcePipeline);

    emit q->enabledChanged(m_enabled);
  }
}

/***********************************************************************************/

void SourcePipelinePrivate::forceUpdate() {
  // Force update of isEnabled

  m_enabled = !m_enabled;
  setEnabled(!m_enabled);
}

/***********************************************************************************/

QString SourcePipelinePrivate::findVideoFormat() {
  auto& configuration = m_configuration.inputVideoSource;
  QString foundDeviceName = configuration.name;

  qInfo() << this << "Trying to find video source matching configuration" << configuration;

  auto devices = DSSource::getVideoCaptureDevices();
  auto deviceIt = std::find_if(std::begin(devices), std::end(devices),
                               [this, configuration](const std::string& deviceName) {
                                 auto name = QString::fromStdString(deviceName);
                                 qDebug() << this << "Found device" << name;

                                 QRegExp match(configuration.name);
                                 return match.exactMatch(name);
                               });

  if (deviceIt == std::end(devices)) {
    throw InvalidConfigurationException(
        QString("Camera device with name %1 was not found").arg(configuration.name));
  } else {
    foundDeviceName = QString::fromStdString(*deviceIt);
    qInfo() << this << "Input source with name" << foundDeviceName
            << "found, looking for expected frame format ...";

    auto formats = DSSource::getVideoFormats2(foundDeviceName.toStdWString().c_str());
    auto formatIt = std::find_if(
        std::begin(formats), std::end(formats),
        [this, configuration](const DSS_WebCamVideoFormats& format) {
          qDebug() << this << "Found video format #" << format.index << ":"
                   << QString::fromStdString(format.mediaFormat) << format.nWidth << "x"
                   << format.nHeight << "@" << format.dFrameRate << "fps";

          return format.nHeight == static_cast<uint32>(configuration.size.height()) &&
                 format.nWidth == static_cast<uint32>(configuration.size.width()) &&
                 static_cast<unsigned int>(format.dFrameRate) == configuration.frameRate;
        });

    if (formatIt == std::end(formats)) {
      auto message = QString("Camera device %1 doesn't support resolution %2x%3 with frame rate %4")
                         .arg(foundDeviceName)
                         .arg(configuration.size.width())
                         .arg(configuration.size.height())
                         .arg(configuration.frameRate);

      throw InvalidConfigurationException(message);
    } else {
      auto index = std::distance(std::begin(formats), formatIt);

      m_inputSourceFormatIndex = QString::number(index);
      m_inputSourceMediaFormat = QString::fromStdString(formatIt->mediaFormat);

      qInfo() << this << "Input source with name" << foundDeviceName
              << "and matching video format found at index" << m_inputSourceFormatIndex
              << "and format" << m_inputSourceMediaFormat;
    }
  }

  return foundDeviceName;
}

/***********************************************************************************/

void SourcePipelinePrivate::reset() {
  disconnect(m_finalFrameGrabber.data());

  m_windowSizeRefreshTimer.stop();

  m_rgbConverter.reset();
  m_rawFrameGrabber.reset();
  m_combinedOpenGLFilter.reset();
  m_keystoneCorrectionFilter.reset();
  m_rgbConverter.reset();
  m_sharpenFilter.reset();
  m_mirrorFilter.reset();
  m_stillCaptureFrameGrabber.reset();
  m_stillCaptureSink.reset();

  m_illuminationCorrectionFilter.reset();
  m_autoWhiteBalanceFilter.reset();
  m_colorCorrectionFilter.reset();

  m_desktopCaptureWindows.reset();
  m_orbbecCapture.reset();
  m_finalFrameGrabber.reset();

  m_lastTask = nullptr;
  m_frameGrabberBuffer = nullptr;
}

/***********************************************************************************/

QString SourcePipelinePrivate::setupCamera() {
  return m_configuration.sourceType == SourcePipelineConfig::DirectShow
             ? findVideoFormat()
             : m_configuration.inputVideoSource.name;
}

/***********************************************************************************/

QRectF SourcePipelinePrivate::viewport() const { return m_viewport; }

/***********************************************************************************/

void SourcePipelinePrivate::setViewport(QRectF viewport) {
  // Normalize components
  viewport = viewport.normalized();

  if (m_viewport != viewport) {
    m_viewport = viewport;

    Q_Q(SourcePipeline);

    emit q->viewportChanged(m_viewport);
  }
}

/***********************************************************************************/

QJsonValue SourcePipelinePrivate::RectToJson(const QRectF& rectangle) {
  return QJsonObject{{"left", rectangle.left()},
                     {"top", rectangle.top()},
                     {"width", rectangle.width()},
                     {"height", rectangle.height()}};
}

/***********************************************************************************/

void SourcePipelinePrivate::onFrameBufferReady(int sourceIndex, const QSize size, int dataSize) {
  Q_Q(SourcePipeline);
  emit q->frameBufferReady(sourceIndex, size, dataSize);
}

/***********************************************************************************/

IlluminationCorrectionFilter* SourcePipelinePrivate::illuminationCorrection() const {
  return m_illuminationCorrectionFilter.data();
}

/***********************************************************************************/

ColorCorrectionFilter* SourcePipelinePrivate::colorCorrection() const {
  return m_colorCorrectionFilter.data();
}

/***********************************************************************************/

AutoWhiteBalanceFilter* SourcePipelinePrivate::autoWhiteBalance() const {
  return m_autoWhiteBalanceFilter.data();
}

/***********************************************************************************/

CombinedOpenGLFilter* SourcePipelinePrivate::combinedOpenGLFilter() const {
    return m_combinedOpenGLFilter.data();
}

/***********************************************************************************/

void SourcePipelinePrivate::setFrameGrabberBuffer(uchar* buffer) { m_frameGrabberBuffer = buffer; }

}  // namespace source
}  // namespace video
