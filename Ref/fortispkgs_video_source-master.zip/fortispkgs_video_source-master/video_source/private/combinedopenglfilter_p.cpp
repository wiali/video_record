#include "combinedopenglfilter_p.h"

#include <QMatrix4x4>
#include <QOpenGLContext>
#include <QOffscreenSurface>
#include <QOpenGLFunctions>
#include <QMetaObject>

namespace video {
namespace source {

/*!
 * \brief The AutoWhiteBalanceFilter::State struct contains internal auto white balance filter data.
 */
struct CombinedOpenGLFilterPrivate::State {
public:
    State() : frameBuffer(nullptr) {}

    /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
    Rock::Mutex mutex;

    /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
    QSize imageSize;

    QMap<QOpenGLContext*, std::shared_ptr<image_filters::CombinedFilterData>> data;

    image_filters::CombinedFilterSettings settings;

    /*!
     * \brief Size of the frame buffer.
     * \details Image size is determined based on the first frame and should not change while pipeline
     * is running.
     */
    size_t bufferSize;

    std::vector<uchar> buffer;

    std::vector<uchar> outputBuffer;

    uchar *frameBuffer;

    /*! \brief index Video source index for naming purposes.
     */
    int index;

    QOffscreenSurface surface;

    QOpenGLContext context;
};


static bool gVerbose = false;

CombinedOpenGLFilterPrivate::CombinedOpenGLFilterPrivate(ulong index,
                                                         const OutputVideoSinkConfig& outputConfig,
                                                         std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                                         CombinedOpenGLFilter *parent)
    : OptionalImageFilterNizzaTask(QString("%1:Combined OpenGL").arg(index).toStdString(),
                                   imageFilter)
    , q_ptr(parent)
    , m_illuminationCorrection(false)
    , m_colorCorrection(false)
    , m_sharpen(false)
    , m_autoWhiteBalance(false)
    , m_keystoneCorrection(false)            
    , m_outputConfig(outputConfig)
    , m_mirrorType(MirrorFilterConfig::MirrorType::None) {
    m_state = std::make_unique<State>();
    m_state->index = static_cast<int>(index);
    m_state->settings.pixelFormat = QOpenGLTexture::PixelFormat::BGR;

    if (!m_outputConfig.name.isEmpty()) {
        // Context has to be *created* in main thread
        if (!m_state->context.create()) {
            qCritical() << "Cannot create OpenGL context";
            throw std::exception("Cannot create OpenGL context");
        }

        // But then it can be moved to another thread since we don't want to block main UI thread
        moveToThread(&m_thread);
        m_state->context.moveToThread(&m_thread);
        m_state->surface.setFormat(m_state->context.format());
        m_state->surface.create();

        m_thread.start();
    }
}

/***********************************************************************************/

CombinedOpenGLFilterPrivate::~CombinedOpenGLFilterPrivate() {
    m_thread.quit();
    m_thread.wait();
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setupKeystoneCorrection(const QSize &keystoneCorrectedSize,
                                                          QTransform homography,
                                                          const KeystoneCorrectionFilterConfig::Quality &quality) {
    m_state->settings.keystoneCorrectedSize = keystoneCorrectedSize;
    m_state->settings.keystoneCorrectionTransformation = homography;
    m_state->settings.interpolationType = quality == KeystoneCorrectionFilterConfig::Quality::Nearest ?
                image_filters::InterpolationType::Linear : image_filters::InterpolationType::Linear;
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setupIlluminationCorrection(const QGenericMatrix<1, 6, float> &illuminationCoefficients) {
    m_state->settings.illuminationCoefficients = illuminationCoefficients;
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::illuminationCorrection() const { return m_illuminationCorrection; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setIlluminationCorrection(bool illuminationCorrection) {
    m_illuminationCorrection = illuminationCorrection;
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::keystoneCorrection() const { return m_keystoneCorrection; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setKeystoneCorrection(bool keystoneCorrection) {
    m_keystoneCorrection = keystoneCorrection;
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::autoWhiteBalance() const { return m_autoWhiteBalance; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setAutoWhiteBalance(bool autoWhiteBalance) {
    m_autoWhiteBalance = autoWhiteBalance;
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::colorCorrection() const { return m_colorCorrection; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setColorCorrection(bool colorCorrection) { m_colorCorrection = colorCorrection; }

/***********************************************************************************/

QGenericMatrix<3, 8, float> CombinedOpenGLFilterPrivate::lampOnCoefficients() const { return m_state->settings.colorCorrectionLampOnCoefficients; }

/***********************************************************************************/

QGenericMatrix<3, 8, float> CombinedOpenGLFilterPrivate::lampOffCoefficients() const { return m_state->settings.colorCorrectionLampOffCoefficients; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (lampOnCoefficients() != coefficients) {
    m_state->settings.colorCorrectionLampOnCoefficients = coefficients;

    m_state->mutex.lock();
    m_state->data.clear();
    m_state->mutex.unlock();
  }
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (lampOffCoefficients() != coefficients) {
    m_state->settings.colorCorrectionLampOffCoefficients = coefficients;

    m_state->mutex.lock();
    m_state->data.clear();
    m_state->mutex.unlock();
  }
}

/***********************************************************************************/

ColorCorrectionFilter::Mode CombinedOpenGLFilterPrivate::colorCorrectionMode() const { return m_colorCorrectionMode; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setColorCorrectionMode(ColorCorrectionFilter::Mode colorCorrectionMode) {
    m_colorCorrectionMode = colorCorrectionMode;
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::sharpen() const { return m_sharpen; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setSharpen(bool sharpen) {
    m_sharpen = sharpen;
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setVerbose(bool val) { gVerbose = val; }

/***********************************************************************************/

QSize CombinedOpenGLFilterPrivate::keystoneCorrectedSize() const { return m_state->settings.keystoneCorrectedSize; }

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::setMirror(MirrorFilterConfig::MirrorType mirrorType) {
    m_mirrorType = mirrorType;
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::conclude() {
  OptionalImageFilterNizzaTask::conclude();

  m_state->mutex.lock();

  m_offscreenImageEvent.wakeAll();

  m_state->mutex.unlock();
}

/***********************************************************************************/

bool CombinedOpenGLFilterPrivate::convert(QOpenGLFramebufferObject* glFrameBuffer) {
    bool result = false;
    const auto context = QOpenGLContext::currentContext();

    m_state->mutex.lock();

    auto contextData = m_state->data.contains(context) ? m_state->data[context] : std::shared_ptr<image_filters::CombinedFilterData>();
    auto settings = m_state->settings;
    auto imageSize = m_state->imageSize;
    auto frameBuffer = m_state->frameBuffer;

    m_state->mutex.unlock();

    if (imageSize.isEmpty()) {
        qWarning() << this << "Cannot request texture before first frame arrives";
    } else {
        if (!contextData) {
            m_state->mutex.lock();
            contextData = m_imageFilter->combinedInit(imageSize, settings);
            m_state->data.insert(context, contextData);

            m_state->mutex.unlock();
        }
    }

    if (contextData) {
        static QHash<MirrorFilterConfig::MirrorType, image_filters::MirrorType> mirrorTypeTranslationTable {
            { MirrorFilterConfig::MirrorType::None, image_filters::MirrorType::None },
            { MirrorFilterConfig::MirrorType::Vertical, image_filters::MirrorType::Vertical },
            { MirrorFilterConfig::MirrorType::Horizontal, image_filters::MirrorType::Horizontal },
            { MirrorFilterConfig::MirrorType::Both, image_filters::MirrorType::Both }
        };

        image_filters::ImageFilter::CombinedFilters filters;
        filters |= m_keystoneCorrection ? image_filters::ImageFilter::KeystoneCorrection : image_filters::ImageFilter::None;
        filters |= m_illuminationCorrection ? image_filters::ImageFilter::IlluminationCorrection : image_filters::ImageFilter::None;
        filters |= m_colorCorrection ? image_filters::ImageFilter::ColorCorrection : image_filters::ImageFilter::None;
        filters |= m_sharpen ? image_filters::ImageFilter::Sharpen : image_filters::ImageFilter::None;
        filters |= m_autoWhiteBalance ? image_filters::ImageFilter::AutoWhiteBalance : image_filters::ImageFilter::None;
        filters |= m_mirrorType != MirrorFilterConfig::MirrorType::None ? image_filters::ImageFilter::Mirror : image_filters::ImageFilter::None;

        m_state->mutex.lock();

        image_filters::SourceImage sourceImage { m_state->imageSize, QImage::Format_RGB888, frameBuffer };

        m_imageFilter->combined(sourceImage, glFrameBuffer, contextData, filters, m_colorCorrectionMode == ColorCorrectionFilter::Mode::LampOff ?
                                    image_filters::ImageFilter::LampOff : image_filters::ImageFilter::LampOn, mirrorTypeTranslationTable[m_mirrorType]);
        m_state->mutex.unlock();

        result = true;
    }

    return result;
}

/***********************************************************************************/

Mir* CombinedOpenGLFilterPrivate::process(Mir* in) {
    uint32 w = in->width, h = in->height;
    auto inputBuffer = in->getBuffer(Mir::imageBuffer);
    const auto isDirectShowSink = !m_outputConfig.name.isNull();

    m_state->mutex.lock();
    auto imageSize = m_state->imageSize;
    auto frameBuffer = m_state->frameBuffer;
    auto bufferSize = m_state->bufferSize;
    auto index = m_state->index;
    auto isFirstFrame = false;
    m_state->mutex.unlock();

    if (imageSize.isEmpty()) {
        isFirstFrame = true;
        m_state->mutex.lock();
        imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));

        if (frameBuffer == nullptr) {
            m_state->buffer.resize(imageSize.width() * imageSize.height() * 3);
            m_state->frameBuffer = frameBuffer = m_state->buffer.data();
        }

        m_state->bufferSize = bufferSize = in->getBufferSize(Mir::imageBuffer);
        m_state->outputBuffer.resize(m_outputConfig.size.width() * m_outputConfig.size.height() * 3);
        m_state->mutex.unlock();
    }

    m_state->mutex.lock();

    memcpy(frameBuffer, inputBuffer, bufferSize);

    m_state->mutex.unlock();

    Q_Q(CombinedOpenGLFilter);

    Mir* out = in;

    emit q->frameReady(index, m_keystoneCorrection ? keystoneCorrectedSize() : imageSize, static_cast<int>(bufferSize));

    if (isDirectShowSink) {
        QMutex mutex;
        QMutexLocker locker(&mutex);

        // First frame is pass-through to avoid delay in initialization of DSSink which will default to 1280x720
        if (!isFirstFrame) {
            // Execute the function on same thread where we created context / surface
            QMetaObject::invokeMethod(this, "generateOffscreenImage", Qt::QueuedConnection);

            m_offscreenImageEvent.wait(&mutex);
        }

        out = new Mir(m_outputConfig.size.width(), m_outputConfig.size.height(), in->format);
        out->timestamp = in->timestamp;

        auto outputBuffer = out->getBuffer(Mir::imageBuffer);

        memcpy(outputBuffer, m_state->outputBuffer.data(), m_state->outputBuffer.size());
    }

    return out;
}

/***********************************************************************************/

void CombinedOpenGLFilterPrivate::generateOffscreenImage() {
  // This method MUST run on object thread

  m_state->context.makeCurrent(&m_state->surface);

  QOpenGLFramebufferObject frameBuffer(m_state->imageSize);

  convert(&frameBuffer);

  const auto frameSize = m_keystoneCorrection ? keystoneCorrectedSize() : m_state->imageSize;

  QOpenGLFramebufferObject targetBuffer(m_outputConfig.size);
  QOpenGLFramebufferObject::blitFramebuffer(&targetBuffer, QRect(QPoint(), targetBuffer.size()),
                                            &frameBuffer, QRect(QPoint(), frameSize));

  const auto functions = m_state->context.functions();

  targetBuffer.bind();

  functions->glReadPixels(0, 0, m_outputConfig.size.width(), m_outputConfig.size.height(),
                          GL_BGR, GL_UNSIGNED_BYTE, m_state->outputBuffer.data());

  targetBuffer.bindDefault();

  m_state->context.doneCurrent();
  m_offscreenImageEvent.wakeAll();
}

/***********************************************************************************/

}  // namespace source
}  // namespace video
