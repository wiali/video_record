/*! \file rawframegrabbertask.cpp
 *
 *  \brief Contains implementation of Nizza module calling Image Enhancement plugin functions (for
 * image processing).
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QFile>
#include <QImage>
#include <QObject>

#include <opencv2/core.hpp>
#include <opencv2/opencv.hpp>

#include <thread>
#include <utility>

#include <NizzaMedia.h>

#include "video_source/private/rawframegrabbertask.h"

namespace video {
namespace source {

static bool gVerbose = false;

RawFrameGrabberTask::RawFrameGrabberTask(std::string name)
    : Task(name, "ImageFilter"),
      m_needFrame(0) {
  // Create input media pin
  addInputPin("in", "image", "Image_Raw");

  // Create output media pin
  addOutputPin("out", "image", "Image_Raw");
}

/***********************************************************************************/

void RawFrameGrabberTask::setVerbose(bool val) { gVerbose = val; }

/***********************************************************************************/

void RawFrameGrabberTask::commence() {
  // do pre-streaming initialization
  if (gVerbose) {
    Rock::Thread::logf("ImageFilter::commence: Entered.\n");
  }
}

/***********************************************************************************/

void RawFrameGrabberTask::conclude() {
  // do post-streaming cleanup
  if (gVerbose) {
    Rock::Thread::logf("ImageFilter::conclude: Entered.\n");
  }

  std::unique_lock<std::mutex> lk(m_frameLock);

  m_savedFrame.release();
}

/***********************************************************************************/

bool RawFrameGrabberTask::process(const std::string& groupName,
                                  const std::vector<Nizza::Media*>& media, Nizza::Output& output) {
  if (gVerbose) {
    Rock::Thread::logf("ImageFilter::process: Entered.\n");
  }

  if (groupName != "in") {
    throw stringf("ImageFilter::process: unknown group [%s]", groupName.c_str());
  }

  if (media.size() != 1) {
    throw stringf(
        "ImageFilter::process: error num"
        "ber of media size [%lu], expected 1.",
        media.size());
  }

  // Check media type before casting.
  if (!media[0] || strcmp(media[0]->getType(), "Image_Raw")) {
    throw stringf("ImageFilter::process: Null media input or type was not Media_Image_Raw.");
  }

  Media_Image_Raw* srcMedia = reinterpret_cast<Media_Image_Raw*>(media[0]);

  IplImage iplImage;
  srcMedia->convertToIPL(&iplImage);

  cv::Mat outData = cv::cvarrToMat(&iplImage);

  bool savedFrame = false;
  if (m_needFrame.testAndSetAcquire(1, 0)) {
    savedFrame = saveFrame(&outData);
  }

  // Output new media
  output.push("out", "image", srcMedia);

  // Signal that we are done with input media. Only call when
  // we no longer are using it and any pointers to its buffer.
  Nizza::endMediaUsage(srcMedia);

  return true;
}

/***********************************************************************************/

bool RawFrameGrabberTask::saveFrame(cv::Mat* outData) {
  std::unique_lock<std::mutex> lk(m_frameLock);

  m_savedFrame.release();
  m_savedFrame = outData->clone();

  // notify everyone waiting for it;
  m_frameArrived.notify_all();

  return true;
}

/***********************************************************************************/

cv::Mat* RawFrameGrabberTask::getFrame(int timeoutMilliseconds) {
  m_needFrame.store(1);
  std::unique_lock<std::mutex> lk(m_frameLock);
  int iTimeout = (timeoutMilliseconds >= 0 ? timeoutMilliseconds : m_defaultGetFrameTimeout);
  auto now = std::chrono::system_clock::now();

  if (m_frameArrived.wait_until(lk, now + std::chrono::milliseconds(iTimeout)) ==
      std::cv_status::no_timeout) {
    cv::Mat* outMat = new cv::Mat(std::move(m_savedFrame.clone()));
    return outMat;
  }

  return nullptr;
}

/***********************************************************************************/

}  // namespace source
}  // namespace video
