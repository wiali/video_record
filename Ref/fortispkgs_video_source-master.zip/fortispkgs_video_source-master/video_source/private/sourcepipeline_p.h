/*! \file sourcepipeline_p.h
 *  \brief Contains definition of source pipeline.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_SOURCEPIPELINE_P_H_
#define VIDEO_SOURCE_PRIVATE_SOURCEPIPELINE_P_H_

#include <QJsonObject>
#include <QObject>
#include <QPointer>
#include <QSharedPointer>
#include <QTimer>
#include <QThread>

#include <DSSource.h>

#include <calibration_data.h>
#include <atomic>
#include <memory>
#include <touchmat/touchmat.h>

#include "video_source/sourcepipeline.h"
#include "video_source/sourcepipelineconfig.h"

#include "video_source/private/finalframegrabbertask.h"
#include "video_source/private/keystonecorrectionfilter.h"
#include "video_source/private/mirrortask.h"
#include "video_source/private/nizzataskdeleter.h"
#include "video_source/private/rawframegrabbertask.h"
#include "video_source/private/sharpenfilter.h"
#include "video_source/private/nullsinktask.h"
#include "video_source/private/orbbeccapturetasksource.h"
#include "video_source/private/combinedopenglfilter_p.h"

namespace video {
namespace source {

/*!
 * \brief The SourcePipeline class encapsulates part of video pipeline untl it reaches compositor.
 */
class SourcePipelinePrivate : public QObject {
  Q_OBJECT
  Q_DECLARE_PUBLIC(SourcePipeline)

  SourcePipeline* const q_ptr;

 public:
  /*!
   * \brief Default constructor.
   * \param imageFilter Pointer to Image filters.
   * \param parent Parent object.
   */
  explicit SourcePipelinePrivate(std::shared_ptr<image_filters::ImageFilter> imageFilter, SourcePipeline* parent = 0);

  virtual ~SourcePipelinePrivate();

  /*! \brief Sets the new configuration.
   *  \details This method has to be called before pipeline is used, otherwise it returns error.
   */
  void setConfiguration(const video::source::SourcePipelineConfig& configuration);

  /*! \brief Returns current pipeline configuration
   */
  video::source::SourcePipelineConfig configuration() const;

  /*!
   * \brief Returns if this input source is enabled.
   */
  bool enabled() const;

  /*!
   * \brief Sets if this input source is enabled.
   * \param isEnabled Value indicating if this input source should be enabled.
   */
  void setEnabled(bool enabled);

  /*!
    * \brief Returns image size after all enhancement filters before entering compositor.
    */
  QSize size() const;

  /*!
    * \brief Returns name of this input source pipeline.
    */
  inline QString name() const;

  /*! \brief Get current zoom/pan viewport.
   *  \details Returns current zoom/pan viewport. Units are fraction of image size - they're in (0,0
   * - 1,1) range.
   *   0,0 represents lower left corner and 1,1 represents upper right corner of image rectangle.
   */
  QRectF viewport() const;

  /*! \brief Sets the new value of the viewport for this source pipeline.
   *  \param viewport Viewport coordinates.
   *  \sa viewport()
   */
  void setViewport(QRectF viewport);

  /*! \brief Get zoom/pan viewport.
   *  \details Returns current zoom/pan viewport. Units are fraction of image size - they're in (0,0
   * - 1,1) range.
   *   0,0 represents lower left corner and 1,1 represents upper right corner of image rectangle.
   */
  QRectF destinationRectangle();

  /*! \brief Sets the new value of the destination rectangle for this source pipeline.
   *  \param destinationRectangle Destination rectangle.
   *  \sa destinationRectangle()
   */
  void setDestinationRectangle(QRectF destinationRectangle);

  /*! \brief Returns last of source pipeline for connection to the sink.
   *  \details Video pipeline can be optimized by excluding video enhancement filters when there is
   * Null Sink at the end of the pipeline and
   *  \details Final Frame Graber is disabled. In this case it's not necessary to execute filters -
   * output will be discarded anyway.
   *  \param dsSource Pointer to DirectShow source Nizza task for configuration.
   *  \param sourceIndex Source index in full pipeline used to provide unique names for each filter
   *  \param calibrationData
   */
  Nizza::Task* lastTask(DSSource* dsSource, unsigned long sourceIndex, const OutputVideoSinkConfig &outputConfig,
                        const calibration::CalibrationData& calibrationData);

  /*! \brief Captures video frame from this source pipeline.
   */
  sensordata::SensorData captureVideoFrame();

  /*! \brief Captures still frame from this source pipeline.
   */
  sensordata::SensorData captureStillFrame();

  /*! \brief Sets the name of this input source pipeline.
   */
  void setName(const QString& name);

  /*!
   * \brief Releases the pointers to source pipeline filters.
   * \details This method is intended to be used after the Nizza pipeline is stopped to reset
   * pointers.
   */
  void reset();

  /*!
   * \brief Forces update of stream to get new frames.
   */
  void forceUpdate();

  /*! \brief Returns the pointer to the illumination correction filter.
   *  \details Illumination correction filter needs to be included in the pipeline (property
   * IlluminationCorrectionFilterConfig::isIncluded)
   *  \details otherwise this method returns nullptr.
   *  \details Since the filters are recreated between restarts of the pipeline results of this
   * method should not be stored.
   */
  IlluminationCorrectionFilter* illuminationCorrection() const;

  /*! \brief Returns the pointer to the auto white balance filter.
   *  \details Illumination correction filter needs to be included in the pipeline (property
   * AutoWhiteBalanceFilterConfig::isIncluded)
   *  \details otherwise this method returns nullptr.
   *  \details Since the filters are recreated between restarts of the pipeline results of this
   * method should not be stored.
   */
  Q_INVOKABLE AutoWhiteBalanceFilter* autoWhiteBalance() const;

  /*! \brief Returns the pointer to the color correction filter.
   *  \details Color correction filter needs to be included in the pipeline (property
   * ColorCorrectionFilterConfig::isIncluded)
   *  \details otherwise this method returns nullptr.
   *  \details Since the filters are recreated between restarts of the pipeline results of this
   * method should not be stored.
   */
  Q_INVOKABLE ColorCorrectionFilter* colorCorrection() const;

  /*! \brief Returns the pointer to the combined OpenGL filter.
   *  \remarks The filters are recreated between restarts of the pipeline so results of this method should not be stored.
   *  \return The combined OpenGL filter associated with current execution.
   */
  Q_INVOKABLE CombinedOpenGLFilter* combinedOpenGLFilter() const;

  /*!
   * \brief Allows to set framegrabber buffer that will receive raw data from framegrabber filter.
   * \details This method has to be called before the video pipeline is started.
   * \details It's caller's responsibility to allocate and deallocate the buffer to proper size to
   * accomodate raw frame.
   * \param buffer Pointer to the buffer.
   */
  void setFrameGrabberBuffer(uchar* buffer);

 signals:
  /*!
   * \brief Signal emitted when isEnabled property is changed on source pipeline which uses
   * DirectShow to produce frames.
   * \param sourceName Source pipeline name.
   * \param isEnabled Indication if the DirectShow source filter is enabled or not.
   */
  void dsSourceIsEnabledChanged(QString sourceName, bool isEnabled);

 private slots:
  void onFrameBufferReady(int sourceIndex, const QSize size, int dataSize);

 protected:
  /*! \brief Setups camera.
   *  \details Set parameters that are optimal for previewing video.
   */
  QString setupCamera();

  /*! \brief Finds video format for input video source configuration.
   */
  QString findVideoFormat();

  /*! \brief Converts a PixelExtent to a QJsonObject
   */
  static QJsonValue RectToJson(const QRectF& rectangle);

  /*!
   * \brief Returns the size of the captured desktop window.
   */
  QSize retrieveWindowSize(bool throwException);

  /*!
   * \brief Sets the new image size.
   * \param size New image size.
   */
  void setSize(QSize size);

  /*!
   * \brief Sets up keystone correction filter.
   * \param calibration CalibrationData instance.
   */
  void setupKeystoneCorrection(unsigned long sourceIndex, const calibration::CalibrationData& calibrationData);

  /*!
   * \brief Sets up illumination correction filter.
   * \param calibrationData CalibrationData instance.
   */
  void setupIlluminationCorrection(unsigned long sourceIndex, const calibration::CalibrationData& calibrationData);

  /*!
   * \brief Sets up color correction filter.
   * \param calibrationData CalibrationData instance.
   */
  void setupColorCorrection(unsigned long sourceIndex, const calibration::CalibrationData& calibrationData);

  /*!
   * \brief Gets dataset color correction coefficients from calibration data.
   * \param calibrationData CalibrationData instance.
   * \param datasetName Name of the dataset.
   */
  QGenericMatrix<3, 8, float> getColorCorrectionCoefficients(const calibration::CalibrationData& calibrationData, const QString& datasetName);

  /*!
   * \brief Converts color correction from calibration to single structure.
   * \param coefficients Coefficients structure.
   * \param channel Channel to fill.
   * \param data CalibrationData instance.
   */
  void readColorCorrectionData(QGenericMatrix<3, 8, float>* coefficients, int channel,
                               const calibration::ColorCorrectionData& data);

  /*! \brief Converts capture to sensor data.
   */
  sensordata::SensorData convertCaptureToSensorData(cv::Mat* capture);

  /*! \brief Indicates if this source input is enabled.
   */
  std::atomic_bool m_enabled;

  /*! \brief Contains pointer to the last Nizza task in source pipeline
   *  \details If nullptr then this input pipeline was not used yet and can be reconfigured.
   */
  Nizza::Task* m_lastTask;

  /*! \brief Contains source pipeline configuration.
   */
  video::source::SourcePipelineConfig m_configuration;

  /*! \brief Nizza RGB converter task.
   *  \details Responsible for manipulating color space before filters are used.
   */
  std::unique_ptr<ImageConverter, NizzaTaskDeleter<ImageConverter>> m_rgbConverter;

  /*! \brief Pointer to Image filters library.
   */
  std::shared_ptr<image_filters::ImageFilter> m_imageFilters;

  /*! \brief Optional pointer to instance of keystone correction filter.
   */
  std::unique_ptr<KeystoneCorrectionFilter, NizzaTaskDeleter<KeystoneCorrectionFilter>> m_keystoneCorrectionFilter;

  /*! \brief Optional pointer to instance of sharpen filter.
   */
  std::unique_ptr<SharpenFilter, NizzaTaskDeleter<SharpenFilter>> m_sharpenFilter;

  /*! \brief Optional pointer to instance of illumination correction filter.
   *  \details Since Nizza deletes tasks we don't need to care about releasing this ourselves, just
   * reset the pointer.
   */
  QScopedPointer<IlluminationCorrectionFilter, NizzaTaskDeleter<IlluminationCorrectionFilter>>
      m_illuminationCorrectionFilter;

  /*! \brief Optional pointer to auto white balance filter.
   */
  QScopedPointer<AutoWhiteBalanceFilter, NizzaTaskDeleter<AutoWhiteBalanceFilter>> m_autoWhiteBalanceFilter;

  /*! \brief Optional pointer to color correction filter.
   */
  QScopedPointer<ColorCorrectionFilter, NizzaTaskDeleter<ColorCorrectionFilter>> m_colorCorrectionFilter;

  /*! \brief Pointer to instance of keystone correction filter.
   */
  std::unique_ptr<RawFrameGrabberTask, NizzaTaskDeleter<RawFrameGrabberTask>> m_rawFrameGrabber;

  /*! \brief Pointer to instance of mirror filter.
   */
  std::unique_ptr<MirrorTask, NizzaTaskDeleter<MirrorTask>> m_mirrorFilter;

  /*! \brief Pointer to instance of GPU filters.
   */
  QScopedPointer<CombinedOpenGLFilter, NizzaTaskDeleter<CombinedOpenGLFilter>> m_combinedOpenGLFilter;

  /*! \brief Nizza final frame grabber task.
   *  \details Since Nizza deletes tasks we don't need to care about releasing this ourselves, just
   * reset the pointer.
   */
  QScopedPointer<FinalFrameGrabberTask, NizzaTaskDeleter<FinalFrameGrabberTask>> m_finalFrameGrabber;

  /*! \brief Nizza still capture frame grabber task.
   *  \details Since Nizza deletes tasks we don't need to care about releasing this ourselves, just
   * reset the pointer.
   */
  std::unique_ptr<RawFrameGrabberTask, NizzaTaskDeleter<RawFrameGrabberTask>> m_stillCaptureFrameGrabber;

  /*! \brief Null sink task.
   */
  std::unique_ptr<NullSinkTask, NizzaTaskDeleter<NullSinkTask>> m_stillCaptureSink;

  /*! \brief Input source format index as detected by Nizza framework based on input source
   * configuration.
   */
  QString m_inputSourceFormatIndex;

  /*! \brief Input source format media format as detected by Nizza framework based on input source
   * configuration.
   */
  QString m_inputSourceMediaFormat;

  /*! \brief Nizza DesktopCaptureWindows input source task.
   */
  std::unique_ptr<DesktopCaptureWindows, NizzaTaskDeleter<DesktopCaptureWindows>> m_desktopCaptureWindows;

  /*! \brief Nizza OrbbecCapture input source task.
   */
  std::unique_ptr<OrbbecCapture, NizzaTaskDeleter<OrbbecCapture>> m_orbbecCapture;

  /*! \brief Output sink viewport configuration as normalized rectangle.
   */
  QRectF m_viewport;

  /*! \brief Output sink destination rectangle as normalized rectangle.
   */
  QRectF m_destinationRectangle;

  /*! \brief Contains name of this input source pipeline.
   */
  QString m_name;

  /*!
   * \brief Size of this input pipeline.
   */
  QSize m_size;

  DSSource* m_dsSource;

  unsigned long m_sourceIndex;

#ifdef Q_OS_WIN
  /*!
   * \brief Handle to captured desktop window.
   */
  HWND m_desktopWindowHandle;
#endif

  /*!
   * \brief Desktop window capture refresh timer.
   * \details Allows periodic updates of size of captured window.
   */
  QTimer m_windowSizeRefreshTimer;

  /*!
   * \brief Pointer to frame grabber buffer for this source pipeline.
   */
  uchar* m_frameGrabberBuffer;

  /*!
   * \brief Pointer to ProAPI touchmat.
   */
  QScopedPointer<proapi::touchmat::Touchmat> m_touchmat;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_SOURCEPIPELINE_P_H_
