/*! \file rawframegrabbertask.h
 *  \brief Nizza task for grabbing raw frames.
 *  This is internal header file (not to be exposed to other Fortis plugins or client apps).
 *  \date May, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_RAWFRAMEGRABBERTASK_H_
#define VIDEO_SOURCE_PRIVATE_RAWFRAMEGRABBERTASK_H_

#include <opencv2/core/core.hpp>

#include <QVector>

#include <condition_variable>
#include <mutex>
#include <string>
#include <vector>

#include <Nizza.h>

namespace video {
namespace source {

/*! \brief Custom Nizza module
 *  \details Module to be inserted into Nizza graph
 */
struct RawFrameGrabberTask : public Nizza::Task {
 public:
  /*! \brief Constructor.
   *  \param index Video source index for naming purposes.
   */
  explicit RawFrameGrabberTask(std::string name);

  /*! \brief Enable.disable logging into Nizza logfile
   */
  static void setVerbose(bool);

  /*! \brief Get individual frame
   *  \details Get a new frame.
   *  \param timeoutMilliseconds How long to wait for a frame
   *  (or -1 to use default timeout: 500 ms).
   *  \returns Pointer to cv::Mat - should be deleted when no longer needed
   */
  cv::Mat* getFrame(int timeoutMilliseconds = -1);

 private:
  /*! \brief Called by Nizza when graph starts
   */
  void commence() override;

  /*! \brief Called by Nizza when graph stops
   */
  void conclude() override;

  /*! \brief Called by Nizza for every frame
   *  \details Processes single frame. Can be called by multiple threads at same time -
   *  but for different frames.
   *  \param groupName Input group name.
   *  \param media List of input media (frames) will always contain 1 element.
   *  \param output Output media.
   *  \returns True - to continue processing, false - to abort processing.
   */
  bool process(const std::string& groupName, const std::vector<Nizza::Media*>& media,
               Nizza::Output& output) override;

  /*! \brief Saves a frame
   *  \details Saves individual frame in buffer (to be retrieved by user code
   *   or by another Fortis plugin).
   */
  bool saveFrame(cv::Mat* outData);

  /*! Flag to indicate if a frame should be saved.
   * \details If != 0, there're some outstanding requests (by
   * user code or by some Fortis plugin) to get an individual frame.
   */
  QAtomicInt m_needFrame;

  /*! \brief Protects saved image cache
   */
  std::mutex m_frameLock;

  /*! \brief Signals that new frame arrived.
   *  \details Signals when a new frame just arrived (only used
   *  if there're some outstanding requests to get a frame).
   */
  std::condition_variable m_frameArrived;

  /*! \brief Cache for saving a frame
   */
  cv::Mat m_savedFrame;

  /*! \brief Default getFrame() timeout
   *  \details Default timeout to wait in getFrame() function.
   *  value: 500 milliseconds.
   */
  const int m_defaultGetFrameTimeout = 5000;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_RAWFRAMEGRABBERTASK_H_
