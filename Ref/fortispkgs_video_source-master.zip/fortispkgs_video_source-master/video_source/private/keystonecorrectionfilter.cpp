/*! \file keystonecorrectionfilter.cpp
 *  \brief Contains implementation of keystone correction filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include "video_source/private/keystonecorrectionfilter.h"

namespace video {
namespace source {

/*!
 * \brief The KeystoneCorrectionFilter::State struct contains internal Sharpen filter data.
 */
struct KeystoneCorrectionFilter::State {
 public:
  /*!
   * \brief Warp transformation parameters.
   */
  QTransform homography;

  /*!
   * \brief Interpolation type to perform.
   */
  image_filters::InterpolationType interpolationType;

  /*!
   * \brief keystoneData Keystone correction image filter data.
    \details Keystone correction data are determined based on the first frame and should not change
   while pipeline is running.
   */
  std::shared_ptr<image_filters::KeystoneCorrectionData> keystoneData;

  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief Output image size based on filter configuration.
   * \details Output size should not change while pipeline is running.
   */
  QRect outputRect;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;
};

KeystoneCorrectionFilter::KeystoneCorrectionFilter(
    ulong index, const QTransform &homography, const QRect& outputRect,
    KeystoneCorrectionFilterConfig::Quality quality,
    std::shared_ptr<image_filters::ImageFilter> imageFilter)
    : OptionalImageFilterNizzaTask(QString("%1:Keystone correction").arg(index).toStdString(),
                                   imageFilter) {
  m_state = std::make_unique<State>();
  m_state->interpolationType = static_cast<image_filters::InterpolationType>(quality);

  m_state->homography = homography;
  m_state->outputRect = outputRect;
}

/***********************************************************************************/

QRect KeystoneCorrectionFilter::outputRect() const
{
    return m_state->outputRect;
}

/***********************************************************************************/

Mir *KeystoneCorrectionFilter::process(Mir *in) {
  MirFormat format = in->format;
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();
  auto imageSize = m_state->imageSize;
  auto keystoneData = m_state->keystoneData;
  auto homography = m_state->homography;
  auto outputRect = m_state->outputRect;
  auto interpolationType = m_state->interpolationType;
  m_state->mutex.unlock();

  auto outputImage = new Mir(static_cast<uint32>(outputRect.width()),
                             static_cast<uint32>(outputRect.height()), format);
  outputImage->timestamp = in->timestamp;

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));
    m_state->mutex.unlock();
  }

  image_filters::SourceImage sourceImage{imageSize, QImage::Format_RGB888, inputBuffer};

  if (keystoneData == nullptr) {
    m_state->mutex.lock();
    keystoneData = m_state->keystoneData = m_imageFilter->keystoneCorrectionInit(
        sourceImage, homography, outputRect, interpolationType);
    m_state->mutex.unlock();
  }

  auto outputBuf = outputImage->getBuffer(Mir::imageBuffer);

  m_imageFilter->keystoneCorrection(sourceImage, outputBuf, keystoneData);

  return outputImage;
}

}  // namespace source
}  // namespace video
