/*! \file nullsinktask.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_NULLSINKTASK_H_
#define VIDEO_SOURCE_PRIVATE_NULLSINKTASK_H_

#include <Nizza.h>

#include <memory>
#include <string>
#include <vector>

namespace video {
namespace source {

/*!
 * \brief The NullSinkTask class provides Null sink (throws away the frames). Useful when consumer
 * is interested only in
 * processing the frames provided by FrameGrabber.
 */
class NullSinkTask : public Nizza::Task {
 public:
  /*!
   * \brief Constructor.
   */
  explicit NullSinkTask(std::string name, int sourceCount);

 private:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  /*! \brief Called by Nizza when graph starts
   */
  void commence() override;

  /*! \brief Called by Nizza when graph stops
   */
  void conclude() override;

  /*! \brief Called by Nizza for every frame
   *  \details Processes single frame. Can be called by multiple threads at same time -
   *  \details but for different frames.
   *  \param groupName Input group name.
   *  \param media List of input media (frames).
   *  \param output Output media.
   *  \returns True - to continue processing, false - to abort processing.
   */
  bool process(const std::string&, const std::vector<Nizza::Media*>&, Nizza::Output&) override;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_NULLSINKTASK_H_
