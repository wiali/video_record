/*! \file colorcorrectionfilter_p.cpp
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include "video_source/private/colorcorrectionfilter_p.h"

namespace video {
namespace source {

/*!
 * \brief The ColorCorrectionFilter::State struct contains internal auto white balance filter data.
 */
struct ColorCorrectionFilterPrivate::State {
 public:
  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;

  /*!
   * \brief illuminationCorrectionData Color correction image filter data.
   * \details Color correction data are determined based on the first frame and should not change
   * while pipeline is running.
   */
  std::shared_ptr<image_filters::ColorCorrectionData> colorCorrectionData;

  /*!
   * \brief Illumination coefficients from configuration.
   */
  QGenericMatrix<3, 8, float> colorCoefficients;
};

ColorCorrectionFilterPrivate::ColorCorrectionFilterPrivate(ulong index,
    std::shared_ptr<image_filters::ImageFilter> imageFilter, ColorCorrectionFilter *parent)
    : OptionalImageFilterNizzaTask(QString("%1:Color correction").arg(index).toStdString(),
                                   imageFilter),
      q_ptr(parent),
      m_mode(ColorCorrectionFilter::Mode::LampOff) {
  m_state = std::make_unique<State>();  
}

/***********************************************************************************/

ColorCorrectionFilter::Mode ColorCorrectionFilterPrivate::mode() const { return m_mode; }

/***********************************************************************************/

QGenericMatrix<3, 8, float> ColorCorrectionFilterPrivate::lampOnCoefficients() const { return m_lampOnCoefficients; }

/***********************************************************************************/

QGenericMatrix<3, 8, float> ColorCorrectionFilterPrivate::lampOffCoefficients() const { return m_lampOffCoefficients; }

/***********************************************************************************/

void ColorCorrectionFilterPrivate::setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (m_lampOnCoefficients != coefficients) {
    m_lampOnCoefficients = coefficients;

    if (m_mode == ColorCorrectionFilter::Mode::LampOn) {
        m_state->mutex.lock();
        m_state->colorCoefficients = m_lampOnCoefficients;
        m_state->mutex.unlock();
    }
  }
}

/***********************************************************************************/

void ColorCorrectionFilterPrivate::setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients) {
  if (m_lampOffCoefficients != coefficients) {
    m_lampOffCoefficients = coefficients;

    if (m_mode == ColorCorrectionFilter::Mode::LampOff) {
        m_state->mutex.lock();
        m_state->colorCoefficients = m_lampOffCoefficients;
        m_state->mutex.unlock();
    }
  }
}

/***********************************************************************************/

void ColorCorrectionFilterPrivate::setMode(ColorCorrectionFilter::Mode mode) {
  if (m_mode != mode) {
    Q_Q(ColorCorrectionFilter);

    m_state->mutex.lock();
    m_state->colorCorrectionData.reset();

    switch (mode) {
      case ColorCorrectionFilter::Mode::LampOff:
        m_state->colorCoefficients = m_lampOffCoefficients;
        break;
      case ColorCorrectionFilter::Mode::LampOn:
        m_state->colorCoefficients = m_lampOnCoefficients;
        break;
    }

    m_state->mutex.unlock();
    m_mode = mode;

    emit q->modeChanged(m_mode);
  }
}

/***********************************************************************************/

Mir *ColorCorrectionFilterPrivate::process(Mir *in) {
  MirFormat format = in->format;
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();
  auto imageSize = m_state->imageSize;
  auto colorCorrectionData = m_state->colorCorrectionData;
  m_state->mutex.unlock();

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));
    m_state->mutex.unlock();
  }

  image_filters::SourceImage sourceImage{m_state->imageSize, QImage::Format_RGB888, inputBuffer};

  if (colorCorrectionData == nullptr) {
    m_state->mutex.lock();

    colorCorrectionData = m_state->colorCorrectionData =
        m_imageFilter->colorCorrectionInit(imageSize, m_state->colorCoefficients);

    m_state->mutex.unlock();
  }

  Mir *outputImage = new Mir(w, h, format);
  outputImage->timestamp = in->timestamp;

  auto outputBuf = outputImage->getBuffer(Mir::imageBuffer);

  m_imageFilter->colorCorrection(sourceImage, outputBuf, colorCorrectionData);

  return outputImage;  // continue
}

}  // namespace source
}  // namespace video
