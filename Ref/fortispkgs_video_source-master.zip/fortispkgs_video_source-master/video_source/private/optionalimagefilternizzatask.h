/*! \file optionalimagefilternizzatask.h
 *  \brief Contains implementation of base class for image enhancement filter.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_OPTIONALIMAGEFILTERNIZZATASK_H_
#define VIDEO_SOURCE_PRIVATE_OPTIONALIMAGEFILTERNIZZATASK_H_

#include <image_filters/imagefilter.h>

#include <atomic>
#include <memory>
#include <string>
#include <vector>

#include <Nizza.h>
#include <NizzaBeans.h>

namespace video {
namespace source {

/*!
 * \brief The OptionalImageFilterNizzaTask class provides base implementation of optional Nizza task
 * \brief that performs image enhancement and can be enabled or disabled.
 */
class OptionalImageFilterNizzaTask : public Nizza::Task {
 public:
  /*!
   * \brief Destructor.
   */
  virtual ~OptionalImageFilterNizzaTask() = default;

  /*!
   * \brief Returns if this filter is enabled or not.
   */
  bool enabled() const;

  /*!
   * \brief Sets if this filter is enabled or not.
   * \param isEnabled New value indicating if this filter is enabled or not.
   */
  virtual void setEnabled(bool enabled);

 protected:
  /*! \brief Called by Nizza when graph starts
   */
  void commence() override;

  /*! \brief Called by Nizza when graph stops
   */
  void conclude() override;

  /*! \brief Enable.disable logging into Nizza logfile
   */
  static void setVerbose(bool);

  /*! \brief Called by Nizza for every frame
   *  \details Processes single frame. Can be called by multiple threads at same time -
   *  \details but for different frames.
   *  \param groupName Input group name.
   *  \param media List of input media (frames) will always contain 1 element.
   *  \param output Output media.
   *  \returns True - to continue processing, false - to abort processing.
   */
  bool process(const std::string& groupName, const std::vector<Nizza::Media*>& media,
               Nizza::Output& output) override;

  /*!
   * \brief Constructor.
   * \param name Name of the filter.
   * \param imageFilter imageFilter Instance of ImageFilter used to perform the operation.
   */
  OptionalImageFilterNizzaTask(const std::string& name,
                               std::shared_ptr<image_filters::ImageFilter> imageFilter);

  /*! \brief Processes the current raw input image and returns new raw output image.
   * \param input Input raw image.
   * \returns Output raw image.
   */
  virtual Mir* process(Mir* input) = 0;

  /*! \brief Shared instance of ImageFilter.
   */
  std::shared_ptr<image_filters::ImageFilter> m_imageFilter;

  /*! \brief Indicates if this filter is enabled or not.
   */
  std::atomic<bool> m_enabled;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_OPTIONALIMAGEFILTERNIZZATASK_H_
