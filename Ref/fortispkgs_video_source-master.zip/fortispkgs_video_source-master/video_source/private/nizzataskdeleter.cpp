/*! \file nizzataskdeleter.cpp
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <DSVideoSink.h>
#include <Nizza.h>

#include <CompositorGPU.h>
#include <DSSource.h>

#include "video_source/private/autowhitebalancefilter_p.h"
#include "video_source/private/colorcorrectionfilter_p.h"
#include "video_source/private/combinedopenglfilter_p.h"
#include "video_source/private/finalframegrabbertask.h"
#include "video_source/private/illuminationcorrectionfilter_p.h"
#include "video_source/private/keystonecorrectionfilter.h"
#include "video_source/private/mirrortask.h"
#include "video_source/private/nizzataskdeleter.h"
#include "video_source/private/nullsinktask.h"
#include "video_source/private/rawframegrabbertask.h"
#include "video_source/private/sharpenfilter.h"
#include "video_source/private/orbbeccapturetasksource.h"
#include "video_source/private/combinedopenglfilter_p.h"

namespace video {
namespace source {

void destroyNizzaFilter(Nizza::Task *task) {
  if (task != nullptr) {
    Nizza::disconnect(task);
    Nizza::destroy(task);
  }
}

template <>
void NizzaTaskDeleter<DSVideoSink>::operator()(DSVideoSink *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<NullSinkTask>::operator()(NullSinkTask *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<DSSource>::operator()(DSSource *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<CompositorGPU>::operator()(CompositorGPU *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<ImageConverter>::operator()(ImageConverter *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<KeystoneCorrectionFilter>::operator()(KeystoneCorrectionFilter *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<SharpenFilter>::operator()(SharpenFilter *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<RawFrameGrabberTask>::operator()(RawFrameGrabberTask *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<MirrorTask>::operator()(MirrorTask *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<CombinedOpenGLFilter>::cleanup(CombinedOpenGLFilter *sink) {
    if (sink != nullptr) {
      auto filter = sink->d_ptr.take();
      destroyNizzaFilter(filter);
      delete sink;
    }
}

template <>
void NizzaTaskDeleter<AutoWhiteBalanceFilter>::cleanup(AutoWhiteBalanceFilter *sink) {
  if (sink != nullptr) {
    auto filter = sink->d_ptr.take();
    destroyNizzaFilter(filter);
    delete sink;
  }
}

template <>
void NizzaTaskDeleter<ColorCorrectionFilter>::cleanup(ColorCorrectionFilter *sink) {
  if (sink != nullptr) {
    auto filter = sink->d_ptr.take();
    destroyNizzaFilter(filter);
    delete sink;
  }
}

template <>
void NizzaTaskDeleter<FinalFrameGrabberTask>::cleanup(FinalFrameGrabberTask *sink) {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<IlluminationCorrectionFilter>::cleanup(IlluminationCorrectionFilter *sink) {
  if (sink != nullptr) {
    auto filter = sink->d_ptr.take();
    destroyNizzaFilter(filter);
    delete sink;
  }
}

template <>
void NizzaTaskDeleter<DesktopCaptureWindows>::operator()(DesktopCaptureWindows *sink) const {
  destroyNizzaFilter(sink);
}

template <>
void NizzaTaskDeleter<OrbbecCapture>::operator()(OrbbecCapture *sink) const {
  destroyNizzaFilter(sink);
}

}  // namespace source
}  // namespace video
