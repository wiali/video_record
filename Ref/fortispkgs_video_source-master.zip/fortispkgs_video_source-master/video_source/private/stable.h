/*! \file stable.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_STABLE_H_
#define VIDEO_SOURCE_PRIVATE_STABLE_H_

// Speed up compilation by adding common, infrequently changed headers here

#include <QtCore/qglobal.h>
#include <QByteArray>
#include <QDateTime>
#include <QDebug>
#include <QException>
#include <QFile>
#include <QGenericMatrix>
#include <QImage>
#include <QJsonArray>
#include <QJsonObject>
#include <QList>
#include <QMap>
#include <QMatrix3x3>
#include <QMetaEnum>
#include <QMetaType>
#include <QObject>
#include <QPointer>
#include <QRect>
#include <QScopedPointer>
#include <QSharedMemory>
#include <QSharedPointer>
#include <QSize>
#include <QString>
#include <QStringList>
#include <QTimer>
#include <QUuid>
#include <QVector>

#include <DSSource.h>
#include <DSVideoSink.h>
#include <Nizza.h>
#include <NizzaBeans.h>
#include <NizzaMedia.h>
#include <NizzaMonitor.h>
#include <calibration_data.h>
#include <image_filters/imagefilter.h>
#include <image_filters/imagefilterexception.h>
#include <touchmat/touchmat.h>

#include <sensor_data.h>
#include <settings.h>

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <iterator>
#include <memory>
#include <mutex>
#include <thread>

#ifdef Q_OS_WIN

#include <windows.h>

#endif

#endif  // VIDEO_SOURCE_PRIVATE_STABLE_H_
