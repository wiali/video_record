/*! \file sharpenfilter.cpp
 *  \brief Contains implementation of sharpen filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include "video_source/private/sharpenfilter.h"

namespace video {
namespace source {

/*!
 * \brief The SharpenFilter::State struct contains internal Sharpen filter data.
 */
struct SharpenFilter::State {
 public:
  /*!
   * \brief sharpenData Sharpen image filter data.
   */
  std::shared_ptr<image_filters::SharpenData> sharpenData;

  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;
};

/***********************************************************************************/

SharpenFilter::SharpenFilter(ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter)
    : OptionalImageFilterNizzaTask(QString("%1:Sharpen").arg(index).toStdString(), imageFilter) {
  m_state = std::make_unique<State>();
}

/***********************************************************************************/

Mir* SharpenFilter::process(Mir* in) {
  MirFormat format = in->format;
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();
  auto imageSize = m_state->imageSize;
  auto sharpenData = m_state->sharpenData;
  m_state->mutex.unlock();

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));
    m_state->mutex.unlock();
  }

  image_filters::SourceImage sourceImage{m_state->imageSize, QImage::Format_RGB888, inputBuffer};

  if (sharpenData == nullptr) {
    m_state->mutex.lock();
    sharpenData = m_state->sharpenData = m_imageFilter->sharpenInit(sourceImage);
    m_state->mutex.unlock();
  }

  Mir* outputImage = new Mir(w, h, format);
  outputImage->timestamp = in->timestamp;

  auto outputBuf = outputImage->getBuffer(Mir::imageBuffer);

  m_imageFilter->sharpen(sourceImage, outputBuf, sharpenData);

  return outputImage;
}

}  // namespace source
}  // namespace video
