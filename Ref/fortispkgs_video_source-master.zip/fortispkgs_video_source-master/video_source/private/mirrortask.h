/*! \file mirrortask.h
 *  \brief Contains implementation of Mirror filter as Nizza task.
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_MIRRORTASK_H_
#define VIDEO_SOURCE_PRIVATE_MIRRORTASK_H_

#include <memory>

#include "video_source/mirrorfilterconfig.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The MirrorTask class provides optional filter for mirroring the image in the pipeline.
 */
class MirrorTask : public OptionalImageFilterNizzaTask {
 public:
  /*! \brief Constructor.
   *  \param index Video source index for naming purposes.
   *  \param imageFilter Instance of ImageFilter used to perform the operation.
   *  \param configuration Reference to filter configuration.
   */
  MirrorTask(ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter,
             const MirrorFilterConfig& configuration);

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir* process(Mir* in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_MIRRORTASK_H_
