/*! \file videopipeline_p.cpp
 *
 *  \brief Contains implementation of video source class plug-in package super cool.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QDateTime>
#include <QDebug>
#include <QImage>
#include <QJsonObject>
#include <QMap>
#include <QMetaEnum>
#include <QSharedMemory>
#include <QSharedPointer>

#include <atomic>
#include <iterator>
#include <thread>
#include <vector>

#ifdef Q_OS_WIN32
#include <GL/GL.h>
#include <windows.h>
#endif

#include <Rock.h>
#include <opencv2/opencv.hpp>

#include "video_source/invalidconfigurationexception.h"
#include "video_source/invalidoperationexception.h"
#include "video_source/nizzaexception.h"
#include "video_source/videopipeline.h"
#include "video_source/videopipelinestatemismatchexception.h"

#include "video_source/private/sourcepipeline_p.h"
#include "video_source/private/videopipeline_p.h"

namespace video {
namespace source {

std::atomic<bool> VideoPipelinePrivate::m_isNizzaStarted(false);

/*! \brief Declares the names of keys in configuration file.
 */
class SettingsNames {
 public:
  /*! \brief Declares the section prefix for pipeline input source.
   *  \details [String] Default value is `source:`.
   */
  static const QString SourceSectionPrefix;

  /*! \brief Declares the keystone correction filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `keystone_correction:`.
   */
  static const QString KeystoneCorrectionFilterSectionPrefix;

  /*! \brief Declares the illumination correction filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `illumination_correction:`.
   */
  static const QString IlluminationCorrectionFilterSectionPrefix;

  /*! \brief Declares the sharpen filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `sharpen:`.
   */
  static const QString SharpenFilterSectionPrefix;

  /*! \brief Declares the auto white balance filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `auto_white_balance:`.
   */
  static const QString AutoWhiteBalanceFilterSectionPrefix;

  /*! \brief Declares the color correction filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `color_correction:`.
   */
  static const QString ColorCorrectionFilterSectionPrefix;

  /*! \brief Declares the framegrabber filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `frame_grabber`.
   */
  static const QString FramegrabberFilterSectionPrefix;

  /*! \brief Declares the mirror filter section prefix for pipeline.
   *  \details [String] This section is optional. Default value is `mirror:`.
   */
  static const QString MirrorFilterSectionPrefix;

  /*! \brief Declares the section prefix for pipeline output sink.
   *  \details [Integer] This section is optional. Default value is `default_sink`.
   */
  static const QString DefaultSinkSectionPrefix;

  /*! \brief Declares the section prefix for still capture.
   *  \details [Integer] This section is optional. Default value is `still_capture`.
   */
  static const QString StillCaptureSectionPrefix;

  class OutputSinkConfiguration {
   public:
    /*! \brief Indicates delay between redraws after viewport updates (pan or zoom operations).
     *  \details [UInt]. Default value is 25.
     */
    static const QString ViewportRedrawDelay;

    /*! \brief Indicates if Nizza monitor window should be displayed.
     *  \details [Boolean]. Default value is false.
     */
    static const QString MonitorWindowSize;
  };

  /*! \brief Declares the common names of the keys.
   */
  class Common {
   public:
    /*! \brief Declares the name value.
     *  \details [String].
     */
    static const QString Name;

    /*! \brief Declares the frame rate value.
     *  \details [Integer].
     */
    static const QString FrameRate;

    /*! \brief Declares the frame size.
     *  \details [QSize].
     */
    static const QString Size;

    /*! \brief Declares if the filter is included in pipeline.
     *  \details [Boolean]. Default value is false.
     */
    static const QString IsIncluded;

    /*! \brief Declares capture type that will be passed into SensorData.
     *  \details [String] Default value is `hiresrgb`.
     */
    static const QString CaptureType;

    /*! \brief Screen index.
     *  \details [Integer]. Default value 0 (primary screen).
     */
    static const QString Screen;

    /*! \brief Contains information about physical size of the input device in meters, used for DPI calculation.
     *  \details [QSizeF] If set to (0x0) then DPI will not be calculated and inserted to final image.
     */
    static const QString DeviceDimensions;

    /*! \brief Contains information about selected backend.
     *  \details [String] Default value is 'IntelIPP'.
     */
    static const QString Backend;
  };

  /*! \brief Declares the names of the keystone correction filter.
   */
  class KeystoneCorrectionFilter {
   public:
    /*! \brief Declares name of homography matrix.
     *  \details [String].
     */
    static const QString HomographyMatrixName;

    /*! \brief Declares which quality level should be used.
     *  \details [String]. Possible values: nearest, linear (default).
     */
    static const QString Quality;
  };

  /*! \brief Declares the names of the illumination correction filter.
   */
  class IlluminationCorrectionFilter {
   public:
    /*! \brief Declares if the auto white balance should be performed together with illumination
     * correction.
     *  \details [Boolean]. Default value is false.
     */
    static const QString IsAutoWhiteBalanceEnabled;

    /*! \brief Declares coefficients.
     *  \details [String]. Declares mapping to calibration illumination data name.
     */
    static const QString DatasetName;
  };

  /*! \brief Declares the names of the illumination correction filter.
   */
  class ColorCorrectionFilter {
   public:
    /*! \brief Declares lamp on coefficients.
     */
    static const QString LampOnDatasetName;

    /*! \brief Declares lamp off coefficients.
     */
    static const QString LampOffDatasetName;
  };

  /*! \brief Declares the names of the frame grabber filter.
   */
  class FrameGrabberFilter {
   public:
    /*! \brief Declares which format should be used.
     *  \details [String]. See `FinalFrameGrabberConfig::Format` for possible values.
     */
    static const QString Format;
  };

  /*! \brief Declares the names of the frame grabber filter.
   */
  class MirrorFilter {
   public:
    /*! \brief Declares which mirroring type should be used.
     *  \details [String]. See `MirrorFilterConfig::Type` for possible values.
     */
    static const QString Type;
  };
};

const QString SettingsNames::SourceSectionPrefix = QString("source:");
const QString SettingsNames::KeystoneCorrectionFilterSectionPrefix =
    QString("keystone_correction:");
const QString SettingsNames::IlluminationCorrectionFilterSectionPrefix =
    QString("illumination_correction:");
const QString SettingsNames::SharpenFilterSectionPrefix = QString("sharpen:");
const QString SettingsNames::FramegrabberFilterSectionPrefix = QString("frame_grabber:");
const QString SettingsNames::AutoWhiteBalanceFilterSectionPrefix = QString("auto_white_balance:");
const QString SettingsNames::ColorCorrectionFilterSectionPrefix = QString("color_correction:");
const QString SettingsNames::MirrorFilterSectionPrefix = QString("mirror:");
const QString SettingsNames::DefaultSinkSectionPrefix = QString("default_sink:");
const QString SettingsNames::StillCaptureSectionPrefix = QString("still_capture:");

const QString SettingsNames::OutputSinkConfiguration::ViewportRedrawDelay =
    QString("viewport_redraw_delay");
const QString SettingsNames::OutputSinkConfiguration::MonitorWindowSize =
    QString("monitor_window_size");

const QString SettingsNames::Common::Name = QString("name");
const QString SettingsNames::Common::FrameRate = QString("frame_rate");
const QString SettingsNames::Common::Size = QString("size");
const QString SettingsNames::Common::IsIncluded = QString("included");
const QString SettingsNames::Common::CaptureType = QString("capture_type");
const QString SettingsNames::Common::Screen = QString("screen");
const QString SettingsNames::Common::DeviceDimensions = QString("device_dimensions");
const QString SettingsNames::Common::Backend = QString("backend");

const QString SettingsNames::KeystoneCorrectionFilter::HomographyMatrixName =
    QString("homography_matrix");
const QString SettingsNames::KeystoneCorrectionFilter::Quality = QString("quality");

const QString SettingsNames::IlluminationCorrectionFilter::IsAutoWhiteBalanceEnabled =
    QString("auto_white_balance_enabled");
const QString SettingsNames::IlluminationCorrectionFilter::DatasetName =
    QString("dataset");

const QString SettingsNames::ColorCorrectionFilter::LampOffDatasetName =
    QString("lamp_off_dataset");
const QString SettingsNames::ColorCorrectionFilter::LampOnDatasetName =
    QString("lamp_on_dataset");

const QString SettingsNames::FrameGrabberFilter::Format = QString("format");

const QString SettingsNames::MirrorFilter::Type = QString("type");

/***********************************************************************************/

#ifdef Q_OS_WIN

/*!
 * \brief Callback for Win32 EnumDisplayMonitors function (MonitorEnumProc).
 * \param hMonitor A handle to the display monitor.
 * \param lprcMonitor A pointer to a RECT structure.
 * \param dwData Must be a pointer to QVector<QRect> object.
 */
BOOL QT_WIN_CALLBACK EnumDisplayMonitorsCallback(HMONITOR hMonitor, HDC, LPRECT lprcMonitor,
                                                 LPARAM dwData) {
  Q_UNUSED(hMonitor)
  auto screenConfiguration = reinterpret_cast<QVector<QRect>*>(dwData);

  qDebug() << "EnumDisplayMonitorsCallback :: Found screen:" << lprcMonitor->left
           << lprcMonitor->top << lprcMonitor->right << lprcMonitor->bottom;
  screenConfiguration->push_back(QRect(lprcMonitor->left, lprcMonitor->top,
                                       lprcMonitor->right - lprcMonitor->left,
                                       lprcMonitor->bottom - lprcMonitor->top));

  return TRUE;
}

#endif

/***********************************************************************************/

QSharedPointer<hp::fortis::Settings> VideoPipelinePrivate::settings(QString group) {
  return QSharedPointer<hp::fortis::Settings>::create(QString("HP/%1").arg(PACKAGE_NAME), group);
}

/***********************************************************************************/

VideoPipelinePrivate::VideoPipelinePrivate(VideoPipeline* parent)
    : q_ptr(parent),
      m_state(VideoPipeline::VideoPipelineState::Unintialized),
      m_lastZoomPanRedraw(std::chrono::system_clock::now()) {
  m_imageFilters = std::make_shared<image_filters::ImageFilter>();

  auto outputSinkSection = settings(SettingsNames::DefaultSinkSectionPrefix);
  OutputVideoSinkConfig config;

  config.name =
      outputSinkSection->value(SettingsNames::Common::Name, "Fortis Video Source").toString();
  config.size = outputSinkSection->value(SettingsNames::Common::Size, QSize(2200, 1660)).toSize();
  config.viewportRedrawDelay =
      outputSinkSection->value(SettingsNames::OutputSinkConfiguration::ViewportRedrawDelay, 25)
          .toInt();
  config.monitorWindowSize =
      outputSinkSection->value(SettingsNames::OutputSinkConfiguration::MonitorWindowSize, QSize())
          .toSize();

  setOutputSinkConfiguration(config);
}

const calibration::CalibrationData& VideoPipelinePrivate::calibrationData() {
    if (m_calibrationData.timeStamp == 0)
    {
        m_calibrationData.load();
        qDebug() << "Calibration data loaded from" << m_calibrationData.lastUsedFile();
    }
    return m_calibrationData;
}

void VideoPipelinePrivate::setOutputSinkConfiguration(const OutputVideoSinkConfig& configuration) {
  if (m_sources.count() == 0) {
    verifyState(VideoPipeline::VideoPipelineState::Unintialized, "setOutputSinkConfiguration");
  } else {
    verifyState(VideoPipeline::VideoPipelineState::Stopped, "setOutputSinkConfiguration");
  }

  if (m_configuration != configuration) {
    m_configuration = configuration;
    Q_Q(VideoPipeline);

    emit q->outputSinkConfigurationChanged(m_configuration);
  }
}

/***********************************************************************************/

VideoPipelinePrivate::~VideoPipelinePrivate() {
  reset();
  Nizza::end();
  m_isNizzaStarted = false;
}

/***********************************************************************************/

QVector<sensordata::SensorData> VideoPipelinePrivate::capture(QStringList stillFrameSources) {
  verifyState(VideoPipeline::VideoPipelineState::Running, "captureFrame");

  QVector<sensordata::SensorData> result;
  QVector<QSharedPointer<SourcePipeline>> enabledSources;

  for (auto& source : m_sources) {
    if (source->enabled()) {
      enabledSources << source;
    }
  }

  const auto sourceCount = enabledSources.count();

  if (sourceCount == 0) {
    throw InvalidOperationException(tr("All input sources are disabled"));
  } else {
    for (int i = 0; i < sourceCount; i++) {
      auto source = enabledSources[i];

      sensordata::SensorData sensorData;

      if (stillFrameSources.contains(source->name())) {
          sensorData = source->captureStillFrame();
      } else {
          sensorData = source->captureVideoFrame();
      }

      sensorData.calibrationData = calibrationData();
      sensorData.metadata["name"] = source->name();
      sensorData.metadata["index"] = i;
      sensorData.metadata["pipeline"] =
          QJsonObject{{"sourceCount", sourceCount},
                      {"width", static_cast<int>(m_configuration.size.width())},
                      {"height", static_cast<int>(m_configuration.size.height())}};

      result << sensorData;
    }
  }

  return result;
}

/***********************************************************************************/

void VideoPipelinePrivate::setState(const VideoPipeline::VideoPipelineState& state) {
  if (m_state != state) {
    m_state = state;
    Q_Q(VideoPipeline);

    emit q->stateChanged(state);
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::concludeCallbackUserData(void* callbackUserData, bool hadError,
                                                    const std::string& errorString, int errorCode) {
  if (callbackUserData != nullptr) {
    auto self = static_cast<VideoPipelinePrivate*>(callbackUserData);

    if (hadError) {
      auto message = QString("Code %1: %2").arg(errorCode).arg(QString::fromStdString(errorString));

      self->setState(VideoPipeline::VideoPipelineState::Stopped);
      throw NizzaException("Unexpected error occured while video pipeline was running",
                           message.toStdString().c_str());
    } else if (self->state() != VideoPipeline::VideoPipelineState::Unintialized) {
      self->setState(VideoPipeline::VideoPipelineState::Stopped);
    }
  } else {
    qCritical() << "Conclude callback has not received callbackUserData";
  }
}

/***********************************************************************************/

Nizza::Task* VideoPipelinePrivate::sink() {
  return m_dsVideoSink ? static_cast<Nizza::Task*>(m_dsVideoSink.get())
                       : static_cast<Nizza::Task*>(m_nullSink.get());
}

/***********************************************************************************/

void VideoPipelinePrivate::start() {
  verifyState(VideoPipeline::VideoPipelineState::Stopped, "start");

  if (!m_isNizzaStarted) {
    auto logPath = m_logPath;

    if (logPath.isNull()) {
      auto outputSinkSection = settings(SettingsNames::DefaultSinkSectionPrefix);
      logPath = outputSinkSection->defaultPath() + "/nizza_logs";
    }

    qInfo() << this << "Setting Nizza logs to" << logPath;

    try {
        Rock::Log::setDirectory(logPath.toStdString());
    } catch (std::string& ex) {
        qWarning() << this << "Cannot set Nizza log location, reason:" << QString::fromStdString(ex);
    }

    m_isNizzaStarted = true;
    Nizza::begin();
  }

  if (m_sources.count() == 0) {
    throw InvalidOperationException(tr("Pipeline must contain least one source before starting"));
  } else {
    try {
      setState(VideoPipeline::VideoPipelineState::Starting);

      qInfo() << this << "Constructing Nizza pipeline with configuration" << m_configuration;

      // If we have more than one source we either need a compositor or it needs to go to
      if (m_sources.count() > 1)
      {
          if (m_configuration.name.isEmpty() && !m_configuration.size.isEmpty()) {
            throw InvalidConfigurationException(
                QString("Pipeline has %1 sources but no compositor").arg(m_sources.count()));
          }
      }

      m_dsSource.reset(new DSSource(QString("DSSource:%1").arg(qrand()).toStdString()));

      if (m_configuration.monitorWindowSize.isValid()) {
        qInfo() << this << "Creating Nizza Monitor";
        m_nizzaMonitor = std::make_unique<NizzaMonitor>();
        m_nizzaMonitor->resize(static_cast<ulong>(m_configuration.monitorWindowSize.width()),
                               static_cast<ulong>(m_configuration.monitorWindowSize.height()));
        m_nizzaMonitor->show(true);
      }

      QString sinkInputPin = "image";

      if (m_configuration.name.isEmpty()) {
        sinkInputPin = "image 0";
        m_nullSink = std::unique_ptr<NullSinkTask, NizzaTaskDeleter<NullSinkTask>>(
            new NullSinkTask("Null sink", m_sources.count()));
      } else {
        m_dsVideoSink =
            std::unique_ptr<DSVideoSink, NizzaTaskDeleter<DSVideoSink>>(new DSVideoSink("DSSink"));        
      }

      if (!m_configuration.size.isEmpty() &&
          // Skip compositor if we have just one source doing resizing
          (m_sources.count() > 1 || m_sources.first()->configuration().backend == SourcePipelineConfig::Backend::IntelIPP)) {
        qDebug() << this << "Setting video boundaries to" << m_configuration.size;

        const auto compositor =
            new CompositorGPU("FortisGpu1", CompositorGPU::modeOffscreen,
                              static_cast<uint32>(m_configuration.size.width()),
                              static_cast<uint32>(m_configuration.size.height()));

        m_compositorGpu =
            std::unique_ptr<CompositorGPU, NizzaTaskDeleter<CompositorGPU>>(compositor);

        m_compositorGpu->setNumberInputs(static_cast<uint32>(m_sources.count()));
        m_compositorGpu->setAlphaBlending(false);
        m_compositorGpu->setOutputBGR(true);

        Nizza::connect(m_compositorGpu.get(), "out", "image", sinkInputPin.toStdString(), "in",
                       sink());
      }

      for (auto& source : m_sources) {
        auto pinIndex = m_sourceToCompositorPinMapping[source->name()];
        auto lastFilter = source->d_ptr->lastTask(m_dsSource.get(), pinIndex, m_configuration, calibrationData());

        if (m_compositorGpu || m_nullSink) {
          auto task = m_compositorGpu ? static_cast<Nizza::Task*>(m_compositorGpu.get())
                                      : static_cast<Nizza::Task*>(m_nullSink.get());
          Nizza::connect(lastFilter, "out", "image", "image", stringf("image %d", pinIndex), task);
        } else if (m_dsVideoSink) {
          Nizza::connect(lastFilter, "out", "image", "image", "in", m_dsVideoSink.get());
        }

        if (m_compositorGpu) {
          tryPerformRedraw(source);
        }
      }

      Nizza::setNumThreads(2);

      for (auto& source : m_sources) {
        source->d_ptr->forceUpdate();
      }

      // Start the Nizza graph
      Nizza::start(sink(), concludeCallbackUserData, static_cast<void*>(this));

      setState(VideoPipeline::VideoPipelineState::Running);      
		
      qInfo() << this << "We have liftoff!";
    } catch (const std::string& ex) {
      reset();
      throw NizzaException("Unexpected error occured while video pipeline was starting.", ex);
    } catch (const char* ex) {
      reset();
      throw NizzaException("Unexpected error occured while video pipeline was starting.", ex);
    } catch (...) {
      reset();
      throw;
    }
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::reset() {
  try {
    auto sinkInstance = sink();

    if (sinkInstance) {
      Nizza::stop(sinkInstance);
    }

    m_dsVideoSink.reset();
    m_compositorGpu.reset();
    m_nullSink.reset();
    m_dsSource.reset();
    m_nizzaMonitor.reset();

    for (auto source : m_sources) {
      source->d_ptr->reset();
    }

    m_sourceToCompositorPinMapping.clear();

    setState(m_sources.count() == 0 ? VideoPipeline::VideoPipelineState::Unintialized
                                    : VideoPipeline::VideoPipelineState::Stopped);

    m_isNizzaStarted = false;
    Nizza::end();
  } catch (const std::string& ex) {
    throw NizzaException("Unexpected error occured while video pipeline was stopping", ex.c_str());
  } catch (const char* ex) {
    throw NizzaException("Unexpected error occured while video pipeline was stopping", ex);
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::stop() {
  if (state() == VideoPipeline::VideoPipelineState::Running) {
    qInfo() << this << "Stopping the video pipeline";

    setState(VideoPipeline::VideoPipelineState::Stopping);

    reset();
  }
}

/***********************************************************************************/

OutputVideoSinkConfig VideoPipelinePrivate::outputSinkConfiguration() const {
  return m_configuration;
}

/***********************************************************************************/

QVector<QSharedPointer<SourcePipeline>> VideoPipelinePrivate::sources() {
  QVector<QSharedPointer<SourcePipeline>> result;

  for (auto& source : m_sources) {
    result << source;
  }

  return result;
}

/***********************************************************************************/

QSharedPointer<SourcePipeline> VideoPipelinePrivate::addSource(const QString& name,
                                                               SourcePipelineConfig config) {
  QSharedPointer<SourcePipeline> result;

  if (m_sources.count() == 0) {
    verifyState(VideoPipeline::VideoPipelineState::Unintialized, "addSource");
  } else {
    verifyState(VideoPipeline::VideoPipelineState::Stopped, "addSource");
  }

  auto source = std::find_if(
      std::begin(m_sources), std::end(m_sources),
      [name](const QSharedPointer<SourcePipeline>& source) { return name == source->name(); });

  if (source != std::end(m_sources)) {
    auto message =
        QString(tr("Source with name '%1' is already included in the pipeline")).arg(name);
    throw InvalidOperationException(message);
  }

  // Make sure we add pins to compositor in same order as we added sources
  if (!m_sourceToCompositorPinMapping.contains(name)) {
    m_sourceToCompositorPinMapping.insert(
        name, static_cast<ulong>(m_sourceToCompositorPinMapping.count()));
  }

  qInfo() << this << "Adding new input source" << name << "with configuration:" << config;
  result = QSharedPointer<SourcePipeline>(new SourcePipeline(m_imageFilters));

  result->d_ptr->setName(name);

  QList<QMetaObject::Connection> connections;

  connections << connect(result->d_ptr.data(), &SourcePipelinePrivate::dsSourceIsEnabledChanged,
                         this, &VideoPipelinePrivate::onDsSourceIsEnabledChanged);
  result->setConfiguration(config);

  connections << connect(result.data(), &SourcePipeline::viewportChanged,
                         [this, result]() { tryPerformRedraw(result); });

  connections << connect(result.data(), &SourcePipeline::destinationRectangleChanged,
                         [this, result]() { tryPerformRedraw(result); });

  connections << connect(result.data(), &SourcePipeline::sizeChanged,
                         [this, result]() { tryPerformRedraw(result); });

  connections << connect(result.data(), &SourcePipeline::enabledChanged,
                         [this, result]() { tryPerformRedraw(result); });

  m_sourceConnectionMap.insert(name, connections);

  m_sources << result;

  Q_Q(VideoPipeline);
  q->sourcesChanged(sources());

  setState(VideoPipeline::VideoPipelineState::Stopped);

  return result;
}

/***********************************************************************************/

void VideoPipelinePrivate::onDsSourceIsEnabledChanged(QString sourceName, bool isEnabled) {
  if (m_dsSource) {
    std::vector<std::string> groupNames;
    m_dsSource->getOutputGroups(groupNames);

    auto it =
        std::find_if(std::begin(groupNames), std::end(groupNames),
                     [sourceName](const std::string& n) { return sourceName.toStdString() == n; });

    if (it == std::end(groupNames)) {
      qCritical() << "Cannot find output pin for  source pipeline" << sourceName;
    } else {
      qInfo() << "Setting DirectShow input source" << sourceName << "to" << isEnabled;
      const auto distance = std::distance(std::begin(groupNames), it);

      m_dsSource->setProductionEnabled(static_cast<int>(distance), isEnabled);

      if (isEnabled) {
        m_dsSource->enableProduction();
      }
    }
  }
}

/***********************************************************************************/

QSharedPointer<SourcePipeline> VideoPipelinePrivate::addKnownSource(
    SourcePipeline::SourcePipelineType sourceType, QSize resolution) {
  auto metaEnum = QMetaEnum::fromType<SourcePipeline::SourcePipelineType>();
  auto name = metaEnum.valueToKey(sourceType);
  auto resolutions = knownResolutions(sourceType);

  if (resolution.isEmpty() && resolutions.count() > 0) {
      resolution = resolutions.first();
  }

  if (!resolution.isEmpty() && !resolutions.contains(resolution)) {
      auto message = QString(tr("Resolution %1x%2 for source type %3 is not recognized"))
              .arg(resolution.width()).arg(resolution.height()).arg(sourceType);
      qCritical() << message;
      throw InvalidConfigurationException(message);
  }

  qInfo() << this << "Reading source pipeline" << name << "configuration with resolution" << resolution;

  SourcePipelineConfig config;  

  auto sourceSettings = settings(name);

  config.captureType =
      sourceSettings
          ->value(SettingsNames::Common::CaptureType, config.captureType)
          .toString();

  config.deviceDimensions =
      sourceSettings
          ->value(SettingsNames::Common::DeviceDimensions, config.deviceDimensions)
          .toSizeF();

  metaEnum = QMetaEnum::fromType<SourcePipelineConfig::Backend>();

  auto backendString = sourceSettings
          ->value(SettingsNames::Common::Backend, metaEnum.valueToKey(config.backend))
          .toString();

  bool ok;
  auto backend = static_cast<SourcePipelineConfig::Backend>(metaEnum.keyToValue(backendString.toLocal8Bit(), &ok));

  if (ok) {
      config.backend = backend;
  } else {
      qWarning() << this << "Cannot parse backend setting for source type" <<
                    sourceType << "reverting to" << metaEnum.valueToKey(config.backend);
  }

  readSourcePipelineConfiguration(sourceType, &config);
  readInputSourceConfiguration(sourceType, name, &config, resolution);
  readKeystoneCorrectionConfiguration(sourceType, name, &config, resolution);
  readIlluminationCorrectionConfiguration(sourceType, name, &config, resolution);
  readSharpenConfiguration(sourceType, name, &config);
  readFrameGrabberConfiguration(name, &config);
  readAutoWhiteBalanceConfiguration(name, &config);
  readColorCorrectionConfiguration(sourceType, name, &config, resolution);
  readMirrorConfiguration(sourceType, name, &config);
  readStillCaptureConfiguration(sourceType, name, &config); 

  return addSource(name, config);
}

/***********************************************************************************/

void VideoPipelinePrivate::removeSource(const QString& name) {
  verifyState(VideoPipeline::VideoPipelineState::Stopped, "removeSource");
  auto sourceIt = std::find_if(
      std::begin(m_sources), std::end(m_sources),
      [name](const QSharedPointer<SourcePipeline>& source) { return name == source->name(); });

  if (sourceIt == std::end(m_sources)) {
    auto message = QString(tr("Source with name '%1' is not included in the pipeline")).arg(name);
    throw InvalidOperationException(message);
  }

  for (auto connection : m_sourceConnectionMap[name]) {
    disconnect(connection);
  }

  m_sourceConnectionMap.remove(name);

  m_sources.removeAt(std::distance(std::begin(m_sources), sourceIt));

  if (m_sources.count() == 0) {
    setState(VideoPipeline::VideoPipelineState::Unintialized);
  }

  Q_Q(VideoPipeline);

  emit q->sourcesChanged(sources());
}

/***********************************************************************************/

void VideoPipelinePrivate::verifyState(const VideoPipeline::VideoPipelineState& expectedState,
                                       const QString& operation) {
  if (m_state != expectedState) {
    throw VideoPipelineStateMismatchException(m_state, expectedState, operation);
  }
}

/***********************************************************************************/

VideoPipeline::VideoPipelineState VideoPipelinePrivate::state() { return m_state; }

/***********************************************************************************/

void VideoPipelinePrivate::tryPerformRedraw(QSharedPointer<SourcePipeline> source) {
  const auto viewport = source->viewport();
  const auto destinationRectangle = source->destinationRectangle();
  const auto configuration = source->configuration();

  qInfo() << this << "Setting pipeline" << source->name() << "viewport to" << viewport
          << "and destination rectangle to" << destinationRectangle;

  if (m_compositorGpu) {
    const auto pinIndex = m_sourceToCompositorPinMapping[source->name()];

    // Calculate pixel coordinates
    const auto left =
        destinationRectangle.left() * static_cast<qreal>(m_configuration.size.width());
    const auto top = destinationRectangle.top() * static_cast<qreal>(m_configuration.size.height());

    // Calculate scale coefficients
    const auto width =
        destinationRectangle.width() * static_cast<qreal>(m_configuration.size.width());
    const auto height =
        destinationRectangle.height() * static_cast<qreal>(m_configuration.size.height());

    const auto scaleX =
        source->enabled() ? (width / static_cast<qreal>(source->size().width())) : 0;
    const auto scaleY =
        source->enabled() ? (height / static_cast<qreal>(source->size().height())) : 0;

    qInfo() << this << "Transformed destination rectangle is" << left << ";" << top << "(" << scaleX
            << "," << scaleY << ")";

    m_compositorGpu->setLocationScale(pinIndex, static_cast<float>(left), static_cast<float>(top),
                                      static_cast<float>(scaleX), static_cast<float>(scaleY));

    m_compositorGpu->setImageEdges(
        pinIndex, static_cast<float>(viewport.left()), static_cast<float>(viewport.right()),
        static_cast<float>(viewport.top()), static_cast<float>(viewport.bottom()));

    // Don't trigger redraw too often in order not to kill image rendering performance

    if (m_configuration.viewportRedrawDelay > 0) {
      const auto delay = std::chrono::milliseconds(m_configuration.viewportRedrawDelay);

      if (std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now() -
                                                                m_lastZoomPanRedraw)
              .count() > std::chrono::duration_cast<std::chrono::milliseconds>(delay).count()) {
        m_compositorGpu->triggerRedraw();
        m_lastZoomPanRedraw = std::chrono::system_clock::now();
      }
    }
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readSourcePipelineConfiguration(
    const SourcePipeline::SourcePipelineType& pipeline,
    SourcePipelineConfig* config) {
  int pipelineId = static_cast<int>(pipeline);
  int desktopPipelines = static_cast<int>(SourcePipelineConfig::Desktop);

  if ((pipelineId & desktopPipelines) == desktopPipelines) {
    config->sourceType = SourcePipelineConfig::Desktop;
  } else if(pipeline == SourcePipeline::SourcePipelineType::OrbbecRGB) {
    config->sourceType = SourcePipelineConfig::OpenNI;
  } else {
      config->sourceType = SourcePipelineConfig::DirectShow;
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readInputSourceConfiguration(
    SourcePipeline::SourcePipelineType sourceType, const QString& pipelineName,
    SourcePipelineConfig* config, QSize resolution) {
  auto inputSourceSectionName =
      QString("%1%2").arg(SettingsNames::SourceSectionPrefix).arg(pipelineName);
  auto inputSourceSection = settings(inputSourceSectionName);
  auto& inputVideoSource = config->inputVideoSource;
  auto& desktopCaptureSource = config->desktopCaptureSource;

  // Fill out defaults
  switch (sourceType) {
    case SourcePipeline::DownwardFacingCamera:
      inputVideoSource.name = "^USB Camera-OV580$";
      inputVideoSource.frameRate = 7;
      inputVideoSource.size = resolution;

      if (resolution == QSize(4416, 3312)) {
        inputVideoSource.frameRate = 7;
      } else if (resolution == QSize(2208, 1656)) {
        inputVideoSource.frameRate = 25;
      }

      // We need to calculate this based on the calibration data
      config->deviceDimensions = QSizeF(-1, -1);

      break;
    case SourcePipeline::SproutCamera:
      inputVideoSource.name = "^HP 14MP Camera$";
      inputVideoSource.frameRate = 6;
      inputVideoSource.size = resolution;

      break;
    case SourcePipeline::ForwardFacingCamera:
      inputVideoSource.name = "^(HP 2.0MP High Definition Webcam)$";
      inputVideoSource.frameRate = 30;
      inputVideoSource.size = resolution;

      break;
    case SourcePipeline::OrbbecRGB:
      break;
    case SourcePipeline::PrimaryDesktop:
    case SourcePipeline::MatDesktop:
    case SourcePipeline::SecondaryDesktop:
      desktopCaptureSource.screen =
          static_cast<int>(sourceType) & 0xF;  // Mask out lowest bits to match screen number
      break;
  }

  switch (config->sourceType) {
    case SourcePipelineConfig::Desktop: {
      desktopCaptureSource.screen =
          inputSourceSection->value(SettingsNames::Common::Screen, desktopCaptureSource.screen)
              .toInt();
      QVector<QRect> screenGeometries;

#ifdef Q_OS_WIN
      EnumDisplayMonitors(NULL, NULL, EnumDisplayMonitorsCallback,
                          reinterpret_cast<LPARAM>(&screenGeometries));
#endif

      if (desktopCaptureSource.screen < screenGeometries.count()) {
        auto geometry = screenGeometries[desktopCaptureSource.screen];

        qInfo() << this << "Screen" << desktopCaptureSource.screen << "geometry is" << geometry;

        config->desktopCaptureSource.captureArea =
            QRect(geometry.x(), geometry.y(), geometry.width(), geometry.height());

        // ToDo: Read out real DPI, for now we assume 96 DPI and convert to meters
        config->deviceDimensions = QSizeF(static_cast<qreal>(geometry.width()) / 96.0 * 0.0254,
                                          static_cast<qreal>(geometry.height()) / 96.0 * 0.0254);

      } else {
        auto message = QString("Provided screen index %1 is out of range (%2 screens available)")
                           .arg(desktopCaptureSource.screen)
                           .arg(screenGeometries.count());
        throw InvalidConfigurationException(message);
      }

      break;
    }

    case SourcePipelineConfig::DirectShow: {
      inputVideoSource.name =
          inputSourceSection->value(SettingsNames::Common::Name, inputVideoSource.name).toString();
      inputVideoSource.frameRate =
          inputSourceSection->value(SettingsNames::Common::FrameRate, inputVideoSource.frameRate)
              .toUInt();
      inputVideoSource.size =
          inputSourceSection->value(SettingsNames::Common::Size, inputVideoSource.size).toSize();      
      break;
    }
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readKeystoneCorrectionConfiguration(
    SourcePipeline::SourcePipelineType sourceType, const QString& pipelineName,
    SourcePipelineConfig* config, QSize resolution) {
  auto keystoneCorrectionFilterSectionName =
      QString("%1%2").arg(SettingsNames::KeystoneCorrectionFilterSectionPrefix).arg(pipelineName);
  auto keystoneCorrectionFilterSection = settings(keystoneCorrectionFilterSectionName);
  auto& keystoneCorrection = config->keystoneCorrection;
  auto qualityMetaEnum = QMetaEnum::fromType<KeystoneCorrectionFilterConfig::Quality>();

  // Fill out defaults
  if (sourceType == SourcePipeline::DownwardFacingCamera) {
    keystoneCorrection.included = true;

    if (resolution == QSize(4416, 3312)) {
      keystoneCorrection.homographyMatrixName = "cameraFullResToHighResMat";
    } else if (resolution == QSize(2208, 1656)) {
      keystoneCorrection.homographyMatrixName = "cameraQtrResToHDVideoResMat";
    }
  }

  keystoneCorrection.included =
      keystoneCorrectionFilterSection
          ->value(SettingsNames::Common::IsIncluded, keystoneCorrection.included)
          .toBool();  

  if (keystoneCorrection.included) {
      keystoneCorrection.homographyMatrixName =
          keystoneCorrectionFilterSection
              ->value(SettingsNames::KeystoneCorrectionFilter::HomographyMatrixName, keystoneCorrection.homographyMatrixName)
              .toString();

    bool ok = true;

    QString qualityString(qualityMetaEnum.valueToKey(keystoneCorrection.quality));
    auto qualityName = keystoneCorrectionFilterSection
                           ->value(SettingsNames::KeystoneCorrectionFilter::Quality, qualityString)
                           .toString();
    auto metaEnum = QMetaEnum::fromType<KeystoneCorrectionFilterConfig::Quality>();

    int quality = metaEnum.keyToValue(qualityName.toStdString().c_str(), &ok);

    if (ok) {
      config->keystoneCorrection.quality =
          static_cast<KeystoneCorrectionFilterConfig::Quality>(quality);
    } else {
      qWarning() << this << "Cannot parse keystone correction quality setting" << qualityName
                 << "reverting to" << qualityString;
    }    
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readIlluminationCorrectionConfiguration(
    SourcePipeline::SourcePipelineType sourceType, const QString& pipelineName,
    SourcePipelineConfig* config, QSize resolution) {
  Q_UNUSED(resolution)
  auto illuminationCorrectionFilterSectionName =
      QString("%1%2")
          .arg(SettingsNames::IlluminationCorrectionFilterSectionPrefix)
          .arg(pipelineName);
  auto illuminationCorrectionFilterSection = settings(illuminationCorrectionFilterSectionName);
  auto& illuminationCorrection = config->illuminationCorrection;

  // Fill out defaults

  if (sourceType == SourcePipeline::DownwardFacingCamera) {
    illuminationCorrection.included = true;
    illuminationCorrection.isAutoWhiteBalanceEnabled = false;
  }

  illuminationCorrection.included =
      illuminationCorrectionFilterSection
          ->value(SettingsNames::Common::IsIncluded, illuminationCorrection.included)
          .toBool();  

  if (illuminationCorrection.included) {
      illuminationCorrection.isAutoWhiteBalanceEnabled =
          illuminationCorrectionFilterSection
              ->value(SettingsNames::IlluminationCorrectionFilter::IsAutoWhiteBalanceEnabled,
                      illuminationCorrection.isAutoWhiteBalanceEnabled)
              .toBool();
      illuminationCorrection.calibrationDatasetName =
          illuminationCorrectionFilterSection
              ->value(SettingsNames::IlluminationCorrectionFilter::DatasetName,
                      illuminationCorrection.calibrationDatasetName)
              .toString();
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readSharpenConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                                    const QString& pipelineName,
                                                    SourcePipelineConfig* config) {
  auto sharpenFilterSectionName =
      QString("%1%2").arg(SettingsNames::SharpenFilterSectionPrefix).arg(pipelineName);
  auto sharpenFilterSection = settings(sharpenFilterSectionName);

  // Fill out defaults
  config->sharpen.included =
      sourceType == SourcePipeline::SourcePipelineType::DownwardFacingCamera;

  config->sharpen.included =
      sharpenFilterSection->value(SettingsNames::Common::IsIncluded, config->sharpen.included)
          .toBool();
}

/***********************************************************************************/

void VideoPipelinePrivate::readFrameGrabberConfiguration(const QString& pipelineName,
                                                         SourcePipelineConfig* config) {
  auto frameGrabberFilterSectionName =
      QString("%1%2").arg(SettingsNames::FramegrabberFilterSectionPrefix).arg(pipelineName);
  auto frameGrabberFilterSection = settings(frameGrabberFilterSectionName);

  // Fill out defaults
  config->frameGrabber.included =
      frameGrabberFilterSection
          ->value(SettingsNames::Common::IsIncluded, config->frameGrabber.included)
          .toBool();

  bool ok = true;

  auto formatMetaEnum = QMetaEnum::fromType<FinalFrameGrabberConfig::Format>();

  QString formatString(formatMetaEnum.valueToKey(config->frameGrabber.format));
  auto formatName =
      frameGrabberFilterSection->value(SettingsNames::FrameGrabberFilter::Format, formatString)
          .toString();

  int format = formatMetaEnum.keyToValue(formatName.toStdString().c_str(), &ok);

  if (ok) {
    config->frameGrabber.format = static_cast<FinalFrameGrabberConfig::Format>(format);
  } else {
    qWarning() << this << "Cannot parse frame grabber format setting" << formatName
               << "reverting to" << formatString;
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readAutoWhiteBalanceConfiguration(const QString& pipelineName,
                                                             SourcePipelineConfig* config) {
  auto autoWhiteBalanceFilterSectionName =
      QString("%1%2").arg(SettingsNames::AutoWhiteBalanceFilterSectionPrefix).arg(pipelineName);
  auto autoWhiteBalanceFilterSection = settings(autoWhiteBalanceFilterSectionName);

  config->autoWhiteBalance.included =
      autoWhiteBalanceFilterSection
          ->value(SettingsNames::Common::IsIncluded, config->autoWhiteBalance.included)
          .toBool();
}

/***********************************************************************************/

void VideoPipelinePrivate::readMirrorConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                                   const QString& pipelineName,
                                                   SourcePipelineConfig* config) {
  auto mirrorFilterSectionName =
      QString("%1%2").arg(SettingsNames::MirrorFilterSectionPrefix).arg(pipelineName);
  auto mirrorFilterSection = settings(mirrorFilterSectionName);

  if (sourceType == SourcePipeline::ForwardFacingCamera) {
    config->mirror.included = true;
    config->mirror.type = MirrorFilterConfig::Vertical;
  }

  if (sourceType == SourcePipeline::OrbbecRGB) {
    config->mirror.included = true;
    config->mirror.type = MirrorFilterConfig::Vertical;
  }

  config->mirror.included =
      mirrorFilterSection->value(SettingsNames::Common::IsIncluded, config->mirror.included)
          .toBool();

  bool ok = true;
  auto typeMetaEnum = QMetaEnum::fromType<MirrorFilterConfig::MirrorType>();

  QString typeString(typeMetaEnum.valueToKey(config->mirror.type));
  auto typeName =
      mirrorFilterSection->value(SettingsNames::MirrorFilter::Type, typeString).toString();

  int type = typeMetaEnum.keyToValue(typeName.toStdString().c_str(), &ok);

  if (ok) {
    config->mirror.type = static_cast<MirrorFilterConfig::MirrorType>(type);
  } else {
    qWarning() << this << "Cannot parse mirror type setting" << typeName << "reverting to"
               << typeString;
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readColorCorrectionConfiguration(
    SourcePipeline::SourcePipelineType sourceType, const QString& pipelineName,
    SourcePipelineConfig* config, QSize resolution) {
  auto colorCorrectionFilterSectionName =
      QString("%1%2").arg(SettingsNames::ColorCorrectionFilterSectionPrefix).arg(pipelineName);
  auto colorCorrectionFilterSection = settings(colorCorrectionFilterSectionName);
  auto& colorCorrection = config->colorCorrection;

  if (sourceType == SourcePipeline::DownwardFacingCamera) {
    colorCorrection.included = true;

    if (resolution == QSize(4416, 3312)) {
        colorCorrection.lampOnCalibrationDatasetName = "colorCorrectionLampOn";
        colorCorrection.lampOffCalibrationDatasetName = "colorCorrectionLampOff";
    } else if (resolution == QSize(2208, 1656)) {
        colorCorrection.lampOnCalibrationDatasetName = "colorCorrectionLampOn2K";
        colorCorrection.lampOffCalibrationDatasetName = "colorCorrectionLampOff2K";
    }
  }

  colorCorrection.included =
      colorCorrectionFilterSection
          ->value(SettingsNames::Common::IsIncluded, config->colorCorrection.included)
          .toBool();

  if (colorCorrection.included) {
      colorCorrection.lampOffCalibrationDatasetName =
          colorCorrectionFilterSection
              ->value(SettingsNames::ColorCorrectionFilter::LampOffDatasetName, config->colorCorrection.lampOffCalibrationDatasetName)
              .toString();

      colorCorrection.lampOnCalibrationDatasetName =
          colorCorrectionFilterSection
              ->value(SettingsNames::ColorCorrectionFilter::LampOnDatasetName, config->colorCorrection.lampOnCalibrationDatasetName)
              .toString();
  }
}

/***********************************************************************************/

void VideoPipelinePrivate::readStillCaptureConfiguration(SourcePipeline::SourcePipelineType sourceType,
                                   const QString& pipelineName, SourcePipelineConfig* config) {
    auto stillCaptureSectionName =
        QString("%1%2").arg(SettingsNames::StillCaptureSectionPrefix).arg(pipelineName);
    auto stillCaptureSection = settings(stillCaptureSectionName);


    // Fill out defaults
    if (sourceType == SourcePipeline::SproutCamera) {
      config->stillCapture.included = true;
    }

    config->stillCapture.included =
        stillCaptureSection->value(SettingsNames::Common::IsIncluded, config->stillCapture.included)
            .toBool();

    bool ok = true;

    auto formatMetaEnum = QMetaEnum::fromType<FinalFrameGrabberConfig::Format>();

    QString formatString(formatMetaEnum.valueToKey(config->stillCapture.format));
    auto formatName =
        stillCaptureSection->value(SettingsNames::FrameGrabberFilter::Format, formatString)
            .toString();

    int format = formatMetaEnum.keyToValue(formatName.toStdString().c_str(), &ok);

    if (ok) {
      config->stillCapture.format = static_cast<FinalFrameGrabberConfig::Format>(format);
    } else {
      qWarning() << this << "Cannot parse frame grabber format setting" << formatName
                 << "reverting to" << formatString;
    }

}

/***********************************************************************************/

/*!
 * \brief Returns the path to the log files.
 */
QString VideoPipelinePrivate::logPath() { return m_logPath; }

/***********************************************************************************/

/*!
 * \brief Sets new path to the log files.
 * \param logPath Path to the log files.
 */
void VideoPipelinePrivate::setLogPath(const QString& logPath) {
  verifyState(VideoPipeline::VideoPipelineState::Unintialized, "setLogPath");

  m_logPath = logPath;
}

/***********************************************************************************/

QVector<QSize> VideoPipelinePrivate::knownResolutions(SourcePipeline::SourcePipelineType sourceType) {
    QVector<QSize> result;

    switch(sourceType) {
    case SourcePipeline::SourcePipelineType::DownwardFacingCamera:
        result << QSize(4416, 3312);
        result << QSize(2208, 1656);
        break;
    case SourcePipeline::SourcePipelineType::ForwardFacingCamera:
        result << QSize(1920, 1080);
        break;
    case SourcePipeline::SourcePipelineType::SproutCamera:
        result << QSize(4352, 3264);
        break;
    }

    return result;
}

}  // namespace source
}  // namespace video
