/*! \file autowhitebalancefilter_p.h
 *  \brief Contains implementation of auto white balance filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_AUTOWHITEBALANCEFILTER_P_H_
#define VIDEO_SOURCE_PRIVATE_AUTOWHITEBALANCEFILTER_P_H_

#include <memory>

#include "video_source/autowhitebalancefilter.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The AutoWhiteBalanceFilter class uses auto white balance algoritm to enhance the image
 * passing through Nizza pipeline.
 */
class AutoWhiteBalanceFilterPrivate : public QObject, public OptionalImageFilterNizzaTask {
  Q_OBJECT
  Q_DECLARE_PUBLIC(AutoWhiteBalanceFilter)

  AutoWhiteBalanceFilter* const q_ptr;

 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param index Video source index for naming purposes.
   * \param parent Pointer to facade object.
   */
  AutoWhiteBalanceFilterPrivate(ulong index,
                                std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                AutoWhiteBalanceFilter* parent);

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir* process(Mir* in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_AUTOWHITEBALANCEFILTER_P_H_
