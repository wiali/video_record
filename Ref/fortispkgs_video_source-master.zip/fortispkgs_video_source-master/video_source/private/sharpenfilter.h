/*! \file sharpenfilter.h
 *  \brief Contains implementation of sharpen filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_SHARPENFILTER_H_
#define VIDEO_SOURCE_PRIVATE_SHARPENFILTER_H_

#include <memory>

#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The SharpenFilter class uses sharpening algoritm to enhance the image passing through
 * Nizza pipeline.
 */
class SharpenFilter : public OptionalImageFilterNizzaTask {
 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param index Video source index for naming purposes.
   */
  SharpenFilter(ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter);

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir* process(Mir* in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_SHARPENFILTER_H_
