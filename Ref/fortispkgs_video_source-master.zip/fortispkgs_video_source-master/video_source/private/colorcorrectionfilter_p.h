/*! \file colorcorrectionfilter_p.h
 *  \brief Contains implementation of auto white balance filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_COLORCORRECTIONFILTER_P_H_
#define VIDEO_SOURCE_PRIVATE_COLORCORRECTIONFILTER_P_H_

#include <memory>

#include "video_source/colorcorrectionfilter.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The ColorCorrectionFilter class uses auto white balance algoritm to enhance the image
 * passing through Nizza pipeline.
 */
class ColorCorrectionFilterPrivate : public QObject, public OptionalImageFilterNizzaTask {
  Q_OBJECT
  Q_DECLARE_PUBLIC(ColorCorrectionFilter)

  ColorCorrectionFilter *const q_ptr;

 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param index Video source index for naming purposes.
   * \param configuration Configuration of this filter.
   * \param parent Pointer to facade object.
   */
  ColorCorrectionFilterPrivate(ulong index, std::shared_ptr<image_filters::ImageFilter> imageFilter,
                               ColorCorrectionFilter *parent);

  /*!
   * \brief Returns color correction mode.
   */
  ColorCorrectionFilter::Mode mode() const;

  /*!
   * \brief Sets new color correction mode.
   * \param mode New mode value.
   */
  void setMode(ColorCorrectionFilter::Mode mode);

  /*!
   * \brief Returns Lamp On coefficients;
   * \return Matrix with current Lamp On coefficients.
   */
  QGenericMatrix<3, 8, float> lampOnCoefficients() const;

  /*!
   * \brief Returns Lamp Off coefficients;
   * \return Matrix with current Lamp Off coefficients.
   */
  QGenericMatrix<3, 8, float> lampOffCoefficients() const;

  /*! \brief Sets new Lamp On coefficients.
   *  \param coefficients New Lamp On coefficients.
   */
  void setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

  /*! \brief Sets new Lamp Off coefficients.
   *  \param coefficients New Lamp Off coefficients.
   */
  void setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir *process(Mir *in);

  /*!
   * \brief Current color correction mode.
   */
  ColorCorrectionFilter::Mode m_mode;

  /*!
   * \brief Lamp on coefficients.
   */
  QGenericMatrix<3, 8, float> m_lampOnCoefficients;

  /*!
   * \brief Lamp off coefficients.
   */
  QGenericMatrix<3, 8, float> m_lampOffCoefficients;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_COLORCORRECTIONFILTER_P_H_
