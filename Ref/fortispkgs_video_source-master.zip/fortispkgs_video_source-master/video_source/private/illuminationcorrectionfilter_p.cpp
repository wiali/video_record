/*! \file illuminationcorrectionfilter_p.cpp
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QGenericMatrix>

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include "video_source/private/illuminationcorrectionfilter_p.h"

namespace video {
namespace source {

/*!
 * \brief The IlluminationCorrectionFilter::State struct contains internal illumination correction
 * filter data.
 */
struct IlluminationCorrectionFilterPrivate::State {
 public:
  /*!
   * \brief Size of the image.
   * \details Image size is determined based on the first frame and should not change while pipeline
   * is running.
   */
  QSize imageSize;

  /*!
   * \brief illuminationCorrectionData Illumination correction image filter data.
   * \details Illumination correction data are determined based on the first frame and should not
   * change while pipeline is running.
   */
  std::shared_ptr<image_filters::IlluminationCorrectionData> illuminationCorrectionData;

  /*!
   * \brief Illumination coefficients from configuration.
   */
  QGenericMatrix<1, 6, float> illuminationCoefficients;

  /*!
   * \brief Raw image processing mutex/
   * \details Prevents accessing state object from two threads at the same time.
   */
  Rock::Mutex mutex;
};

IlluminationCorrectionFilterPrivate::IlluminationCorrectionFilterPrivate(
    ulong index, bool autoWhiteBalance,
    QGenericMatrix<1, 6, float>& illuminationCoefficients,
    std::shared_ptr<image_filters::ImageFilter> imageFilter, IlluminationCorrectionFilter *parent)
    : OptionalImageFilterNizzaTask(
          QString(autoWhiteBalance ? "%1:Illumination & white-balance"
                                                          : "%1:Illumination")
              .arg(index)
              .toStdString(),
          imageFilter),
      q_ptr(parent),
      m_autoWhiteBalance(autoWhiteBalance) {
  m_state = std::make_unique<State>();

  m_state->illuminationCoefficients = illuminationCoefficients;
}

/***********************************************************************************/

bool IlluminationCorrectionFilterPrivate::autoWhiteBalance() const {
  return m_autoWhiteBalance;
}

/***********************************************************************************/

void IlluminationCorrectionFilterPrivate::setAutoWhiteBalance(
    bool autoWhiteBalance) {
  if (autoWhiteBalance != m_autoWhiteBalance) {
    Q_Q(IlluminationCorrectionFilter);
    m_autoWhiteBalance = autoWhiteBalance;

    emit q->autoWhiteBalanceChanged(m_autoWhiteBalance);
  }
}

/***********************************************************************************/

Mir *IlluminationCorrectionFilterPrivate::process(Mir *in) {
  MirFormat format = in->format;
  uint32 w = in->width, h = in->height;

  auto inputBuffer = in->getBuffer(Mir::imageBuffer);

  m_state->mutex.lock();
  auto imageSize = m_state->imageSize;
  auto illuminationCorrectionData = m_state->illuminationCorrectionData;
  m_state->mutex.unlock();

  if (imageSize.isEmpty()) {
    m_state->mutex.lock();
    imageSize = m_state->imageSize = QSize(static_cast<int>(w), static_cast<int>(h));
    m_state->mutex.unlock();
  }

  image_filters::SourceImage sourceImage{m_state->imageSize, QImage::Format_RGB888, inputBuffer};

  if (illuminationCorrectionData == nullptr) {
    m_state->mutex.lock();

    illuminationCorrectionData = m_state->illuminationCorrectionData =
        m_imageFilter->illuminationCorrectionInit(imageSize, m_state->illuminationCoefficients);

    m_state->mutex.unlock();
  }

  Mir *outputImage = new Mir(w, h, format);
  outputImage->timestamp = in->timestamp;

  auto outputBuf = outputImage->getBuffer(Mir::imageBuffer);

  m_imageFilter->illuminationCorrection(sourceImage, outputBuf, illuminationCorrectionData,
                                        m_autoWhiteBalance);

  return outputImage;  // continue
}

/***********************************************************************************/

void IlluminationCorrectionFilterPrivate::setEnabled(bool enabled) {
  if (enabled != this->enabled()) {
    Q_Q(IlluminationCorrectionFilter);
    OptionalImageFilterNizzaTask::setEnabled(enabled);

    emit q->enabledChanged(enabled);
  }
}

}  // namespace source
}  // namespace video
