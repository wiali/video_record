/*! \file illuminationcorrectionfilter_p.h
 *  \brief Contains implementation of illumination correction and optional auto white balance filter
 * as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_ILLUMINATIONCORRECTIONFILTER_P_H_
#define VIDEO_SOURCE_PRIVATE_ILLUMINATIONCORRECTIONFILTER_P_H_

#include <memory>

#include "video_source/illuminationcorrectionfilter.h"
#include "video_source/illuminationcorrectionfilterconfig.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The IlluminationCorrectionFilter class uses illumination correction algorithm to enhance
 * the image passing through Nizza pipeline.
 * \details Optionally, this filter can also perform auto white balance in one pass.
 */
class IlluminationCorrectionFilterPrivate : public QObject, public OptionalImageFilterNizzaTask {
  Q_OBJECT
  Q_DECLARE_PUBLIC(IlluminationCorrectionFilter)

  IlluminationCorrectionFilter* const q_ptr;

 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param configuration Reference to filter configuration.
   * \param index Video source index for naming purposes.
   * \param parent Pointer to facade object.
   */
  IlluminationCorrectionFilterPrivate(ulong index,
                                      bool autoWhiteBalance,
                                      QGenericMatrix<1, 6, float>& illuminationCoefficients,
                                      std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                      IlluminationCorrectionFilter* parent);

  /*!
   * \brief Returns if optional auto white balance algorithm is enabled.
   * \sa setIsAutoWhiteBalanceEnabled
   */
  bool autoWhiteBalance() const;

  /*!
   * \brief Sets if auto white balance algorithm should be used.
   * \param isAutoWhiteBalanceEnabled Indicates if auto white balance algorithm should be used.
   */
  void setAutoWhiteBalance(bool autoWhiteBalance);

  virtual void setEnabled(bool enabled);

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  /*! \brief Indicates if auto white balance is enabled.
   */
  std::atomic_bool m_autoWhiteBalance;

  virtual Mir* process(Mir* in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_ILLUMINATIONCORRECTIONFILTER_P_H_
