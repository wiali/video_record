#include "NizzaBeans.h"

#define WINVER	0x0501	// Target Windows XP and Windows .NET Server
#define _WIN32_WINNT 0x0501	// Target Windows XP and Windows .NET Server
#include <windows.h>
#include <WinUser.h>

#include "OpenNI.h"

#include "orbbeccapturetasksource.h"

OrbbecCaptureState::OrbbecCaptureState(OrbbecCapture *ownr, const std::string &name)
    : m_numToSend(0), m_numSent(0),
    owner(ownr), frameRate(0.0f), timerThread(0),
    timerStart("OrbbecCaptureState::timerStart" + name), timerMilliseconds(0), timerTimes()
    , m_initialized(false)
    , m_stream(0)
{
    // Request the most accurate timer/sleep resolution possible.
    timerResolution = Rock::setTimerResolution(1);
}

OrbbecCaptureState::~OrbbecCaptureState()
{
    stop();
    Rock::unsetTimerResolution(timerResolution);
}


void OrbbecCaptureState::timerThreadMain()
{
    while (true) {

        // Wait for the signal to count time.
        timerStart.wait();

        // If no time, it's a signal to exit.
        if (timerMilliseconds == 0)
            break;

        // Sleep for the specified amount of milliseconds.
        Rock::Thread::sleep(timerMilliseconds);

        // Tell Nizza that we can produce.
        owner->scheduleNextProduction();
    }
}

void OrbbecCaptureState::issueScheduleNextProduction()
{
    // If the rate changed, remove the production history.
    if (timerRate != frameRate) {
        timerRate = frameRate;
        timerTimes.clear();
    }

    // If frame rate is zero, run as fast as we can.
    if (timerRate == 0.0f) {
        owner->scheduleNextProduction();
        return;
    }
    else if (timerRate == -1.0f) {
        return;
    }

    int64 period = int64(1000000.0 / timerRate);

    // Record current time in history.
    int64 currProduction = Rock::StopWatch::getMicroSecs();
    timerTimes.push_back(currProduction);

    // Keep only the production times that are within 10 periods from now.
    while (!timerTimes.empty() && timerTimes.front() < currProduction - 10 * period)
        timerTimes.pop_front();

    // Calculate the necessary time to sleep in order to achieve specified frame rate.
    int64 earliestProduction = timerTimes.front();
    int64 num = timerTimes.size();
    int64 nextProduction = earliestProduction + num*period;
    int64 sleepDelay = nextProduction - currProduction;

    if (sleepDelay < 1000) {    // less than a millisecond, so schedule now
        owner->scheduleNextProduction();
    }
    else {                      // more than a ms, so use timer
        timerMilliseconds = uint32(sleepDelay / 1000);
        timerStart.post(1);
    }
}

void OrbbecCaptureState::start()
{
    initialize();
    m_stream = QSharedPointer<openni::VideoStream>::create();
    auto oniStatus = m_stream->create(m_device, openni::SENSOR_COLOR);

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Unable to create video stream: openni::SENSOR_COLOR");
    }

    oniStatus = m_stream->start();

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Failed to start stream: openni::SENSOR_COLOR");
    }

    auto videoMode = m_stream->getVideoMode();
    videoMode.setPixelFormat(openni::PIXEL_FORMAT_RGB888);
    videoMode.setResolution(640, 480);

    oniStatus = m_stream->setVideoMode(videoMode);

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Unable to set video mode for: openni::SENSOR_COLOR");
    }
}

void OrbbecCaptureState::stop()
{
    if (m_stream)
    {
        m_stream->stop();
        //delete m_stream;
    }
    shutdown();
}

Media_Image_Raw* OrbbecCaptureState::captureImage()
{
    uint32 dest_width = 640;
    uint32 dest_height = 480;

    openni::VideoFrameRef frame;
    int changedIndex = -1;

    auto streamPointer = m_stream.data();
    auto oniStatus = openni::OpenNI::waitForAnyStream(&streamPointer, 1, &changedIndex, 1000);

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Failed to get new frame from: openni::SENSOR_COLOR");
    }

    oniStatus = m_stream->readFrame(&frame);

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Unable to read frame from: openni::SENSOR_COLOR");
    }

    // Create the media
    // Allocate media before getting image for more accurate latency timings
    MirFormat format(mirRGB, mirUINT8, mirPixel, mirAlign4, mirProgressive);

    Media_Image_Raw* m = new Media_Image_Raw(dest_width, dest_height, format);

    if (!m)
        throw stringf("OrbbecCapture: Not enough memory for new media.");

    /*
    Assign values to the Media Object
    */
    // now get the actual data

    if (frame.getDataSize() == m->getBufferSize(Media_Image_Raw::imageBuffer)) {
        BYTE* pData = m->getBuffer(Media_Image_Raw::imageBuffer);

        memcpy(pData, frame.getData(), frame.getDataSize());
    }
    else {
        throw stringf("OrbbecCapture: Image size is different.");
    }


    return m;
}

void OrbbecCaptureState::initialize()
{
    if (!m_initialized)
    {
        try
        {
            initOpenNI();
            initDevice();

            m_initialized = true;
        }
        catch (...)
        {
            shutdown();
            throw;
        }
    }
}

void OrbbecCaptureState::shutdown()
{
    if (m_device.isValid())
    {
        m_device.close();
    }

    openni::OpenNI::shutdown();

    m_initialized = false;
}

void OrbbecCaptureState::initOpenNI()
{
    openni::Status oniStatus = openni::OpenNI::initialize();

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Unable to initialize OpenNI");
    }
}

void OrbbecCaptureState::initDevice()
{
    openni::Status oniStatus = m_device.open(openni::ANY_DEVICE);

    if (oniStatus != openni::STATUS_OK)
    {
        throw stringf("Unable to open OpenNI camera");
    }
}

//---------------

OrbbecCapture::OrbbecCapture(const std::string& name)
    : OrbbecCapture(name, new OrbbecCaptureState(this, name))
{}

OrbbecCapture::OrbbecCapture(const std::string& name, OrbbecCaptureState* st)
    : Nizza::TaskSource(name, "OrbbecCapture"), state(st)
{
    addOutputPin("out", "image", "Image_Raw");
}

OrbbecCapture::~OrbbecCapture()
{
    if (state)
        delete state;
}

void OrbbecCapture::setMaxCaptureRate(float rate) {
    if (rate < 0.0f && rate != -1.0f)
        throw stringf("OrbbecCapture::setMaxCaptureRate: Requested a frame rate of %f, but it must be positive, 0.0 or -1.0", rate);

    state->frameRate = rate;
}

void OrbbecCapture::produceFrame()
{
    scheduleNextProduction();
}

static void timerThreadFunc(void* arg)
{
    reinterpret_cast<OrbbecCaptureState*>(arg)->timerThreadMain();
}

/*
Initializes Nizza Beans Object
*/
void OrbbecCapture::commence()
{
    state->start();
    state->m_numSent = 0;

    // Set up the timer thread.
    state->timerRate = state->frameRate;
    state->timerTimes.clear();
    state->timerThread = new Rock::Thread(name + "_timerThread", timerThreadFunc, state);
    if (!state->timerThread)
        throw stringf("DesktopCapture::commence: Could not create internal thread.");
    state->timerThread->setPriority(Rock::Thread::critical);

    if (state->frameRate >= 0.0) {
        // Start producing as long as we are not in triggered mode
        scheduleNextProduction();
    }
}

void OrbbecCapture::conclude()
{
    // Kill the timer thread.
    if (state->timerThread) {
        state->stop();
        state->timerMilliseconds = 0;
        state->timerStart.post(1);
        state->timerThread->waitFinished();
        delete state->timerThread;
        state->timerThread = 0;
        while (state->timerStart.tryWait());  // remove any extraneous signals
    }
}

/*
Produces a Nizza Media Object and Pushes it Out
*/
bool OrbbecCapture::produce(Nizza::Output& output)
{
    // Create the new media object.
    Media_Image_Raw* mta = state->captureImage();

    if (mta) {
        mta->timestamp = Rock::StopWatch::getMicroSecs();

        // Send it downstream.
        output.push("out", "image", mta);
        Nizza::endMediaUsage(mta);

        state->m_numSent++;
    }

    bool doContinue = (state->m_numSent < state->m_numToSend) || (state->m_numToSend == 0);

    if (doContinue) {
        state->issueScheduleNextProduction();
    }

    return doContinue;
};

