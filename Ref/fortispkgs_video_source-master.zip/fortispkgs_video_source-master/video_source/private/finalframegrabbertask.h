/*! \file finalframegrabbertask.h
 *  \brief Contains implementation of frame grabber task as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_FINALFRAMEGRABBERTASK_H_
#define VIDEO_SOURCE_PRIVATE_FINALFRAMEGRABBERTASK_H_

#include <memory>

#include "video_source/finalframegrabberconfig.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*! The FrameGrabberTask sends signal frameReady whenever there is new frame available.
 */
class FinalFrameGrabberTask : public QObject, public OptionalImageFilterNizzaTask {
  Q_OBJECT

 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param configuration Configuration object.
   * \param parent Parent QObject.
   * \param index Video source index for naming purposes.
   * \param buffer Raw data buffer pointer.
   */
  explicit FinalFrameGrabberTask(ulong index, uchar *buffer,
                                 std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                 const FinalFrameGrabberConfig &configuration, QObject *parent = 0);

 signals:

  /*!
   * \brief Signal frameBufferReady is emitted when frame buffer is filled with new frame.
   * \param sourceIndex Source index.
   * \param size Size of the frame in pixels.
   * \param dataSize Size of the frame in bytes.
   */
  void frameBufferReady(int sourceIndex, const QSize size, int dataSize);

 private:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir *process(Mir *in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_FINALFRAMEGRABBERTASK_H_
