/*! \file keystonecorrectionfilter.h
 *  \brief Contains implementation of keystone correction filter as Nizza task.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_PRIVATE_KEYSTONECORRECTIONFILTER_H_
#define VIDEO_SOURCE_PRIVATE_KEYSTONECORRECTIONFILTER_H_

#include <memory>

#include "video_source/keystonecorrectionfilterconfig.h"
#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

/*!
 * \brief The KeystoneCorrectionFilter class uses keystone correction algorithm (perspective warp)
 * to enhance the image passing through Nizza pipeline.
 */
class KeystoneCorrectionFilter : public OptionalImageFilterNizzaTask {
 public:
  /*!
   * \brief Constructor.
   * \param imageFilter Instance of ImageFilter used to perform the operation.
   * \param configuration Reference to filter configuration.
   * \param index Video source index for naming purposes.
   */
  KeystoneCorrectionFilter(ulong index, const QTransform &homography, const QRect &outputRect, KeystoneCorrectionFilterConfig::Quality quality,
                           std::shared_ptr<image_filters::ImageFilter> imageFilter);

  QRect outputRect() const;

 protected:
  /*! \brief Forward declaration of filter's internal state structure.
   */
  struct State;

  /*! \brief Instance of internal state structure.
   */
  std::unique_ptr<State> m_state;

  virtual Mir *process(Mir *in);
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_PRIVATE_KEYSTONECORRECTIONFILTER_H_
