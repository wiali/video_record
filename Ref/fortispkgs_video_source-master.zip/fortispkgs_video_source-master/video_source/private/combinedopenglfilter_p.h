#ifndef GPUFILTERS_P_H
#define GPUFILTERS_P_H

#include <QMutex>
#include <QSize>
#include <QGenericMatrix>
#include <QColor>
#include <QWaitCondition>

#include <Nizza.h>

#include "video_source/combinedopenglfilter.h"

#include "keystonecorrectionfilterconfig.h"
#include "video_source/colorcorrectionfilter.h"
#include "video_source/mirrorfilterconfig.h"
#include "video_source/outputvideosinkconfig.h"
#include "video_source/private/optionalimagefilternizzatask.h"

struct GLFWwindow;

namespace video {
namespace source {

class CombinedOpenGLFilterPrivate : public QObject, public OptionalImageFilterNizzaTask {
    Q_OBJECT
    Q_DECLARE_PUBLIC(CombinedOpenGLFilter)

    CombinedOpenGLFilter* const q_ptr;

public:
    explicit CombinedOpenGLFilterPrivate(ulong index,
                                         const OutputVideoSinkConfig& outputConfig,
                                         std::shared_ptr<image_filters::ImageFilter> imageFilter,
                                         CombinedOpenGLFilter* parent);

    ~CombinedOpenGLFilterPrivate();

    bool convert(QOpenGLFramebufferObject* frameBuffer);

    /*! \brief Enable.disable logging into Nizza logfile
     */
    static void setVerbose(bool);

    bool illuminationCorrection() const;

    void setIlluminationCorrection(bool illuminationCorrection);

    bool colorCorrection() const;

    void setColorCorrection(bool colorCorrection);

    bool keystoneCorrection() const;

    void setKeystoneCorrection(bool keystoneCorrection);

    bool autoWhiteBalance() const;

    void setAutoWhiteBalance(bool autoWhiteBalance);

    void setupKeystoneCorrection(const QSize &keystoneCorrectedSize, QTransform homography, const KeystoneCorrectionFilterConfig::Quality &quality);

    void setupIlluminationCorrection(const QGenericMatrix<1, 6, float>  &illuminationCoefficients);

    QSize keystoneCorrectedSize() const;

    /*!
     * \brief Returns color correction mode.
     */
    ColorCorrectionFilter::Mode colorCorrectionMode() const;

    /*!
     * \brief Sets new color correction mode.
     * \param mode New mode value.
     */
    void setColorCorrectionMode(ColorCorrectionFilter::Mode mode);

    bool sharpen() const;

    void setSharpen(bool sharpen);

    void setMirror(MirrorFilterConfig::MirrorType mirrorType);

    /*!
     * \brief Returns Lamp On coefficients;
     * \return Matrix with current Lamp On coefficients.
     */
    QGenericMatrix<3, 8, float> lampOnCoefficients() const;

    /*!
     * \brief Returns Lamp Off coefficients;
     * \return Matrix with current Lamp Off coefficients.
     */
    QGenericMatrix<3, 8, float> lampOffCoefficients() const;

    /*! \brief Sets new Lamp On coefficients.
     *  \param coefficients New Lamp On coefficients.
     */
    void setLampOnCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

    /*! \brief Sets new Lamp Off coefficients.
     *  \param coefficients New Lamp Off coefficients.
     */
    void setLampOffCoefficients(const QGenericMatrix<3, 8, float>& coefficients);

private:
 virtual Mir* process(Mir* in);

 void conclude() override;

 uint runCorrectionFilters(const QSize &imageSize, const uint8 *inputBuffer);

 QColor autoWhiteBalanceScale(uint inputTexture);

 uint sharpen();

 /*! \brief Forward declaration of filter's internal state structure.
  */
 struct State;

 /*! \brief Instance of internal state structure.
  */
 std::unique_ptr<State> m_state;

 QSize m_inputSourceSize;

 bool m_illuminationCorrection;

 bool m_colorCorrection;

 bool m_sharpen;

 bool m_autoWhiteBalance;

 bool m_keystoneCorrection;

 OutputVideoSinkConfig m_outputConfig;

 /*!
  * \brief Current color correction mode.
  */
 ColorCorrectionFilter::Mode m_colorCorrectionMode;

 MirrorFilterConfig::MirrorType m_mirrorType;

 QWaitCondition m_offscreenImageEvent;

 QThread m_thread;

 private slots:

 void generateOffscreenImage();
};


}  // namespace source
}  // namespace video

#endif // GPUFILTERS_P_H
