/*! \file optionalimagefilternizzatask.cpp
 *  \brief Contains implementation of base class for image enhancement filter.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <NizzaBeans.h>
#include <NizzaMedia.h>

#include <image_filters/imagefilter.h>

#include "video_source/private/optionalimagefilternizzatask.h"

namespace video {
namespace source {

static bool gVerbose = false;

OptionalImageFilterNizzaTask::OptionalImageFilterNizzaTask(
    const std::string& name, std::shared_ptr<image_filters::ImageFilter> imageFilter)
    : Task(name, "ImageFilter"), m_imageFilter(imageFilter), m_enabled(true) {
  // Create input media pin
  addInputPin("in", "image", "Image_Raw");

  // Create output media pin
  addOutputPin("out", "image", "Image_Raw");
}

/***********************************************************************************/

void OptionalImageFilterNizzaTask::commence() {
  // do pre-streaming initialization
  if (gVerbose) {
    Rock::Thread::logf("%s::commence: Entered.\n", name.c_str());
  }
}

/***********************************************************************************/

void OptionalImageFilterNizzaTask::conclude() {
  // do post-streaming cleanup
  if (gVerbose) {
    Rock::Thread::logf("%s::conclude: Entered.\n", name.c_str());
  }
}

/***********************************************************************************/

void OptionalImageFilterNizzaTask::setVerbose(bool val) { gVerbose = val; }

/***********************************************************************************/

bool OptionalImageFilterNizzaTask::enabled() const { return m_enabled; }

/***********************************************************************************/

void OptionalImageFilterNizzaTask::setEnabled(bool enabled) { m_enabled = enabled; }

/***********************************************************************************/

bool OptionalImageFilterNizzaTask::process(const std::string& groupName,
                                           const std::vector<Nizza::Media*>& media,
                                           Nizza::Output& output) {
  if (gVerbose) {
    Rock::Thread::logf("%s::process: Entered.\n", name.c_str());
  }

  if (groupName != "in") {
    throw stringf("%s::process: unknown group [%s]", name.c_str(), groupName.c_str());
  }

  if (media.size() != 1) {
    throw stringf(
        "%s::process: error num"
        "ber of media size [%lu], expected 1.",
        name.c_str(), media.size());
  }

  // Check media type before casting.
  if (!media[0] || strcmp(media[0]->getType(), "Image_Raw")) {
    throw stringf("%s::process: Null media input or type was not Media_Image_Raw.", name.c_str());
  }

  Mir *in = reinterpret_cast<Mir*>(media[0]), *out = nullptr;
  bool res = true;

  if (m_enabled) {
    out = process(in);

    output.push("out", "image", out);

    if (in != out) {
      Nizza::endMediaUsage(out);
    }
  } else {
    output.push("out", "image", in);
  }

  Nizza::endMediaUsage(in);

  if (gVerbose) {
    Rock::Thread::logf("%s::process: Finished.\n", name.c_str());
  }

  return res;  // continue
}

}  // namespace source
}  // namespace video
