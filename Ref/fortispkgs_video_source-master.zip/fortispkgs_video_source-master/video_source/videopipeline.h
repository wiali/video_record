/*! \file videopipeline.h
 *  \brief Contains the definition of the video source class plug-in package.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_VIDEOPIPELINE_H_
#define VIDEO_SOURCE_VIDEOPIPELINE_H_

#include <QObject>
#include <QScopedPointer>

#include <sensor_data.h>

#include "video_source/sourcepipeline.h"
#include "video_source/videopipeline_api.h"

namespace image_filters {
class ImageFilter;
}

namespace video {
namespace source {

/*! \brief Forward declartion of private implementation. */
class VideoPipelinePrivate;

/*! \brief The VideoPipeline class wraps a single Nizza video pipeline and manages its lifetime.
 */
class VIDEO_PIPELINE_API VideoPipeline
    : public QObject
{
  Q_OBJECT

  /*! \brief Current state of the video pipeline.
   */
  Q_PROPERTY(video::source::VideoPipeline::VideoPipelineState state READ state NOTIFY stateChanged)

  /*! \brief Get/Set property for the log file path.
   */
  Q_PROPERTY(QString logPath READ logPath WRITE setLogPath)

public:

  /*! \brief Possible graph states
   */
  enum class VideoPipelineState
  {
    Unintialized, /*!< Default state after video pipeline is constructed. */
    Stopped,      /*!< Pipeline was initialized succesfully and it is currently not running. */
    Starting,     /*!< Pipeline is starting. */
    Running,      /*!< Pipeline started succesfully and it is running. */
    Stopping      /*!< Pipeline is stopping. */
  };
  Q_ENUM(VideoPipelineState)

  /*! \brief Creates a new instance of VideoSource.
   *  \remarks There can be only a single instance per process running at the time.
   *  \param parent Optional parent of this QObject.
   */
  explicit VideoPipeline(QObject* parent = nullptr);

  /*! \brief Destroys this instance of VideoSource.
   *  \details Stops the pipeline if running.
   */
  virtual ~VideoPipeline();

  /*! \brief Sets new output sink configuration.
   *  \details This method must be called before the video pipeline is started.
   *  \param configuration Video pipeline configuration object.
   *  \exception InvalidOperationException Thrown when output sink parameters are out of allowed range.
   *  \exception VideoPipelineStateMismatchException Thrown when video pipeline was already started.
   */
  Q_INVOKABLE void setOutputSinkConfiguration(const OutputVideoSinkConfig& configuration);

  /*! \brief Starts the video pipeline.
   *  \details Starts an existing video pipeline. The pipeline must be in the "stopped" state. This is a blocking function.
   *  \exception VideoPipelineStateMismatchException Thrown when video pipeline was already started.
   */
  Q_INVOKABLE void start();

  /*! \brief Stops the video pipeline.
   */
  Q_INVOKABLE void stop();

  /*! \brief Get current output sync configuration of video pipeline.
   */
  Q_INVOKABLE OutputVideoSinkConfig outputSinkConfiguration();

  /*! \brief Get current state of video pipeline.
   */
  Q_INVOKABLE VideoPipelineState state();

  /*! \brief Captures a frame from video pipeline with all the sensor data.
   *  \param stillFrameSources Indicates which sources should use still frame capture method
   *         (SourcePipeline::captureStillFrame). Remaining sources will use the video frame capture method
   *         (SourcePipeline::captureVideoFrame).
   *  \details Gets a frame from each input source in the pipeline.
   *  \return List of sensor datas with captured images.
   *  \exception InvalidOperationException Thrown when calibration data is missing.
   *  \exception InvalidOperationException Thrown when none of the input sources is enabled.
   *  \exception VideoPipelineStateMismatchException Thrown when video pipeline is not running.
   */
  Q_INVOKABLE QVector<sensordata::SensorData> capture(QStringList stillFrameSources = QStringList());

  /*! \brief Returns list of configured input sources.
   */
  Q_INVOKABLE QVector<QSharedPointer<SourcePipeline>> sources();

  /*!
   * \brief Adds new input source with known configuration into video pipeline.
   * \details Supported resolutions can be obtained by calling knownResolutions method.
   * \param sourceType Known type of the input source.
   * \param resolution Known resolution of the input source. This parameter is optional and if
   * isn't provided default value will be used.
   * \exception VideoPipelineStateMismatchException Thrown when video pipeline is running.
   * \exception InvalidOperationException Thrown when this source type is already in the video
   * pipeline.
   * \exception InvalidConfigurationException Thrown when given resolution is not supported.
   */
  Q_INVOKABLE QSharedPointer<video::source::SourcePipeline> addKnownSource(
      SourcePipeline::SourcePipelineType sourceType, QSize resolution = QSize());

  /*! \brief Adds new input source with configuration into video pipeline.
   *  \param name Name of the new input source.
   *  \param config Configuration of new input source.
   *  \exception VideoPipelineStateMismatchException Thrown when the video pipeline is already running.
   *  \exception InvalidOperationException Thrown when the source with this name is already in the video pipeline.
   */
  Q_INVOKABLE QSharedPointer<SourcePipeline> addSource(const QString& name, SourcePipelineConfig config);

  /*! \brief Removes input source from video pipeline.
   *  \param name Name of the input source to remove.
   *  \exception VideoPipelineStateMismatchException Thrown when the video pipeline is already running.
   *  \exception InvalidOperationException Thrown when the source with this name is not in the video pipeline.
   */
  Q_INVOKABLE void removeSource(const QString& name);

  /*! \brief Returns the path to the log files.
   */
  QString logPath();

  /*! \brief Sets new path to the log files.
   *  \details This method must be called before the first source is added to the pipeline.
   *  \exception VideoPipelineStateMismatchException Thrown when the video pipeline is already running.
   *  \param logPath Path to the log files.
   */
  void setLogPath(const QString& logPath);

  /*!
   * \brief Returns known resolutions for given source type.
   * \details This method is particulary useful for camera devices that need to do post-processing
   * operations that are tied to resolution (e.g. keystone correction). For Desktop source types
   * this method doesn't return any results.
   * \param sourceType Known type of the input source.
   */
  QVector<QSize> knownResolutions(SourcePipeline::SourcePipelineType sourceType);

 signals:
  /*! \brief Signal emitted when video pipeline state changes.
   *  \param state New video pipeline state.
   */
  void stateChanged(video::source::VideoPipeline::VideoPipelineState state);

  /*! \brief Signal emitted when the input source has been added or removed.
   *  \param sources New list of input sources.
   */
  void sourcesChanged(QVector<QSharedPointer<video::source::SourcePipeline>> sources);

  /*! \brief Signal emitted when the output sync configuration has changed.
   *  \param configuration New output sync configuration.
   */
  void outputSinkConfigurationChanged(video::source::OutputVideoSinkConfig configuration);

private:

  Q_DECLARE_PRIVATE(VideoPipeline)
  QScopedPointer<VideoPipelinePrivate> const d_ptr;
};

}  // namespace source
}  // namespace video

#endif  // VIDEO_SOURCE_VIDEOPIPELINE_H_
