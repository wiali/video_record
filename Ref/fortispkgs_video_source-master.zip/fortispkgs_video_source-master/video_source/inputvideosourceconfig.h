/*! \file inputvideosourceconfig.h
 *  \brief Contains the definition of the input video source parameters class.
 *  \date April, 2016
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef VIDEO_SOURCE_INPUTVIDEOSOURCECONFIG_H_
#define VIDEO_SOURCE_INPUTVIDEOSOURCECONFIG_H_

#include <QDebug>
#include <QObject>
#include <QSize>
#include <QString>

#include "video_source/videopipeline_api.h"

namespace video {
namespace source {

/*! \brief Used to specify the desired input params.
 *  \details Contains name of input video source (camera) and/or its parameters: resolution, frame rate.
 */
class VIDEO_PIPELINE_API InputVideoSourceConfig
{
  Q_GADGET
  Q_PROPERTY(QString name MEMBER name)
  Q_PROPERTY(QSize size MEMBER size)
  Q_PROPERTY(unsigned int frameRate MEMBER frameRate)  

public:

  /*! \brief Name of input video source (camera)
   */
  QString name;

  /*! \brief Image size.
   */
  QSize size;

  /*! \brief Frame rate
   */
  unsigned int frameRate;  
};

}  // namespace source
}  // namespace video

/*! \brief Equality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if InputVideoSourceConfig values are the same, otherwise false.
 */
inline bool operator == (const video::source::InputVideoSourceConfig& lhs,
                         const video::source::InputVideoSourceConfig& rhs)
{
  return (lhs.name == rhs.name && lhs.size == rhs.size && lhs.frameRate == rhs.frameRate);
}

/*! \brief Inequality operator.
 *  \param lhs Left hand side part of the expression.
 *  \param rhs Right hand side part of the expression.
 *  \return True if InputVideoSourceConfig values are not the same, otherwise false.
 */
inline bool operator != (const video::source::InputVideoSourceConfig& lhs,
                         const video::source::InputVideoSourceConfig& rhs)
{
  return !(lhs == rhs);
}

/*! \brief Support for QDebug stream operator (http://doc.qt.io/qt-5/debug.html).
 *  \details Used for debugging purposes only.
 *  \param debug Debug stream.
 *  \param obj Reference to object that should be streamed.
 *  \return Debug stream, same as debug parameter.
 */
inline QDebug operator << (QDebug debug, const video::source::InputVideoSourceConfig& obj)
{
  debug << obj.name << " [" << obj.size << " @ " << obj.frameRate << " fps]";
  return debug;
}

#endif  // VIDEO_SOURCE_INPUTVIDEOSOURCECONFIG_H_
