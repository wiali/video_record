#include <QSignalSpy> 

#include "video_source_tests.h"
#include "video_source.h"
#include "video_source_factory.h"

using namespace fortis::video::source::v0;
using namespace fortis::video::source::test;
using namespace fortis::error::v0;

static VideoSourceFactory *s_vsFact;
static VideoSource *s_vs;

// ~~~
#include <windows.h>
void VideoSourceTest::init()
{
    static int init = 1;
    if (init)
    {
        init = 0;
        //Sleep(20 * 1000);
    }
}

void VideoSourceTest::cleanup()
{
}

void VideoSourceTest::createFactory()
{
    s_vsFact = new VideoSourceFactory;
    bool bRet = (s_vsFact != nullptr);
    QCOMPARE(bRet,true);
}

void VideoSourceTest::destroyFactory()
{
    QVERIFY(s_vs == nullptr);
    QVERIFY(s_vsFact != nullptr);
    //s_vsFact->deleteLater();
    delete s_vsFact;
    s_vsFact = nullptr;
    bool bRet = (s_vsFact == nullptr);
    QCOMPARE(bRet,true);
}

void VideoSourceTest::createPipelineDefault()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs == nullptr);
    s_vs = s_vsFact->createDefault(true);
    bool bRet = (s_vs != nullptr);
    QCOMPARE(bRet,true);
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),1);
    QString id0 = *vec.begin();
    QString id1 = s_vs->getId();
    QCOMPARE(id0 == QString(),false);
    QCOMPARE(id0,id1);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
    VideoSourceConfig *config = s_vs->getConfig(0);
    QStringList namesOfInputDirectShowVirtualDevices = config->namesOfInputDirectShowVirtualDevices();
    QCOMPARE(namesOfInputDirectShowVirtualDevices.size(),1);
    QString el0 = config->namesOfInputDirectShowVirtualDevices()[0];
    QCOMPARE(el0,QString("USB Camera-OV580"));
    QCOMPARE(config->nameOfOutputDirectShowVirtualDevice(),QString("Fortis Video Source"));
    delete config;
    //config->deleteLater();
}

void VideoSourceTest::createPipeline2Fail()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs != nullptr);

    InputVideoSource ivs;
    ivs.m_name = "HP High Definition 1MP Webcam";
    ivs.m_height = 480;
    ivs.m_width = 640;
    ivs.m_frameRate = 30.0f;
    VideoSource *vs = s_vsFact->createSingle(ivs,true);
    bool rc = (vs == nullptr);
    QCOMPARE(rc,true);
    ErrorInfo errorInfo = s_vsFact->error();
    QCOMPARE(errorInfo.code,-1);
}

void VideoSourceTest::startPipelineDefault()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->start();
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Running"));
}


void VideoSourceTest::stopPipelineDefault()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->stop(-1);
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
}

void VideoSourceTest::destroyPipelineDefault()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs != nullptr);

    //s_vs->deleteLater();
    delete s_vs;
    s_vs = nullptr;
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),0);
}

void VideoSourceTest::createPipelineSingle()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs == nullptr);

    InputVideoSource ivs;
    ivs.m_name = "USB Camera-OV580";
    ivs.m_width = 4416;
    ivs.m_height = 3312;
    ivs.m_frameRate = 7;
    s_vs = s_vsFact->createSingle(ivs,true);

    bool bRet = (s_vs != nullptr);
    QCOMPARE(bRet,true);
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),1);
    QString id0 = *vec.begin();
    QString id1 = s_vs->getId();
    QCOMPARE(id0 == QString(),false);
    QCOMPARE(id0,id1);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
    VideoSourceConfig *config = s_vs->getConfig(0);
    QStringList namesOfInputDirectShowVirtualDevices = config->namesOfInputDirectShowVirtualDevices();
    QCOMPARE(namesOfInputDirectShowVirtualDevices.size(),1);
    QString el0 = config->namesOfInputDirectShowVirtualDevices()[0];
    QCOMPARE(el0,QString("USB Camera-OV580"));
    QCOMPARE(config->nameOfOutputDirectShowVirtualDevice(),QString("Fortis Video Source"));
    //config->deleteLater();
    delete config;
}

void VideoSourceTest::startPipelineSingle()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->start();
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Running"));
}

void VideoSourceTest::stopPipelineSingle()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->stop(-1);
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
}

void VideoSourceTest::destroyPipelineSingle()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs != nullptr);

    //s_vs->deleteLater();
    delete s_vs;
    s_vs = nullptr;
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),0);
}

void VideoSourceTest::createPipelineMultiple()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs == nullptr);

    InputVideoSource ivs;
    ivs.m_name = "USB Camera-OV580";
    ivs.m_width = 4416;
    ivs.m_height = 3312;
    ivs.m_frameRate = 7;
    InputVideoSourceCollection vivs(nullptr);
    vivs.push_back(ivs);
    s_vs = s_vsFact->createMultiple(&vivs,true);

    bool bRet = (s_vs != nullptr);
    QCOMPARE(bRet,true);
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),1);
    QString id0 = *vec.begin();
    QString id1 = s_vs->getId();
    QCOMPARE(id0 == QString(),false);
    QCOMPARE(id0,id1);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
    VideoSourceConfig *config = s_vs->getConfig(0);
    QStringList namesOfInputDirectShowVirtualDevices = config->namesOfInputDirectShowVirtualDevices();
    QCOMPARE(namesOfInputDirectShowVirtualDevices.size(),1);
    QString el0 = config->namesOfInputDirectShowVirtualDevices()[0];
    QCOMPARE(el0,QString("USB Camera-OV580"));
    QCOMPARE(config->nameOfOutputDirectShowVirtualDevice(),QString("Fortis Video Source"));
    delete config;
    //config->deleteLater();
}

void VideoSourceTest::startPipelineMultiple()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->start();
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Running"));
}

void VideoSourceTest::stopPipelineMultiple()
{
    QVERIFY(s_vs != nullptr);

    bool bRet = s_vs->stop(-1);
    QCOMPARE(bRet,true);
    QString currentState = s_vs->getState();
    QCOMPARE(currentState,QString("State::Init"));
}

void VideoSourceTest::destroyPipelineMultiple()
{
    QVERIFY(s_vsFact != nullptr);
    QVERIFY(s_vs != nullptr);

    //s_vs->deleteLater();
    delete s_vs;
    s_vs = nullptr;
    QStringList vec = s_vsFact->listIDs();
    QCOMPARE(vec.size(),0);
}
