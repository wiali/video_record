#ifndef VIDEO_SOURCE_TESTS_H 
#define VIDEO_SOURCE_TESTS_H


#include <QTest>
#include <QScopedPointer>


#include "video_source.h"

namespace fortis {
    namespace video {
        namespace source {
            namespace test {


/*! \brief Unit Test class for VideoSource.
 *  \details This is a QTest compliant class used to validate the functionality provided by VideoSource plugin.
 */
class VideoSourceTest : public QObject
{
     Q_OBJECT

private Q_SLOTS:

    /*! \brief Called before each test is executed.
     */
     void init();

    /*! \brief Called after each test is executed.
     */
     void cleanup();

     /*! \brief Create video source class factory.
      */
     void createFactory();

     /*! \brief Create video pipeline.
     */
     void createPipelineDefault();

     /*! \brief Attempt to create 2nd video pipeline.
      *  \details Should fails, because we currently don't allow for more than 1 pipeline at any time.
     */
     void createPipeline2Fail();

     /*! \brief Create and start Nizza graph
     */
     void startPipelineDefault();

     /*! \brief Stop Nizza graph
      */
      void stopPipelineDefault();

      /*! \brief Destroy video pipeline.
      */
      void destroyPipelineDefault();

      /*! \brief Create video pipeline.
      *   \details Create pipeline passing list of video sources as parameter.
      */
      void createPipelineSingle();

      /*! \brief Create and start Nizza graph
      */
      void startPipelineSingle();

      /*! \brief Stop Nizza graph
       */
       void stopPipelineSingle();

       /*! \brief Destroy video pipeline.
       */
       void destroyPipelineSingle();

       /*! \brief Create video pipeline.
       *   \details Create pipeline passing list of video sources as parameter.
       */
       void createPipelineMultiple();

       /*! \brief Create and start Nizza graph
       */
       void startPipelineMultiple();

       /*! \brief Stop Nizza graph
        */
        void stopPipelineMultiple();

        /*! \brief Destroy video pipeline.
        */
        void destroyPipelineMultiple();
       /*! \brief Destroy video source class factory.
       */
      void destroyFactory();
};
}}}}

#endif // VIDEO_SOURCE_TESTS_H 
