#include "video_source_tests.h" 


using namespace fortis::video::source::test;
QTEST_MAIN(VideoSourceTest)
