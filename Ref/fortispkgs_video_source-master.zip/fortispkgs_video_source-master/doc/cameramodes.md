# Settings for various Camera modes

It is important to configure `Camera`, `Projector` and `video_source` pipeline correctly in various environments in order to achieve optimal results. This document covers the use of parameters that need to be set for following environments. **In all modes, `Projector` needs to be turned _on_**:

* **Desktop Mode** - in this mode image projected on the mat is the Windows desktop image
* **Lamp Off** - in this mode artificial window with __black__ background is displayed on mat which forces projector to go to minimum nominal brightness
* **Lamp On** - in this mode artificial window with __white__ background is displayed on mat which forces projector to go to maximum nominal brightness
* **Flash Mode** - this mode is similar to Lamp On mode with exception of short-term increate of projector brigtness to maximum possible value. This projector mode leads to quick overheating but provides exceptional brightness so it's available only for limited period of time.

Following table summarizes various parameters that needs to be set in various components to achieve a specific Mode:

| Call and Parameter | Value to use for `Desktop Mode` | Value to use for `Lamp On` | Value to use for `Lamp Off` | Value to use for `Flash Mode` |
| ---------------------------:  | :-----------------------------------: | :-----------------------------: | :-----------------------------: | :--------------------------------: |
| **Projector** <br> note: Call `proapi::Projector::on()` to reset from grayscale and flash states |  |  |  |  |
| `proapi::Projector::on()` | n/a | n/a | n/a | n/a |
| `proapi::Projector::grayscale(bool)` | `false` | `true` | `false` | n/a |
| `proapi::Projector::flash(bool)` | `false` | `false` | `false` | `true` |
|  |  |  |  |  |
| **Touchmat** |  |  |  |  |
| `proapi::Touchmat::setTouchState(bool)` | `true` | `false` | `false` | `false` |
|  |  |  |  |  |
| **Camera** <br> note: Camera parameters need to be set _after_ camera resolution |  |  |  |  |
| `proapi::Camera::autoGainEnabled(bool)` | `true` | `true` | `true` | `false` |
| `proapi::Camera::gain(uint)` | n/a | n/a | n/a | *device default |
| `proapi::Camera::autoExposureEnabled(bool)` | `true` | `true` | `true` | `false` |
| `proapi::Camera::exposure(uint)` | n/a | n/a | n/a | *device default |
| `proapi::Camera::autoWhiteBalanceEnabled(bool)` | `true` | `true` | `true` | `false` |
| `proapi::Camera::whiteBalance(rgb)` | n/a | n/a | n/a | *device default |
| `proapi::Camera::gammaCorrectionEnabled(bool)` | `true` | `true` | `true` | `true` |
| `proapi::Camera::lensColorShadingEnabled(bool)` | `true` | `true` | `true` | `true` |
| `proapi::Camera::lensShadingEnabled(bool)` | `true` | `true` | `true` | `true` |
|  |  |  |  |  |
| **Video Source Pipeline** <br> Note: You need to directly change `SourcePipeline` properties |  |  |  |  |
| `SourcePipeline::configuration()::sharpen.included` | `true` | `true` | `true` | `true` |
| `SourcePipeline::configuration()::illuminationCorrection.included` | `false` | `false` | `false` | `true` |
| `SourcePipeline::configuration()::colorCorrection.included` | `false` | `true` | `false` | `false` |
| `SourcePipeline::illuminationCorrection()::setEnabled` | `false` | `false` | `false` | `true` |
| `SourcePipeline::illuminationCorrection()::setAutoWhiteBalance` | `false` | `false` | `false` | `true` |



TODO: Code an example using ProAPI enabling flash-mode when missing details are available.
