This video source package provides a unified way of accessing video streams from various sources available with the default Sprout configurations and with custom configurations also for other sources like externally connected webcams and others that are not part of default hardware configurations. 

Each video source available on Sprout is used through this package to provide all necessary image-corrections in order to provide the best image quality (for example built-in hi-resolution camera is operating under angle so perspective warp is necessary to produce rectangular image). This package also supports compositing of multiple video sources into single output stream to allow layouting (e.g. side-by-side) as well picture-in-picture compositing.

Video pipeline consists of following components:

```
+----------------+      
|  Input source  |  -----------\ 
+----------------+             |
                               v
+-----------------+      +------------+      +-------------+
|  Input source   |  --> | Compositor |  --> | Output sink |
+-----------------+      +------------+      +-------------+
                               ^
+----------------+             |
|  Input source  |  -----------/ 
+----------------+            
```

For debugging purposes, it's possible to display the video pipeline with latencies (aka Nizza monitor) by setting the property `video::source::OutputVideoSinkConfig::monitorWindowSize` on the instance of `video::source::VideoPipeline::outputSinkConfiguration` to the desired window size. By default this property contains size of `0x0` which means that the monitor window will not be displayed.

Video pipeline reads its default configuration values from file located in the user's local app data folder, for example `$env:LocalAppData/video_source/config.ini`.

## Creating the video pipeline

The video pipeline instance can be created by creating an instance of `video::source::VideoPipeline`. Please note that there can be _only_ be a _single_ `video::source::VideoPipeline` per-process running at the time.

By default the video pipeline will have no input sources but it will default to `video::source::VideoPipeline::outputSinkConfiguration`. This default output sync configuration is read from the configuration file `config.ini`'s section `[default_sink]`:

```ini
[default_sink]
name=Fortis Video Source
size=@Size(2200 1660)
```

Until a pipeline is started it is possible to change the configuration of the video pipeline. This includes the configuration of output sync and configuration of the input sources. After the pipeline is started it is not possible to, for example add new input sources or change the output sync resolution. 

Output sync configuration can be changed by calling `video::source::VideoPipeline::setOutputSinkConfiguration` method and passing the configuration object.

**NOTE**: The video pipeline must contain at least one input source in order to be started.

### Example

```cpp
video::source::VideoPipeline videoPipeline;

videoPipeline.addKnownSource(SourcePipeline::DownwardFacingCamera);
videoPipeline.start();
```

## Configuring the output sync

Output sync configuration can be one of two syncs:

* _DirectShow Virtual Camera Sink_ - used to push the composited output frames to the DirectShow Virtual Camera mechanism. After this operation, the consumer application can connect to the Virtual Camera device using the DirectShow pipeline.   
* _Null Sink_ - causes the output frames for each source to be processed, _but_ they are not composited. This is useful if an application wishes to consume the output frames directly by using the `video::source::SourcePipeline::frameBufferReady` signal (see below).

Choice of the output sync is made by changing value of property `video::source::OutputVideoSinkConfig::name`. By specifying an empty name (`QString()`) the pipeline will be constructed with _Null Sync_.

## Configuring the input sources

The video pipeline can compose inputs from multiple input sources into a single output image to create side-by-side or picture-in-picture configurations.  

Input sources can be added by calling:    
  * `video::source::VideoPipeline::addKnownSource` method for well-known sources with one of predefined configurations defined by the `video::source::SourcePipeline::SourcePipelineType` enum. Configurations of input sources are read from `config.ini`, e.g.:
```ini
[source:DownwardFacingCamera]
name=USB Camera-OV580
frame_rate=7
size=@Size(4416 3312)
auto_exposure_enabled=true
auto_white_balance_enabled=true
```  

Sources that need extensive post-processing (e.g. DownwardFacingCamera) tied to video resolution must define proper calibration values
for each filter. To simplify this operation for non-default resolutions consumers can pass parameter `resolution` to
`video::source::VideoPipeline::addKnownSource` method that will setup all the calibration data based on video stream resolution:

### Example

```cpp
video::source::VideoPipeline videoPipeline;

// Use half-resolution
videoPipeline.addKnownSource(SourcePipeline::DownwardFacingCamera, QSize(2208, 1656));
videoPipeline.start();
```

This will make sure that frame rate, keystone correction, color correction, illumination correction etc. are properly set for this
resolution. Consumers can call method `video::source::VideoPipeline::knownResolutions` to retrieve list of known resolutions.

  * `video::source::VideoPipeline::addSource` method and passing complete configuration 

There are two major groups of input sources defined by enumeration. `video::source::SourcePipelineConfig::SourceType` and depending on the value of `video::source::SourcePipelineConfig::sourceType` property different configuration options are allowed:

* `Camera` - this type of input source must be OS-recognised camera device that can be accessed using DirectShow. Configuration options are read from property `video::source::SourcePipelineConfig::inputVideoSource`  
* `Desktop` - this type of input source is a portion of OS desktop; configuration options are read from property `video::source::SourcePipelineConfig::desktopCaptureSource`  

After input source is added into the pipeline it's configuration can still be re-configured using `video::source::SourcePipeline::setConfiguration` however any configuration needs to be done before pipeline is started.  

Each input source can be independently enabled or disabled by using the method `video::source::SourcePipeline::setIsEnabled()` while the pipeline is running. This is useful when the capture pipeline includes multiple input streams in a pre-defined layout and one or more input streams needs to be hidden without stopping the pipeline.

## GPU acceleration

It is possible to turn on GPU acceleration for filters to speed up the processing. GPU acceleration is turned off by default and all filters are executed on CPU; it can be enabled by changing the processing backend
in source configuration either in code or in configuration file:

```cpp
SourcePipelineConfig sourceConfig;
sourceConfig.backend = SourcePipelineConfig::Backend::OpenGL;
```

This optimization is prefered on sources with big frame sizes but low frame rates that requires big postprocessing (e.g. Sprout high resolution camera) where execution of filters will counterweight the need of uploading data to / from GPU. Enabling this option on streams that doesn't require postprocessing might result into worse performance then pure CPU processing.

Another usage of this GPU acceleration is when video_source is used from Qt application - in this case it is possible to load video frame into video pipeline, do all the postprocessing and then directly render
the final video frame to the screen which significantly increases the performance of the application and lowers the CPU usage. For details on how to integrate video pipeline with direct rendering see chapter
*Direct GPU rendering*.

### Camera input sources

Camera input sources are identified by their name that is recognized by the operating system. The following properties must be provided in a `video::source::InputVideoSourceConfig` configuration object:   
* `video::source::InputVideoSourceConfig::name` - name of the camera as recognized by operating system  
* `video::source::InputVideoSourceConfig::size` - requested resolution  
* `video::source::InputVideoSourceConfig::frameRate` - requested frame rate  

The input pipeline will try to find a matching device and media format based on this value. Any camera color space will be converted to the BGR color space as part of the post-processing.

### The Desktop input source

The Desktop input source can capture the area of the desktop or a specified window. Both options can be configured by the properties of `video::source::DesktopSourceConfig`:  
* If `video::source::DesktopSourceConfig::windowName` and `video::source::DesktopSourceConfig::className` are set to empty strings, then the desktop area will be captured and `video::source::DesktopSourceConfig::captureArea` needs to be set to proper capture area. In case of multi-display setup all desktops are merged into single logical desktop space.  
* In all other cases a single window is identified using the OS function ([FindWindow](https://msdn.microsoft.com/en-us/library/windows/desktop/ms633499(v=vs.85).aspx)). Additionally the property `video::source::DesktopSourceConfig::windowSizeRefreshDelay` can be set to periodically update the size of the captured image to match resized window.           

Desktop window capture on Windows requires to specify `className` and `windowName` of the window. This can be found using for example [WinLister](http://www.nirsoft.net/utils/winlister.html). This type of capture can be currently configured only using APIs. For example, the following snippet will capture the File Explorer window with the title "Desktop" and it will capture size every second:

```cpp
SourcePipelineConfig windowCaptureConfig;
windowCaptureConfig.sourceType = SourcePipelineConfig::Desktop;
windowCaptureConfig.desktopCaptureSource.windowName = "Desktop";
windowCaptureConfig.desktopCaptureSource.className = "CabinetWClass";
windowCaptureConfig.desktopCaptureSource.windowSizeRefreshDelay = 1000;
videoPipeline->addSource("DesktopWindow", windowCaptureConfig);
```

### Post-processing

Each input source can include a set of the enhancement filters that are queued in this order. Optional filters (enclosed in `[]`) are skipped:  

```
Source -> Conversion to BGR -> Raw frame grabber -> [Illumination correction] -> [Color correction] -> [Keystone correction] -> [Sharpen] -> [Final frame grabber]
```

When GPU rendering is enabled the pipeline combines all the filters into single Combined GPU filter to avoid unnecesary loading to GPU:

```
Source -> Conversion to BGR -> Raw frame grabber -> [Combined GPU filter] -> [Final frame grabber]
```

All configuration and API calls to specific filter is maintained without change - for example same configuration Keystone Correction filter is used for Combined GPU filter.

The image coming from the last filter in the pipeline is passed to the output sync filter.

#### Conversion to BGR space 

In case that input source color space is different from BGR it will be converted before proceeding.

#### Raw frame-grabber

Each input source can request to grab a frame from the BGR color space before it is enhaced or composed. This allows raw data capture for the purpose of later post-processing with for example, higher quality.

Optional filters can include one or more of following:

#### Keystone-correction 

Sources that needs to execute perspective warp in order to compensate for camera position can leverage keystone-correction. Configuration options are wrapped in the class `video::source::KeystoneCorrectionFilterConfig`. For pre-configured `Camera` input sources, the values can also be read from the current system's calibration homography settings, e.g.:

```ini
[keystone_correction:DownwardFacingCamera]
enabled=true
calibration_matrix=cameraFullResToHighResMat
quality=Nearest
```

Since the input image is usually a 14MPix image from the hi-resolution camera, quality settings can drastically affect processing-speed. To address this issue the video source package provides the following filter quality settings:

* `Nearest` - fastest algorithm but lower quality. Use this value if you are optimizing for low CPU usage  
* `Linear` - (default value) linear interpolation algorithm provides better quality but is more time-consuming  

#### Illumination-correction 

Sources that needs to compensate for different lighting conditions can leverage illumination-correction. Configuration options are wrapped in the class `video::source::IlluminationCorrectionFilterConfig` and for pre-configured `Camera` input sources, the values can also be read from the current system's calibration illumination settings.

#### Color-correction

Sources that needs to compensate for different background color conditions can leverage color-correction. Configuration options are wrapped in the class `video::source::ColorCorrectionFilterConfig` and for pre-configured `Camera input` sources, the values can also be read from the current system's calibration color-correction settings.

#### Sharpen 

This filter prodives 3x3 edge sharpen filter to sharpen the image. This filter doesn't provide any configuration options.

#### Final frame-grabber 

Each video source can produce frames with all the filters applied, but before composition. This is useful for an application that needs to perform custom post processing but does not want to apply all the filters themselves. Configuration options are wrapped in the class `video::source::FinalFrameGrabberConfig`.

In case that application wishes to consume output frames directly, it can specify Null Sync (see section _Output Sink Configuration_) and enable the property `video::source::FinalFrameGrabberConfig::isIncluded` in each `video::source::SourcePipeline::configuration`. This option is turned off by default for performance reasons.

By enabling this option, an application can connect to the signal `video::source::SourcePipeline::frameBufferReady`, which will be emitted for each newly available raw frame. As this signal is part of the processing pipeline, applications should not perform _any_ expensive operations in the slot handling for this signal, in order not to block the pipeline. Ideally an application should just copy the data into another memory segment and process image in a separate thread.

**NOTE**: Please make sure that you provide the frame buffer of the correct size by calling `video::source::SourcePipeline::setFrameGrabberBuffer` before the video pipeline is started. Memory segments should be a continous memory segment of size `frame_width * frame_height * bytes_per_pixel`. Parameter `bytes_per_pixel` depends on the channel count of the pixel format specified by `video::source::FinalFrameGrabberConfig::format`. Each channel is 1 byte.

### Image composition

Last step of the input source pipeline is the image-composer, which offers the definition of the viewport. The input source viewport can be used to crop part of the input source image instead of passing the whole area. By default each input source is configured to provide the whole area. This functionality can be used for example to create zooming / panning functionality. The input source viewport is defined in normalized coordinates between (0;0) - (1;1) with (0;0) located in _bottom-left_ corner:   
```
    (0, 1)  +---------------+ (1,1)
            |       |       |
            |   (0.5;0.5)   |
  (0, 0.5)  +-------+-------| (1,0.5)              
            |       |       |
            |       |       |
     (0,0)  +-------+-------+ (1, 0)   

```

In the case that there is only a single input source and the application doesn't wish to use the viewport functionality, the image-composer can be turned off for performance-tuning. To achieve this effect, pass `0x0` to the `size` property of `video::source::VideoPipeline::outputSinkConfiguration`.

**NOTE**: Viewport-normalized coordinates maps to the _input_ source _output_ resolution. This is different from the input resolution if keystone-correction is applied, which can shrink down resolution by using the `video::source::OutputVideoSinkConfig::size` property.

## Composing multiple input sources to a single image

As the final step in the video pipeline, all input sources are composed into a single image with the configured output sync resolution. This allows the ability to maintain performance, as some input sources can contain huge amounts of data (e.g. `DownwardFacingCamera` source provides 14MPix images) however those images cannot usually be displayed in full-quality on displays, so they can be re-sized to the desired resolution.

Second option that is provided for each input source is destination rectangle which uses normalized coordinates mapped to output sink resolution. By default, each input source is configured to be placed in whole area of output sync.

**NOTE**: Please note the difference between the destination rectangle and the viewport - both are using normalized coordinates but for the different resolutions, so clients needs to take care of maintaining the aspect ratio of the input source for mapping into the output sync resolution.

The destination rectangle allows placing and resizing a single input source into the final image. It can be used to produce side-by-side:   
```cpp

video::source::VideoPipeline videoPipeline;

auto source = videoPipeline.addKnownSource(video::source::SourcePipeline::PrimaryDesktop);
source.setDestinationRectangle(QRectF(0.1, 0, 0.3, 0.5));
auto source2 = videoPipeline.addKnownSource(video::source::SourcePipeline::MatDesktop);
source2.setDestinationRectangle(QRectF(0, 0.5, 0.5, 0.5));
```   
or picture in picture output:   
```cpp

video::source::VideoPipeline videoPipeline;

videoPipeline.addKnownSource(video::source::SourcePipeline::PrimaryDesktop);
auto source2 = videoPipeline.addSource(video::source::SourcePipeline::DownwardFacingCamera);
source2.setDestinationRectangle(QRectF(0.65, 0.05, 0.3, 0.3));
```   
   
## Direct GPU rendering

In order to allow GPU rendering directly from video source pipeline into Qt window it is necessary change `video::source::SourcePipelineConfig::backend` to `video::source::SourcePipelineConfig::OpenGL` and
to disable compositor and DirectShow sink:

```cpp
video::source::VideoPipeline videoPipeline;
auto outputSinkConfig = videoPipeline->outputSinkConfiguration();

// Don't stream to DirectShow virtual camera
outputSinkConfig.name = QString();

// Don't include compositor
outputSinkConfig.size = QSize();

videoPipeline->setOutputSinkConfiguration(outputSinkConfig);

auto source = videoPipeline->addKnownSource(video::source::SourcePipeline::SourcePipelineType::DownwardFacingCamera);
auto sourceConfig = source->configuration();

// Use GPU accelerated processing
sourceConfig.backend = SourcePipelineConfig::Backend::OpenGL;

source->setConfiguration(sourceConfig);
```

To display frames from video source in application using GPU acceleration consumers have to create their own widget deriving from QOpenGLWidget:

```cpp
class OpenGlRenderWidget : public QOpenGLWidget
{
    Q_OBJECT
public:
    explicit OpenGlRenderWidget(QWidget *parent = 0) 
      : QOpenGLWidget(parent), m_frameReadyForUpdate(false) {}

    void connectToSource(QSharedPointer<video::source::SourcePipeline> pipeline);

protected:

    virtual void resizeGL(int w, int h) override {
      auto f = QOpenGLContext::currentContext()->functions();

      int side = qMin(width, height);
      f->glViewport((width - side) / 2, (height - side) / 2, side, side);

      QOpenGLWidget::resizeGL(width, height);
    }

    virtual void paintGL() override;

private:
    QSharedPointer<QOpenGLFramebufferObject> m_frameBuffer;
    QSharedPointer<video::source::SourcePipeline> m_pipeline;

    QSize m_frameSize;
    bool m_frameReadyForUpdate;
private slots:

    void onFrameReady(int sourceIndex, const QSize& size);
};
```

After starting the pipeline consumers can attach to the event `video::source::CombinedOpenGLFilter::frameReady` which signalizes availability of new frame:

```cpp
void OpenGlRenderWidget::connectToSource(QSharedPointer<video::source::SourcePipeline> pipeline) {
    m_pipeline = pipeline;
    m_sourceConnection = connect(pipeline->combinedOpenGLFilter(), &video::source::CombinedOpenGLFilter::frameReady, this, &OpenGlRenderWidget::onFrameReady);
}
```

Since all OpenGL-bound functionality must  happen on thread of `OpenGlRenderWidget` we need to store the data and request update when frame is ready:

```cpp
void OpenGlRenderWidget::onFrameReady(int sourceIndex, const QSize &size) {
    Q_UNUSED(sourceIndex);
    if (m_pipeline) {
        m_frameSize = size;
        m_frameReadyForUpdate = true;
        update();
    }
}
```

And finally, convert and copy the data from video pipeline into current OpenGL framebuffer:

```cpp
void OpenGlRenderWidget::paintGL()
{
    auto f = QOpenGLContext::currentContext()->functions();

    if (m_frameSize.isValid() && !m_frameBuffer) {
        QOpenGLFramebufferObjectFormat format;
        format.setInternalTextureFormat(QOpenGLTexture::RGB);

        // Framebuffer has to be created with rendering OpenGL context
        m_frameBuffer.reset(new QOpenGLFramebufferObject(m_frameSize, format));
    }

    if (m_frameBuffer && m_frameReadyForUpdate && m_pipeline) {
        m_pipeline->combinedOpenGLFilter()->convert(m_frameBuffer.data());
        m_frameReadyForUpdate = false;
    }

    f->glClearColor(0, 1, 1, 1);
    f->glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Blit to target framebuffer with inverted Y axis
    QOpenGLFramebufferObject::blitFramebuffer(0, QRect(0, 0, width(), height()),
                                              m_frameBuffer.data(), QRect(0, m_frameSize.height(), m_frameSize.width(), -m_frameSize.height()));
}
```