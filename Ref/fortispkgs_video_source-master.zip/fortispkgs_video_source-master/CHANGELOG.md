# Change Log

This is the Change log for Video Source library, which is used to trace the project changes in chronological order.

## [4.3.2] - 2017-09-21

### Changed

- Updating dependencies `sensor_data` to 1.5.0 and `proapi` to 2.10.3.

## [4.3.1] - 2017-09-11

### Changed

- Updating dependencies

## [4.3.0] - 2017-09-06

### Changed

- Updated library to use `sensor_data` 1.4.0 and `calibration_data` 2.1.0 in order to allow using the new `calibration_data.json` structure.
- Adding new APIs to `ColorCorrectionFilter` allowing to change color correction coefficients on the fly.

## [4.2.2] - 2017-08-22

### Changed

- Updating dependencies

## [4.2.1] - 2017-08-18

### Fixed

- Passing interpolation type for OpenGL filter settings to the combined filter

## [4.2.0] - 2017-08-14

### Added

- Updating dependencies

## [4.1.0] - 2017-08-07

### Added

- Support for GPU accelerated streaming into DirectShow Sink

## [4.0.2] - 2017-08-01

### Changed

- Updating dependencies

## [4.0.1] - 2017-08-01

### Fixed

- Crash when capturing with Intel IPP pipeline

## [4.0.0] - 2017-07-31

### Changed

- _**BREAKING CHANGE**_: `SourcePipeline::isEnabled` changed to `SourcePipeline::enabled`
- _**BREAKING CHANGE**_: `SourcePipeline::setIsEnabled` changed to `SourcePipeline::setEnabled`
- _**BREAKING CHANGE**_: `SourcePipeline::isEnabledChanged` changed to `SourcePipeline::enabledChanged`
- _**BREAKING CHANGE**_: `SourcePipeline::SourcePipelineType` names and values changed
- `SourcePipelineConfig::SourceType` enum key names changed to better match their purpose

### Added

- New option to use GPU acceleration for filters in `SourcePipelineConfig::backend`;
in this version only Null sink is supported
- New filter `CombinedOpenGLFilter`

## [3.4.1] - 2017-06-29

### Changed

- Fixing issue with multiple sources

## [3.4.0] - 2017-06-29

### Added

- Added support for Orbbec RGB streaming. Capture support is still pending (color conversion from RGB to BGR).

## [3.3.1] - 2017-06-29

### Changed

- Fixing issue with multiple sources routed to Null sink.
- Fixing memory leak.

## [3.3.0] - 2017-06-29

### Changed

- Updating to ProAPI 2.5.0

## [3.2.1] - 2017-06-28

### Changed

- Using ProAPI to calculate proper DPI for captured images

## [3.2.0] - 2017-06-26

### Added

- Added new parameter `resolution` to `VideoSource::addKnownSource` for easier resolution definition for known sources.
- Added complimentary method `VideoSource::knownResolutions` to obtain list of known resolutions that can be used.

## [3.1.0] - 2017-06-21

### Fixed
- Enhanced documentation.
- No longer export symbols for inline classes.

### Changed
- No longer exposed as plugin. It did not implement any plugin interface in any case.
- Removed `Q_PROPERTY`s that could not be used.

## [3.0.0] - 2017-06-02

### Added

- Adding support for calculating DPI of captured images available automatically for
`SourcePipeline::DownwardFacingCamera` and all `SourcePipelineConfig::Desktop`.
- Added configuration value `SourcePipelineConfig::deviceDimensions` to override dimensions of device for DPI calculation.  

### Changed

- _**BREAKING CHANGE**_: Configuration value `InputVideoSourceConfig::captureType` moved to
  `SourcePipelineConfig::captureType`
- Removed `calibration` package dependency, adding `calibration_data-1.1.0`.
- Updated `sensor_data` to 1.3.0.
- Using new IPP packages separated by domain with configurable deploy.
  * This requires FPM 1.7.4 or later.

### Fixed

- `SourcePipelineConfig::captureType` is used to fill out `SensorData`

## [2.0.2] - 2017-05-30

### Fixed
- Fixing deletion of still capture sync.

## [2.0.1] - 2017-05-26

### Fixed
- Fixing information passed in metadata to image enhancement

## [2.0.0] - 2017-05-26

### Changed
- _**BREAKING CHANGE**_: Renaming boolean properties from `isEnabled` to `enabled`, `isIncluded` to `included`, etc.  
- _**BREAKING CHANGE**_: `KeystoneCorrectionFilterConfig`, `IlluminationCorrectionFilterConfig` and `ColorCorrectionFilterConfig` now accepts mapping to calibration homography instead of raw values.  
- _**BREAKING CHANGE**_: Renaming `SourcePipeline::captureFrame` to `SourcePipeline::captureVideoFrame`
- Adding new option to request still frame capture via `SourcePipeline::captureStillFrame`
- `VideoPipeline::capture` now accepts list of sources that should be captured using still frame method.

### Added
- New `SourcePipelineType::SproutCamera` configuration

## [1.3.1] - 2017-05-24

### Fixing
- Adding `try`/`catch` block to handle Nizza log exceptions

## [1.3.0] - 2017-05-17

### Added
- Adding new API to set Nizza log file location

## [1.2.0] - 2017-05-05

### Changed
- Updated Sensor Data dependency to 1.2.0

## [1.1.5] 2017-05-02

### Changed
- Sharpen filter is now enabled only for downward facing camera
- Settings path is `%localappdata%/hp/video_source/config.ini`

## [1.1.4] 2017-04-25

### Fixed
- Fixing issue when mirror filter was not deleted properly

## [1.1.3] 2017-04-24

### Changed
- Increasing forward-facing camera resolution to 1920x1080@30fps, dropping support for Gen1 camera for now

## [1.1.2] 2017-04-24

### Fixed
- Cleaning up connections between video pipeline restarts

## [1.1.1] 2017-04-21

### Changed
- Updating copyright information in headers.

## [1.1.0] 2017-04-19

### Changed
- Removed explicit dependency from Qt libraries in package.json.

## [1.0.2] - 2017-04-18

### Fixed
- Documentation update & deployment fix.

## [1.0.1] - 2017-04-05

### Fixed
- Linting, code style & documentation update.

## [1.0.0] - 2017-04-05

### Fixed
- Fixing order of filters.

### Changed
- Promoted to major 1 version

## [0.26.3] - 2017-03-27

### Fixed
- Resetting video pipeline state when any error occurs during startup.

## [0.26.2] - 2017-03-23

### Changed
- Use calibration 4.0.5 and ProAPI 2.1.0.

## [0.26.1] - 2017-03-23

### Fixing
- Taking programmatic setting of keystone-correction configuration into account.

## [0.26.0] - 2017-03-20

### Changing
- `QByteArray` is quite uneffective when moving between threads so adding option to provide own frame buffer instead.

## [0.25.3] - 2017-03-20

### Fixing
- Adding support for quarter-res (2K) calibration data.

## [0.25.2] - 2017-03-17

### Fixing
- Removing test for calibration data in capture - if pipeline is running then calibration data must be present or they are not needed

## [0.25.1] - 2017-03-16

### Adding
- Adding information about `LampOn` and `LampOff` color-correction into `sensorData`

## [0.25.0] - 2017-03-16

### Adding
- Adding option to toggle between `LampOn` and `LampOff` color-correction

## [0.24.0] - 2017-03-10

### Adding
- Adding option to mirror output image

## [0.23.4] - 2017-03-09

### Changed
- Updated dependencies

## [0.23.3] - 2017-03-06

### Fixed
- Fixing color channel order for color-correction

## [0.23.2] - 2017-03-06

### Fixed
- Fixing wrong inclusion of color-correction filter

## [0.23.1] - 2017-03-01

### Fixed
- Fixing read out of calibration of color-correction data

## [0.23.0] - 2017-03-01

### Added
- Exposing `colorCorrection` filter

## [0.22.0] - 2017-03-01

### Added
- Updating dependencies and adding precompiled header

## [0.21.0] - 2017-02-23

### Added
- New Color-correction filter
- Reworking memory management

## [0.20.5] - 2017-02-17

### Changed
- Fixing release of already stopped Nizza graph

## [0.20.4] - 2017-02-14

### Changed
- Fixing pipeline construction when camera is in use

## [0.20.3] - 2017-02-14

### Changed
- Updating dependencies

## [0.20.2] - 2017-02-13

### Changed
- Fixing DirectShow filter inclusion

## [0.20.1] - 2017-02-09

### Fixing

- Restarting the video stream after last source was disabled

## [0.20.0] - 2017-02-06

### Changed

- Removing `VideoPipelineFactory` since there cannot be more than 1 Nizza pipeline

## [0.19.4] - 2017-02-03

### Fixed

- Updating dependencies

## [0.19.3] - 2017-02-03

### Fixed

- Updating dependencies and documentation
- Proper order of auto white balance and illumination-correction filters

## [0.19.1] - 2017-02-02

### Fixed

- Properly filling out which filters are currently in use for image enhancement

## [0.19.0] - 2017-02-02

### Added

- Exposing control of auto white balance filter properties

### Fixed

- Setting default value of keystone-correction to `Linear`
- Adding two cameras (e.g. DownwardFacing & ForwardFacing) no longer crashes the video pipeline

## [0.18.1] - 2017-02-01

### Fixed

- Pipeline restarting
- VideoPipeline now properly switches to Unintialized state after last source is removed

## [0.18.0] - 2017-01-30

### Changed

- Adding option to specify output format for final frame grabber (`OutputVideoSinkConfig::frameGrabber`)
- Updating dependencies
- Keystone-correction default quality is now `Linear`
- Refactoring to allow separate frame grabbers
- Fixing memory consumption issues
- Removing dependency on ProAPI camera - since it needs to be setup based on the environment it's consumer's responsibility to setup proper camera mode
- Renaming `isEnabled` filter configuration property to `isIncluded` to distinguish between filter included and enabled state
- Exposing control of illumination filter properties

### Fixed

- Fixing reading of quality setting for keystone-correction

## [0.17.0] - 2017-01-25

### Fixed

- Filling in `highresrgb` sensor data type
- Updating dependencies

### Changed

- API signature for `SourcePipeline::capture`

## [0.16.8] - 2017-01-25

### Fixed

- Updating dependencies

## [0.16.7] - 2017-01-24

### Fixed

- Fixing issue with streaming from multiple DirectShow sources (e.g. DownwardFacing and ForwardFacing camera) in same pipeline

## [0.16.6] - 2017-01-23

### Fixed

- Fixing release of Desktop source pointer to allow proper restarting of the pipeline.

## [0.16.5] - 2017-01-23

### Fixed

- Optimizing video pipeline in special case when there is Null Sync at the end of the pipeline and Final Frame Graber is disabled. In this case it's not necessary to execute filters - output will be discarded anyway.

## [0.16.4] - 2017-01-23

### Fixed

- Registering custom types for cross-thread access

## [0.16.3] - 2017-01-20

### Fixed

- Reading new camera properties from configuration file.

## [0.16.2] - 2017-01-20

### Fixed

- Stopping the pipeline is now deterministic.

## [0.16.1] - 2017-01-20

### Fixed

- Restarting the video pipeline is now working.

## [0.16.0] - 2017-01-20

### Changed

- Signature of `VideoPipeline::capture()` doesn't create unnecessary `QSharedPointer`

## [0.15.6] - 2017-01-20

### Changed

- Fixing public API dependency on dev `image_filter` dependency

## [0.15.5] - 2017-01-19

### Changed
- Adding more options for Fortis camera settings (`InputVideoSourceConfig::isAutoGainEnabled`, `InputVideoSourceConfig::isLensShadingEnabled`, `InputVideoSourceConfig::isLensColorShadingEnabled`, `InputVideoSourceConfig::isGammaCorrectionEnabled`)
- Removing duplicate items from captured SensorData

## [0.15.4] - 2017-01-19

### Changed
- Updating product name

## [0.15.3] - 2017-01-19

### Changed

- Adding option to skip composer when there is just single input source
- Updating copyright information

## [0.15.2] - 2017-01-18

### Changed

- Added option to define Null sync
- Updated dependencies

## [0.15.1] - 2017-01-17

### Changed

- Updated dependencies

## [0.15.0] - 2017-01-17

### Added

- Adding configuration parameter for `VideoPipeline::frameReady()`
- Adding configuration parameter for showing Nizza monitor
- Adding command line options for integration test

### Changed

- Adding source index to all filter names to allow parallel camera display

## [0.14.0] - 2017-11-13

### Changed

- Adding parameter to enable `VideoPipeline::frameReady()` processing (default is off to avoid performance hit).
- Refactoring & documentation

## [0.13.0] - 2017-11-11

### Changed

- Adding new signal to allow retrieval of final frames `VideoPipeline::frameReady()`.
- Adding support for regex matching of camera names
- Adding Forward Facing camera regex to support both 1.55 and 1.6 HW

## [0.12.1] - 2016-12-22

### Changed

- Documentation updates.

## [0.12.0] - 2016-12-22

### Changed

- Removing `config.ini` and adding default configuration into source files.

## [0.11.2] 2016-12-21

### Changed

- Updated dependencies

## [0.11.1] 2016-12-20

### Changed

- Updated to use official SensorData and Calibration library packages

## [0.11.0] 2016-12-20

### Changed

- Using exceptions instead of error codes
- Adding PImpl facade
- Removing custom types in favor of Qt types
- Use ProAPI Camera object instead of Camera Fortis Package

## [0.10.0] 2016-12-15

## Added

- New API for adding known and custom configuration of input source (`VideoPipeline::addKnownSource`, `VideoPipeline::addSource`)
- New configuration option for capturing specific desktop window (`DesktopSourceConfig::windowName`, `DesktopSourceConfig::className` and `DesktopSourceConfig::windowSizeRefreshDelay`)
- New API to enable or disable single input source (`SourcePipeline::setIsEnabled()`)

## [0.9.0] 2016-12-12

### Added

- Option to make composite video output by adding multiple pre-defined sources
- Configurable sync options (width, height, DS sink name)
- Configurable sources with predefined default sources for Desktop and Camera inputs
- New API to position single input in composite video output `SourcePipeline::setOutputRectangle`
- New API to capture frames from all sources

## Removed

- Deprecating `VideoPipeline::pan` and `VideoPipeline::zoom` in favor of more generic `SourcePipeline::setViewport`

## [0.8.1] 2016-12-05

### Added

- Added Desktop and Forward camera support

## [0.8.0] 2016-11-30

### Changed

- Refactoring APIs and extracting configuration to configuration files
- Removing sourceIndex from VideoPipeline calls
- Renaming method `getFrame` to `captureFrame`
- Removing `VideoPipeline::started` and `VideoPipeline::finished` signals in favor on generic signal `VideoPipeline::stateChanged`
- Changing zoom factor to start with 1

## [0.7.1] - 2016-11-28

### Fixed

- Fixed SPROUT-14274
- Updated zoom API to take zoom factor (0x to 10x) instead of percent

## [0.7.0] - 2016-11-28

### Changed

- Deprecated APIs `VideoPipelineFactory::createDefault`, `VideoPipelineFactory::createSingle` and `VideoPipelineFactory::createMultiple` in favor of new API `VideoPipelineFactory::get`

## [0.6.18] - 2016-11-21

### Changed

- Using Intel IPP to perform conversion from BGR to RGB

## [0.6.17] - 2016-11-19

### Changed

- Using real homography

## [0.6.16] - 2016-11-19

### Changed

- Using new `image_filter` option to crop image after keystone-correction
- Updated `getFrame` signature to return `SensorData`

##  [0.6.15] - 2016-11-17

### Changed 

- Using new `image_filters` package

## [0.6.14] - 2016-11-16

__Eaten by Grufallo__
