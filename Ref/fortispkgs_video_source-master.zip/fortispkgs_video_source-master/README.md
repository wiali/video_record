# Video Source

The `video_source` package provides infrastructure to create and connect to existing video pipelines using Nizza framework.
Each pipeline can be configured and managed independently.

Please see [documentation frontpage](./doc/mainpage.md) on additional information and [capture sample](https://github.azc.ext.hp.com/FortisPkgs/samples/tree/master) on how to use this package to capture a frame and access video stream.

## Running the integration test

### Pre-requisities  

In order to stream frames, we need Intel's IPP in PATH, as well as access to the Nizza COM object. We can do this by installing some pre-requisites that are currently mandatory for the integration test:

1. Install Capture WorkTool  
2. Install the G2 SDK  

Failing to do this will likely result in crashes for the test.

_**Note**_: _Using the integration test's `Capture still frame` currently is only for Hurley hardware_.

### Dependencies  

All required DLLs should be copied by `deployDependencies()` method.
Nevertheless, it was observed that on some systems some Qt DLLs are not copied. The root cause is yet to be determined.

In those cases, you will need to manually copy following additional DLLs from corresponding Qt location (e.g. `C:\Qt\x64\vs2015\qt561-1_x64\5.6\msvc2015_64\bin`) to output folder (e.g. `fortispkgs_video_source\build\win32-msvc2015-x64-r`):

* `Qt5OpenGL.dll`
* `Qt5Multimedia.dll`
* `Qt5MultimediaWidgets.dll`

Additionally you will need to copy OS-specific multimedia plugins from Qt plugin location `C:\Qt\x64\vs2015\qt561-1_x64\5.6\msvc2015_64\plugins` to output folder.
