#ifndef IMAGE_FILTERS_TEST_H
#define IMAGE_FILTERS_TEST_H

#include <QObject>
#include <QPointer>
#include <QOpenGLContext>
#include <QOffscreenSurface>

#include <image_filters/imagefilter.h>

namespace image_filters_test {

class ImageFiltersTest : public QObject
{
    Q_OBJECT
public:
    explicit ImageFiltersTest(QObject* parent = nullptr);

private Q_SLOTS:
    /*! \brief Called before whole test cases is executed.
     */
    void init();

    /*! \brief Called after whole test cases is executed.
     */
    void cleanup();

    void autoWhiteBalance();

    void illuminationCorrection();

    void keystoneCorrection();

    void sharpen();

    void crop();

    void cropSameSize();

    void convertBGRtoRGB();

    void resize();

    void resizeSameSize();

    void paste();

    void convertRGBtoRGBA();

    void colorCorrection();

    void mirror();

    void documentationSamples();

    void combinedNone();

    void combinedIlluminationCorrection();

    void combinedKeystoneCorrection();

    void combinedSharpen();

    void combinedAutoWhiteBalance();

    void combinedColorCorrection();

    void combinedMirrorVertical();

    void combinedMirrorHorizontal();

    void combined();

private:

    QGenericMatrix<1, 6, float> illuminationCoefficients();

    QGenericMatrix<3, 8, float> colorCoefficients();

    QPointer<image_filters::ImageFilter> m_imageFilter;

    QPointer<QOpenGLContext> m_context;

    QPointer<QOffscreenSurface> m_surface;
};

} // image_filters

#endif // IMAGE_FILTERS_TEST_H
