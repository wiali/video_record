#include <QTest>

#include "image_filters_test.h"

QTEST_MAIN(image_filters_test::ImageFiltersTest)
