#ifndef __clang_analyzer__

#include <QTest>
#include <QSignalSpy>
#include <QDebug>
#include <QSharedMemory>
#include <QVariant>
#include <QStandardPaths>
#include <QElapsedTimer>
#include <QMutex>
#include <QGuiApplication>

#include <fstream>
#include <memory>

#include <image_filters/imagefilterexception.h>
#include "image_filters_test.h"

#define TEST_PRELUDE QImage input("../../image_filters_test/data/hiresWarpped.png"); \
    QImage output(input.size(), input.format()); \
    QElapsedTimer timer; \
    timer.start();

#define TEST_PRELUDE_RAW QFile file("../../image_filters_test/data/img_DownwardFacingCamera_3022.raw"); \
    file.open(QIODevice::ReadOnly); \
    QImage input(4416, 3312, QImage::Format_RGB888); \
    auto fileData = file.readAll(); \
    memcpy(input.bits(), fileData.data(), fileData.length()); \
    QImage output(input.size(), input.format()); \
    QElapsedTimer timer; \
    timer.start();

#define TEST_FINALE(filename) TEST_PERF \
    output.save(filename);

#define TEST_PERF qInfo() << "Average performance" << ((float)timer.elapsed()) / (float)samples << "ms per image (" << samples << "samples)";

namespace image_filters_test {

ImageFiltersTest::ImageFiltersTest(QObject* parent)
    : QObject(parent)
    , m_imageFilter(nullptr)
{ }

void ImageFiltersTest::init()
{
    m_imageFilter = new image_filters::ImageFilter(this);

    auto a = static_cast<QGuiApplication*>(QGuiApplication::instance());

    QSurfaceFormat format;
    format.setVersion(2, 0);
    m_context = new QOpenGLContext();
    m_context->setScreen(a->screens().first());
    m_context->setFormat(format);

    m_context->create();

    m_surface = new QOffscreenSurface();
    m_surface->create();

    m_context->makeCurrent(m_surface);
}

void ImageFiltersTest::cleanup()
{
    m_context->doneCurrent();
    delete m_surface;
    delete m_context;
    delete m_imageFilter;
}

void ImageFiltersTest::autoWhiteBalance()
{
    TEST_PRELUDE_RAW;
    const int samples = 100;

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->autoWhiteBalance({ input.size(), input.format(), input.bits() }, output.bits());
    }


    TEST_FINALE("C:/temp/autoWhiteBalance_ipp.png")
}

void ImageFiltersTest::combinedNone()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;

    QOpenGLFramebufferObject frameBuffer(input.size());
    auto data = m_imageFilter->combinedInit(input.size(), { });

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data);
    }    

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedNone.jpg");
}

void ImageFiltersTest::combinedIlluminationCorrection()
{
    TEST_PRELUDE_RAW;

    image_filters::CombinedFilterSettings settings;
    settings.illuminationCoefficients = illuminationCoefficients();

    QOpenGLFramebufferObject frameBuffer(input.size());

    const int samples = 10;

    auto data = m_imageFilter->combinedInit(input.size(), settings);
    auto filters = image_filters::ImageFilter::CombinedFilter::IlluminationCorrection;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedIlluminationCorrection.jpg");
}

void ImageFiltersTest::combinedKeystoneCorrection()
{
    TEST_PRELUDE_RAW;

    image_filters::CombinedFilterSettings settings;
    settings.keystoneCorrectionTransformation = QTransform(1.0017250987536013,
                                                           -0.12554803827773522,
                                                           -184.15298590696472,
                                                           0.0021158136477528646,
                                                           0.9645927567446152,
                                                           -334.48768852440429,
                                                           1.3555052364720054e-06,
                                                           -5.9370750047008174e-05);
    settings.keystoneCorrectedSize = QSize(4200, 2800);
    settings.interpolationType = image_filters::InterpolationType::Linear;
    output = output.copy(0, 0, settings.keystoneCorrectedSize.width(), settings.keystoneCorrectedSize.height());

    QOpenGLFramebufferObject frameBuffer(settings.keystoneCorrectedSize);

    const int samples = 10;

    auto data = m_imageFilter->combinedInit(input.size(), settings);
    auto filters = image_filters::ImageFilter::CombinedFilter::KeystoneCorrection;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedKeystoneCorrection.png");
}

void ImageFiltersTest::combinedColorCorrection()
{
    TEST_PRELUDE_RAW;

    image_filters::CombinedFilterSettings settings;
    settings.colorCorrectionLampOffCoefficients = colorCoefficients();

    QOpenGLFramebufferObject frameBuffer(input.size());
    const int samples = 10;

    auto data = m_imageFilter->combinedInit(input.size(), settings);
    auto filters = image_filters::ImageFilter::CombinedFilter::ColorCorrection;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedColorCorrection.jpg");
}

void ImageFiltersTest::combinedSharpen()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;

    image_filters::CombinedFilterSettings settings;
    settings.interpolationType = image_filters::InterpolationType::Linear;
    QOpenGLFramebufferObject frameBuffer(input.size());

    auto data = m_imageFilter->combinedInit(input.size(), settings);
    auto filters = image_filters::ImageFilter::CombinedFilter::Sharpen;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedSharpen.png");
}

void ImageFiltersTest::combinedAutoWhiteBalance()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;

    QOpenGLFramebufferObject frameBuffer(input.size());
    auto data = m_imageFilter->combinedInit(input.size(), {});
    auto filters = image_filters::ImageFilter::CombinedFilter::AutoWhiteBalance;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedAutoWhiteBalance.jpg");
}

void ImageFiltersTest::combinedMirrorVertical() {
    TEST_PRELUDE_RAW;

    const int samples = 10;

    QOpenGLFramebufferObject frameBuffer(input.size());
    auto data = m_imageFilter->combinedInit(input.size(), {});
    auto filters = image_filters::ImageFilter::CombinedFilter::Mirror;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters,
                                image_filters::ImageFilter::ColorCorrectionMode::LampOff, image_filters::MirrorType::Vertical);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedMirrorVertical.jpg");
}

void ImageFiltersTest::combinedMirrorHorizontal() {
    TEST_PRELUDE_RAW;

    const int samples = 10;

    QOpenGLFramebufferObject frameBuffer(input.size());
    auto data = m_imageFilter->combinedInit(input.size(), {});
    auto filters = image_filters::ImageFilter::CombinedFilter::Mirror;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters,
                                image_filters::ImageFilter::ColorCorrectionMode::LampOff, image_filters::MirrorType::Horizontal);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combinedMirrorHorizontal.jpg");
}

void ImageFiltersTest::combined()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;

    QOpenGLFramebufferObject frameBuffer(input.size());

    image_filters::CombinedFilterSettings settings;
    settings.colorCorrectionLampOffCoefficients = colorCoefficients();
    settings.keystoneCorrectionTransformation = QTransform(1.0017250987536013,
                                                           -0.12554803827773522,
                                                           -184.15298590696472,
                                                           0.0021158136477528646,
                                                           0.9645927567446152,
                                                           -334.48768852440429,
                                                           1.3555052364720054e-06,
                                                           -5.9370750047008174e-05);
    settings.keystoneCorrectedSize = QSize(4200, 2800);
    settings.illuminationCoefficients = illuminationCoefficients();
    settings.interpolationType = image_filters::InterpolationType::Linear;
    output = output.copy(0, 0, settings.keystoneCorrectedSize.width(), settings.keystoneCorrectedSize.height());

    auto data = m_imageFilter->combinedInit(input.size(), settings);

    auto filters = image_filters::ImageFilter::CombinedFilter::AutoWhiteBalance |
                   image_filters::ImageFilter::CombinedFilter::KeystoneCorrection |
                   image_filters::ImageFilter::CombinedFilter::ColorCorrection |
                   image_filters::ImageFilter::CombinedFilter::IlluminationCorrection |
                   image_filters::ImageFilter::CombinedFilter::Sharpen |
                   image_filters::ImageFilter::CombinedFilter::Mirror;

    for (auto i = 0; i < samples; i++)
    {
        m_imageFilter->combined({ input.size(), input.format(), input.bits() }, &frameBuffer, data, filters,
                                image_filters::ImageFilter::ColorCorrectionMode::LampOff, image_filters::MirrorType::Both);
    }

    TEST_PERF
    frameBuffer.toImage(false).save("C:/temp/combined.jpg");
}

QGenericMatrix<1, 6, float> ImageFiltersTest::illuminationCoefficients()
{
    QGenericMatrix<1, 6, float> coeff;
    coeff(0,0) = 2.5230617942129108e-11f;
    coeff(1,0) = -1.0221334179050245e-07f;
    coeff(2,0) = -1.0395525151807306e-07f;
    coeff(3,0) = 0.00043135794112458825f;
    coeff(4,0) = -2.1098026991239749e-05f;
    coeff(5,0) = 0.15029878914356232f;

    return coeff;
}

QGenericMatrix<3, 8, float> ImageFiltersTest::colorCoefficients()
{
    QGenericMatrix<3, 8, float> coeff;

    coeff(0,0) = -7.5758323225816326e-12f;
    coeff(1,0) = -7.4532489555134696e-12f;
    coeff(2,0) = 9.0845291358943037e-12f;
    coeff(3,0) = 1.9898789647282422e-12f;
    coeff(4,0) = -4.1034724063138128e-08f;
    coeff(5,0) = 0.00012325085117481649f;
    coeff(6,0) = -3.2430936698801816e-05f;
    coeff(7,0) = 0.6693977117538452f;

    coeff(0,1) = -8.9153346163883818e-12f;
    coeff(1,1) = -7.3469537745229907e-12f;
    coeff(2,1) = 1.2476206699696402e-11f;
    coeff(3,1) = 1.8157183655914677e-12f;
    coeff(4,1) = -5.563992289125963e-08f;
    coeff(5,1) = 0.00014785709208808839f;
    coeff(6,1) = -2.9542361517087556e-05f;
    coeff(7,1) = 0.67374217510223389f;

    coeff(0,2) = -5.9365555006574144e-12f;
    coeff(1,2) = -5.3369344533982233e-12f;
    coeff(2,2) = 8.4230270328000678e-12f;
    coeff(3,2) = 2.0841754971162585e-12f;
    coeff(4,2) = -4.1330167732667178e-08f;
    coeff(5,2) = 0.00010192402987740934f;
    coeff(6,2) = -3.5528690204955637e-05f;
    coeff(7,2) = 0.65378129482269287f;

    return coeff;
}

void ImageFiltersTest::illuminationCorrection()
{
    TEST_PRELUDE_RAW;
    const int samples = 10;

    auto map = m_imageFilter->illuminationCorrectionInit(input.size(), illuminationCoefficients());

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->illuminationCorrection({ input.size(), input.format(), input.bits() }, output.bits(), map);
    }

    TEST_FINALE("C:/temp/illuminationCorrection_ipp.png");
}

void ImageFiltersTest::keystoneCorrection()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    QTransform homography(1.0017250987536013,
                                    -0.12554803827773522,
                                    -184.15298590696472,
                                    0.0021158136477528646,
                                    0.9645927567446152,
                                    -334.48768852440429,
                                    1.3555052364720054e-06,
                                    -5.9370750047008174e-05);

    output = output.copy(0, 0, 4200, 2800);

    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };
    auto p = m_imageFilter->keystoneCorrectionInit(sourceImage, homography, output.rect() , image_filters::InterpolationType::Linear);

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->keystoneCorrection(sourceImage, output.bits(), p);
    }

    TEST_FINALE("C:/temp/keystoneCorrection_ipp.png");
}

void ImageFiltersTest::sharpen()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };
    auto p = m_imageFilter->sharpenInit(sourceImage);

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->sharpen(sourceImage, output.bits(), p);
    }

    TEST_FINALE("C:/temp/sharpen_ipp.png");
}

void ImageFiltersTest::crop()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    QRect destRect(0, 0, 1001, 1000);

    auto channelCount = QImage::toPixelFormat(sourceImage.format).bitsPerPixel() / 8;
    std::vector<uchar> buff (destRect.width() * destRect.height() * channelCount);

    // QImage adds stride so we need to force it to accept our stride
    output = QImage(buff.data(), destRect.width(), destRect.height(), destRect.width() * channelCount, input.format());

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->crop(sourceImage, output.bits(), destRect);
    }

    TEST_FINALE("C:/temp/crop_ipp.png");
}

void ImageFiltersTest::mirror()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->mirror(sourceImage, output.bits(), image_filters::MirrorType::Vertical);
    }

    TEST_FINALE("C:/temp/mirror_ipp.png");
}

void ImageFiltersTest::cropSameSize()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    QRect destRect(QPoint(), input.size());

    auto channelCount = QImage::toPixelFormat(sourceImage.format).bitsPerPixel() / 8;
    std::vector<uchar> buff (destRect.width() * destRect.height() * channelCount);

    // QImage adds stride so we need to force it to accept our stride
    output = QImage(buff.data(), destRect.width(), destRect.height(), destRect.width() * channelCount, input.format());

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->crop(sourceImage, output.bits(), destRect);
    }

    TEST_FINALE("C:/temp/cropSameSize_ipp.jpg");
}

void ImageFiltersTest::convertBGRtoRGB()
{
    // Note: This test works ONLY with 32-bit RGB images (aka raw data), it will not with JPEG/PNG without prior conversion!
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->convertBGRtoRGB(sourceImage, output.bits());
    }

    TEST_FINALE("C:/temp/convertBGRtoRGB_ipp.png");
}

void ImageFiltersTest::convertRGBtoRGBA()
{
    // Note: This test works ONLY with 32-bit RGB images (aka raw data), it will not with JPEG/PNG without prior conversion!
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    output = QImage(input.size(), QImage::Format_RGBA8888);

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->convertRGBtoRGBA(sourceImage, output.bits());
    }

    TEST_FINALE("C:/temp/convertBGRtoRGBA_ipp.png");
}

void ImageFiltersTest::resize()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    QRect destRect(0, 0, 800, 600);
    output = input.copy(destRect);

    auto data = m_imageFilter->resizeInit(sourceImage, destRect, image_filters::InterpolationType::Linear);

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->resize(sourceImage, output.bits(), data);
    }

    TEST_FINALE("C:/temp/resize_ipp.png");
}

void ImageFiltersTest::resizeSameSize()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    QRect destRect(QPoint(), input.size());
    output = input.copy(destRect);

    auto data = m_imageFilter->resizeInit(sourceImage, destRect, image_filters::InterpolationType::Linear);

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->resize(sourceImage, output.bits(), data);
    }

    TEST_FINALE("C:/temp/resizeSameSize_ipp.png");
}

void ImageFiltersTest::paste()
{
    TEST_PRELUDE_RAW;

    const int samples = 10;
    input = input.copy(0, 0, 1920, 1080);

    auto area = input.copy(0, 0, 756, 324);

    image_filters::SourceImage sourceImage { area.size(), area.format(), area.bits() };
    image_filters::SourceImage destinationImage { input.size(), input.format(), input.bits() };
    output = input;

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->paste(sourceImage, destinationImage, { 0, 756 });
    }

    TEST_FINALE("C:/temp/paste_ipp.png");
}

void ImageFiltersTest::colorCorrection()
{
    TEST_PRELUDE_RAW;
    const int samples = 10;

    auto map = m_imageFilter->colorCorrectionInit(input.size(), colorCoefficients());

    for (auto i=0; i < samples; i++)
    {
        m_imageFilter->colorCorrection({ input.size(), input.format(), input.bits() }, output.bits(), map);
    }

    TEST_FINALE("C:/temp/colorCorrection_ipp.png");
}

void ImageFiltersTest::documentationSamples()
{
    try {
        image_filters::ImageFilter imageFilter;

        QImage input(256, 256, QImage::Format_RGB888);

        // Make sure that image stride is same as this package requires
        Q_ASSERT(input.bytesPerLine() == input.width() * input.pixelFormat().bitsPerPixel() / 8);

        // Construct source image structure
        const image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

        // Define cropping rectangle
        const QRect croppingRectangle(64, 64, 128, 128);

        // Construct output image
        QImage output(croppingRectangle.size(), input.format());

        imageFilter.crop(sourceImage, output.bits(), croppingRectangle);
    }
    catch(image_filters::ImageFilterException & exception)  {
        qDebug() << exception.filterName() << exception.errorInfo();
    }

    try {
        image_filters::ImageFilter imageFilter;

        QImage input(256, 256, QImage::Format_RGB888);
        input.fill(QColor(255, 0, 0));

        QImage input2(256, 256, QImage::Format_RGB888);
        input2.fill(QColor(0, 255, 0));

        // Make sure that image stride is same as this package requires
        Q_ASSERT(input.bytesPerLine() == input.width() * input.pixelFormat().bitsPerPixel() / 8);
        Q_ASSERT(input2.bytesPerLine() == input2.width() * input2.pixelFormat().bitsPerPixel() / 8);

        // Construct source image structure
        image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

        // Define resize rectangle
        const QRect destinationRect(64, 64, 128, 128);
        const auto resizeData = imageFilter.resizeInit(sourceImage, destinationRect, image_filters::InterpolationType::Linear);

        // Construct output image
        QImage output(destinationRect.size(), input.format());

        imageFilter.resize(sourceImage, output.bits(), resizeData);

        // Since we are not changing image parameters like size or format we can reuse resizeData and just change the source data

        sourceImage.data = input2.bits();

        imageFilter.resize(sourceImage, output.bits(), resizeData);
    }
    catch(image_filters::ImageFilterException & exception)  {
        qDebug() << exception.filterName() << exception.errorInfo();
    }

}

#endif // not __clang_analyzer__

}
