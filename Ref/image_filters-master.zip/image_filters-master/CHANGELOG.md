# Change Log
  This is the Change log for Fortis updater, which is used to trace the project changes in chronologically order.

## [2.2.2] 2017-08-30

### Fixed
- Avoid throwing exceptions for OpenGL errors.

## [2.2.1] 2017-08-18

### Fixed

- Qt Metatype declaration is now in global namespace

## [2.2.0] 2017-08-18

### Added

- Adding interpolation option for OpenGL filters

## [2.1.1] 2017-08-01

### Fixed

- Sharpen + keystone correction resulted in cut off image size

## [2.1.0] 2017-07-25

### Added
- Mirroring to GPU filters

## [2.0.0] 2017-07-25

### Changed
- __BREAKING CHANGE__: Combined GPU filters now require active OpenGL context and accepts frame buffer as parameter.

## [1.2.0] 2017-07-18

### Added
- Adding combined filter to perform filters as single operation on GPU.

## [1.1.0] 2017-06-05

### Changed
- Using new IPP packages separated by domain with configurable deploy.
  - This requires FPM 1.7.4 or later.

## [1.0.4] 2017-04-21

### Changed
- Updating copyright information in headers.

## [1.0.3] 2017-04-19

### Changed
- Removed explicit dependency from Qt libraries in package.json.

## [1.0.2] - 2017-04-14

### Changing
- Rearranging include folder to match code style.

## [1.0.1] - 2017-04-14

### Changing
- Linting, code style and extended documentation.

## [1.0.0] - 2017-04-05

### Changing
- Promoting to major 1.

## [0.9.0] - 2017-03-10

### Adding
- Adding `mirror` filter.

## [0.8.1] - 2017-02-24

### Fixed
- Fixing `colorCorrection` filter.

## [0.8.0] - 2017-02-23

### Fixed
- Adding `colorCorrection` filter.

## [0.7.9] - 2017-02-14

### Fixed
- Sharpen filter doesn't copy borders which results into image fringes

## [0.7.8] - 2017-02-03

### Changed
- Performance optimizations for `resize`

## [0.7.7] - 2017-01-27

### Changed
- Adding new filter `convertRGBtoRGBA`

## [0.7.6] - 2017-01-19


### Changed
- Reverting back the version of OpenCV

## [0.7.5] - 2017-01-19

### Changed
- Using newer version of OpenCV

## [0.7.4] - 2017-01-19

### Changed
- Updating product information

## [0.7.3] - 2017-01-19

### Changed
- Updating copyright information

## [0.7.2] - 2016-12-21

### Changed

- Changing dependency to Opencv 3.1.0

## [0.7.1] - 2016-12-20

### Changed

- Throwing exceptions by reference

## [0.7.0] - 2016-12-16

### Changed

- Removing `Fortis` from namespace

## [0.6.1] - 2016-12-16

### Fixed

- Illumination correction

## [0.6.0] - 2016-12-16

### Changed

- Adding version to library file name
- Changing to PImpl facade

## [0.5.3] - 2016-12-08

### Fixed

- Crop & paste algorithm

## [0.5.2] - 2016-12-08

### Fixed

- Crop algorithm

## [0.5.1] - 2016-12-07

### Fixed

- Illumination correction algorithm

## [0.5.0] - 2016-12-05

### Added

- Resize filter
- Paste filter

### Changed

- Using smart pointers for filter data

## [0.4.0] - 2016-11-21

### Added

- Adding `convertBGRtoRGB` filter

## [0.3.0] - 2016-11-19

### Added

- Adding `crop` filter

## [0.2.0] - 2016-11-18

### Changed

- Adding destination rectangle as keystone correction parameter

## [0.1.0] - 2016-11-16

- Initial version
