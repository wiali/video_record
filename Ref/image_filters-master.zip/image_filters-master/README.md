# Image filters package

This package provides low-level image buffer filters operating directly on memory segments. Please see [documentation frontpage](./doc/mainpage.md) on additional information

