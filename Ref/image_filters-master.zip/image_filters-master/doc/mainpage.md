Image filters package is aimed to provide image filtering functions operating
directly on raw memory segments representing unpacked image data to provide
fastest possible operation. This package is aimed to be utilized in video processing and image processing
packages to achieve maximum performance. Internally this package uses [Intel
IPP](https://software.intel.com/en-us/intel-ipp) library for most of operations,
[OpenCV](http://opencv.org) or custom algorithms.

__Note:__ This package will throw image_filters::ImageFilterException in case of
invalid or unexpected data. It's callers responsiblity to catch and process the
exception to avoid crashing the application.

## Image definition

**The package currently supports only formats with 1 byte per image channel (e.g. RGBA32).**

Main purpose of this package is to provide operations on top of *unpacked* image
data - this means that all data representing image buffer should be be allocated
within single continous memory segment *without* any memory alignment. This means
that stride of the image (bytes per image row) always has to be

```math
image_stride = image_width * channel_count * bytes_per_channel
```

and total size of image buffer (in bytes) has to be:

```math
image_size = image_stride * image_height
```

This structure of image which is input parameter to all functions of this package is
represented by image_filters::SourceImage structure which defines image size,
image format and pointer to raw memory segment which has to fulfill rules mentioned above.

__Note:__ Please note that `QImage` by default can produce different strides for images
that doesn't align to memory segments. Always check if `QImage::bytesPerLine()` matches expected stride.
This is especially true when trying to convert output buffer to `QImage` so always pass stride to
`QImage` constructor.

__Note:__ All functions require caller to provide output image buffer of proper size where the output
image will be stored and caller is responsible for maintaining thread-safe operation in case
that filters are used from multiple threads.

## Image processing

Certain algorithms in this package are very straightforward (e.g. image_filters::ImageFilter::mirror)
and can operate efficiently without any additional pre-processing. In other cases
(e.g. image_filters::ImageFilter::resize) the speed of processing can be greatly increased
if the processed images are of similar properties (e.g. during processing of video frames
of same size and format).

In such cases this package provides initialization functions (e.g. image_filters::ImageFilter::resizeInit)
that pre-process as much data as possible to achieve best performance and output of initialization function
is passed to function that performs image filter.

__Note:__ It is callers responsibility to call initialization function whenever necessary
and make sure that processed image image properties matches properties that were used during initialization.

## Supported channels

Following filter formats and parameters are supported:

| Filter | Channel count | Initialization function |
| ------ | ------ | ------ |
| image_filters::ImageFilter::autoWhiteBalance | 3 or 4 | N/A |
| image_filters::ImageFilter::colorCorrection | 3 or 4 | image_filters::ImageFilter::colorCorrectionInit |
| image_filters::ImageFilter::convertBGRtoRGB | 3 | N/A |
| image_filters::ImageFilter::convertRGBtoRGBA | 3 | N/A |
| image_filters::ImageFilter::crop | 3 or 4 | N/A |
| image_filters::ImageFilter::illuminationCorrection | 3 or 4 | image_filters::ImageFilter::illuminationCorrectionInit |
| image_filters::ImageFilter::keystoneCorrection | 3 or 4 | image_filters::ImageFilter::keystoneCorrectionInit |
| image_filters::ImageFilter::mirror | 3 or 4 | N/A |
| image_filters::ImageFilter::paste | 3 or 4 | N/A |
| image_filters::ImageFilter::resize | 3 or 4 | image_filters::ImageFilter::resizeInit |
| image_filters::ImageFilter::sharpen | 3 or 4 | image_filters::ImageFilter::sharpenInit |

## Example

For filters that doesn't require initialization function (e.g. cropping):

```cpp

try {
    image_filters::ImageFilter imageFilter;

    QImage input(256, 256, QImage::Format_RGB888);

    // Make sure that image stride is same as this package requires
    Q_ASSERT(input.bytesPerLine() == input.width() * input.pixelFormat().bitsPerPixel() / 8);

    // Construct source image structure
    const image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    // Define cropping rectangle
    const QRect croppingRectangle(64, 64, 128, 128);

    // Construct output image
    QImage output(croppingRectangle.size(), input.format());

    imageFilter.crop(sourceImage, output.bits(), croppingRectangle);
}
catch(image_filters::ImageFilterException & exception)  {
    qDebug() << exception.filterName() << exception.errorInfo();
}

```

Filters that does require initialization (e.g. resize) extra step is necessary:

```cpp

try {
    image_filters::ImageFilter imageFilter;

    QImage input(256, 256, QImage::Format_RGB888);
    input.fill(QColor(255, 0, 0));

    QImage input2(256, 256, QImage::Format_RGB888);
    input2.fill(QColor(0, 255, 0));

    // Make sure that image stride is same as this package requires
    Q_ASSERT(input.bytesPerLine() == input.width() * input.pixelFormat().bitsPerPixel() / 8);
    Q_ASSERT(input2.bytesPerLine() == input2.width() * input2.pixelFormat().bitsPerPixel() / 8);

    // Construct source image structure
    image_filters::SourceImage sourceImage { input.size(), input.format(), input.bits() };

    // Define resize rectangle
    const QRect destinationRect(64, 64, 128, 128);
    const auto resizeData = imageFilter.resizeInit(sourceImage, destinationRect, image_filters::InterpolationType::Linear);

    // Construct output image
    QImage output(destinationRect.size(), input.format());

    imageFilter.resize(sourceImage, output.bits(), resizeData);

    // Since we are not changing image parameters like size or format we can reuse resizeData and just change the source data

    sourceImage.data = input2.bits();

    imageFilter.resize(sourceImage, output.bits(), resizeData);
}
catch(image_filters::ImageFilterException & exception)  {
    qDebug() << exception.filterName() << exception.errorInfo();
}

```
