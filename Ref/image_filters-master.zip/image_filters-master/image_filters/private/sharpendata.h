/*! \file sharpendata.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_SHARPENDATA_H_
#define IMAGE_FILTERS_PRIVATE_SHARPENDATA_H_

#include <ippi.h>

namespace image_filters {

/*!
 * \brief This structure contains internal information for sharpen algorithm.
 * \details This structure can be obtained by calling ImageFilter::sharpenInit method.
 */
struct SharpenData {
  /*!
   * \brief Source image step (stride).
   */
  int step;

  /*!
   * \brief Count of channels per pixel.
   */
  int channelCount;

  /*!
   * \brief Size of the source image.
   */
  IppiSize size;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_SHARPENDATA_H_
