/*! \file keystonecorrectiondata.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_KEYSTONECORRECTIONDATA_H_
#define IMAGE_FILTERS_PRIVATE_KEYSTONECORRECTIONDATA_H_

#include <ippi.h>

#include "image_filters/interpolationtype.h"

namespace image_filters {

/*!
 * \brief This structure contains internal information for keystoneCorrection algorithm.
 * \details This structure can be obtained by calling ImageFilter::keystoneCorrectionInit method.
 */
struct KeystoneCorrectionData {
  /*!
   * \brief Region of interest of source image.
   */
  IppiRect sourceRoi;

  /*!
   * \brief Region of interest of destination image.
   */
  IppiRect destinationRoi;

  /*!
   * \brief Step (stride) of source image.
   */
  int sourceStep;

  /*!
   * \brief Step (stride) of destination image.
   */
  int destinationStep;

  /*!
   * \brief Count of channels per pixel.
   */
  int channelCount;

  /*!
   * \brief Size of the source image.
   */
  IppiSize size;

  /*!
   * \brief Type of the interpolation.
   */
  InterpolationType type;

  /*!
   * \brief Perspective warp coefficients.
   */
  double coefficients[3][3];
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_KEYSTONECORRECTIONDATA_H_
