/*! \file sourceimage.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_COLORCORRECTIONDATA_H_
#define IMAGE_FILTERS_PRIVATE_COLORCORRECTIONDATA_H_

#include <QVector3D>

#include <vector>

namespace image_filters {

/*!
 * \brief This structure contains internal information for color correction algorithm.
 * \details This structure can be obtained by calling ImageFilter::colorCorrectionInit method.
 */
struct ColorCorrectionData {
  /*!
   * \brief Contains image rows for parallel processing.
   */
  std::vector<int> rows;

  /*!
   * \brief Contains pre-calculated color map for every image pixel and every channel.
   */
  std::vector<QVector3D> map;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_COLORCORRECTIONDATA_H_
