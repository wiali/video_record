/*! \file illuminationcorrectiondata.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_ILLUMINATIONCORRECTIONDATA_H_
#define IMAGE_FILTERS_PRIVATE_ILLUMINATIONCORRECTIONDATA_H_

#include <vector>

namespace image_filters {

/*!
 * \brief This structure contains internal information for illumination correction algorithm.
 * \details This structure can be obtained by calling ImageFilter::illuminationCorrectionInit
 * \details method.
 */
struct IlluminationCorrectionData {
  /*!
   * \brief Contains image rows for parallel processing.
   */
  std::vector<int> rows;

  /*!
   * \brief Contains pre-calculated illumination map for every image pixel.
   */
  std::vector<float> map;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_ILLUMINATIONCORRECTIONDATA_H_
