#ifndef IMAGE_FILTERS_COMBINED_FILTER_DATA_H_
#define IMAGE_FILTERS_COMBINED_FILTER_DATA_H_

#include <QSize>

/*#include "GL/glew.h"
#include "GL/wglew.h"
#include "GLFW/glfw3.h"*/

#include <QOpenGLVertexArrayObject>
#include <QOpenGLShaderProgram>
#include <QOpenGLTexture>
#include <QOpenGLContext>
#include <QOffscreenSurface>
#include <QOpenGLBuffer>
#include <QOpenGLFramebufferObject>
#include <QSharedPointer>

#include "interpolationtype.h"

namespace image_filters {

struct CombinedFilterData
{
    QScopedPointer<QOpenGLVertexArrayObject> vertexArrayObject;

    QSize imageSize;

    QSize keystoneCorrectedSize;

    QSharedPointer<QOpenGLShaderProgram> filtersProgram;

    QSharedPointer<QOpenGLShaderProgram> autoWhiteBalanceScaleProgram;

    QSharedPointer<QOpenGLShaderProgram> sharpenProgram;

    QSharedPointer<QOpenGLShaderProgram> mirrorProgram;

    GLuint renderBuffer;

    QSharedPointer<QOpenGLFramebufferObject> autoWhiteBalanceFrameBuffer;

    QMatrix3x3 textureMatrix;

    QMatrix3x3 invariantTextureMatrix;

    QMatrix4x4 projectionMatrix;

    GLfloat illuminationCoefficients[6];

    GLfloat colorCorrectionCoefficientsLampOn[24];

    GLfloat colorCorrectionCoefficientsLampOff[24];

    QSharedPointer<QOpenGLBuffer> vertexBuffer;

    QOpenGLTexture::PixelFormat pixelFormat;

    InterpolationType interpolationType;
};

}  // namespace image_filters

#endif // IMAGE_FILTERS_COMBINED_FILTER_DATA_H_
