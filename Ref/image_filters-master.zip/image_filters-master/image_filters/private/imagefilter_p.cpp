/*! \file imagefilter_p.cpp
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include <QElapsedTimer>
#include <QFile>
#include <QResource>
#include <QtConcurrent/QtConcurrentMap>
#include <QMatrix4x4>
#include <QOpenGLFunctions>
#include <QOpenGLTexture>
#include <QOpenGLFramebufferObjectFormat>

#include <algorithm>
#include <array>
#include <memory>

#include "image_filters/imagefilterexception.h"
#include "image_filters/private/imagefilter_p.h"

#include "opencv2/core.hpp"
#include "opencv2/imgproc.hpp"

#include "ippcore.h"

using namespace image_filters;
using namespace cv;

#define CHECK_OPENGL_ERROR(message, ...) \
{ \
    auto error = glGetError(); \
    if (error != GL_NO_ERROR) { \
    qCritical() << this << message << ":" << error; \
    return __VA_ARGS__; \
    } \
    }

static QHash<MirrorType, IppiAxis> MirrorToAxisTranslationTable{
    {MirrorType::Horizontal, ippAxsHorizontal},
    {MirrorType::Vertical, ippAxsVertical},
    {MirrorType::Both, ippAxsBoth}};

/***********************************************************************************/

ImageFilterPrivate::ImageFilterPrivate(QObject* parent)
    : QObject(parent) {
    ippInit();
}

/***********************************************************************************/

ImageFilterPrivate::~ImageFilterPrivate() {}

/***********************************************************************************/

int ImageFilterPrivate::getOpenCVType(QImage::Format format) {
    int cv_type = CV_8UC4;

    switch (format) {
    case QImage::Format_RGB888:
        cv_type = CV_8UC3;
        break;
    }

    return cv_type;
}

/***********************************************************************************/

QVector3D ImageFilterPrivate::getWhiteBalanceScale(const SourceImage& sourceImage) {
    auto imageType = getOpenCVType(sourceImage.format);
    cv::Mat sourceMat(sourceImage.size.height(), sourceImage.size.width(), imageType,
                      sourceImage.data);

    Vec3f pt, ptsum;
    float min;
    int sample_size = 0;

    // sample pixels to compute average color
    for (int i = 0; i < sourceMat.size().height; i += 20) {
        for (int j = 0; j < sourceMat.size().width; j += 20) {
            if (imageType == CV_8UC4) {
                auto const& rgba8 = sourceMat.at<Vec4b>(i, j);
                pt[0] = static_cast<float>(rgba8[0]) / 255.0f;
                pt[1] = static_cast<float>(rgba8[1]) / 255.0f;
                pt[2] = static_cast<float>(rgba8[2]) / 255.0f;
            } else if (imageType == CV_8UC3) {
                auto const& rgb8 = sourceMat.at<Vec3b>(i, j);
                pt[0] = static_cast<float>(rgb8[0]) / 255.0f;
                pt[1] = static_cast<float>(rgb8[1]) / 255.0f;
                pt[2] = static_cast<float>(rgb8[2]) / 255.0f;
            }

            if ((pt[0] + pt[1] + pt[2] > 0.2f) && (pt[0] < 1.0f) && (pt[1] < 1.0f) && (pt[2] < 1.0f)) {
                ptsum += pt;
                sample_size++;
            }
        }
    }

    float denom = sample_size;
    if (denom > 0.0f) ptsum /= denom;

    // find min color component
    if (ptsum[0] <= ptsum[1]) {
        if (ptsum[0] <= ptsum[2])
            min = ptsum[0];
        else
            min = ptsum[2];
    } else {
        if (ptsum[1] <= ptsum[2])
            min = ptsum[1];
        else
            min = ptsum[2];
    }

    QVector3D ptscale;

    // apply color balancing
    if ((min > 0.2f) && (sample_size > 200)) {
        ptscale[0] = static_cast<float>(min) / ptsum[0];
        ptscale[1] = static_cast<float>(min) / ptsum[1];
        ptscale[2] = static_cast<float>(min) / ptsum[2];
    } else {
        ptscale[0] = ptscale[1] = ptscale[2] = 1.0;  // do nothing
    }

    return ptscale;
}

/***********************************************************************************/

void ImageFilterPrivate::legacyAutoWhiteBalance(const SourceImage& sourceImage, uchar* outputData) {
    const auto imageType = getOpenCVType(sourceImage.format);

    cv::Mat sourceMat(sourceImage.size.height(), sourceImage.size.width(), imageType,
                      sourceImage.data);
    cv::Mat resultMat(sourceImage.size.height(), sourceImage.size.width(), imageType, outputData);

    auto ptscale = getWhiteBalanceScale(sourceImage);
    Vec4b rgba8;
    Vec3b rgb8;

    for (int i = 0; i < resultMat.size().height; i++) {
        for (int j = 0; j < resultMat.size().width; j++) {
            if (imageType == CV_8UC3) {
                rgb8 = sourceMat.at<Vec3b>(i, j);

                const auto scale0 = ptscale[0] * static_cast<float>(rgb8[0]);
                const auto scale1 = ptscale[1] * static_cast<float>(rgb8[1]);
                const auto scale2 = ptscale[2] * static_cast<float>(rgb8[2]);

                rgb8[0] = static_cast<uchar>(floor(scale0));
                rgb8[1] = static_cast<uchar>(floor(scale1));
                rgb8[2] = static_cast<uchar>(floor(scale2));

                resultMat.at<Vec3b>(i, j) = rgb8;
            } else if (imageType == CV_8UC4) {
                rgba8 = sourceMat.at<Vec4b>(i, j);

                const auto scale0 = ptscale[0] * static_cast<float>(rgb8[0]);
                const auto scale1 = ptscale[1] * static_cast<float>(rgb8[1]);
                const auto scale2 = ptscale[2] * static_cast<float>(rgb8[2]);

                rgb8[0] = static_cast<uchar>(floor(scale0));
                rgb8[1] = static_cast<uchar>(floor(scale1));
                rgb8[2] = static_cast<uchar>(floor(scale2));

                resultMat.at<Vec4b>(i, j) = rgba8;
            }
        }
    }
}

/***********************************************************************************/

int ImageFilterPrivate::getChannelCount(const SourceImage& sourceImage) {
    return QImage::toPixelFormat(sourceImage.format).bitsPerPixel() / 8;
}

/***********************************************************************************/

int ImageFilterPrivate::getIntelIppImageStep(const SourceImage& sourceImage) {
    return sourceImage.size.width() * getChannelCount(sourceImage);
}

/***********************************************************************************/

void ImageFilterPrivate::autoWhiteBalance(const SourceImage& sourceImage, uchar* outputData) {
    auto ptscale = getWhiteBalanceScale(sourceImage);
    const int channelCount = getChannelCount(sourceImage);

    QVector<int> rows(sourceImage.size.height());
    std::iota(rows.begin(), rows.end(), 0);

    QtConcurrent::blockingMap(
                rows.begin(), rows.end(), [ptscale, sourceImage, &outputData, channelCount](int i) {
        auto const rowStart = i * sourceImage.size.width();

        for (int j = 0; j < sourceImage.size.width(); j++) {
            auto const offset = (rowStart + j);
            auto const pixelOffset = channelCount * offset;

            const auto scale0 = ptscale[0] * static_cast<float>(sourceImage.data[pixelOffset + 0]);
            const auto scale1 = ptscale[1] * static_cast<float>(sourceImage.data[pixelOffset + 1]);
            const auto scale2 = ptscale[2] * static_cast<float>(sourceImage.data[pixelOffset + 2]);

            outputData[pixelOffset + 0] = static_cast<uchar>(floor(scale0));
            outputData[pixelOffset + 1] = static_cast<uchar>(floor(scale1));
            outputData[pixelOffset + 2] = static_cast<uchar>(floor(scale2));
        }
    });
}

/***********************************************************************************/

void ImageFilterPrivate::legacyIlluminationCorrection(const SourceImage& sourceImage,
                                                      uchar* outputData,
                                                      const QVarLengthArray<float, 6>& coeff) {
    cv::Mat sourceMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), sourceImage.data);
    cv::Mat resultMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), outputData);

    auto imageType = getOpenCVType(sourceImage.format);

    for (int i = 0; i < sourceMat.size().height; i++) {
        for (int j = 0; j < sourceMat.size().width; j++) {
            qreal val = static_cast<qreal>(coeff[0] * j * j * i + coeff[1] * j * i + coeff[2] * j * j + coeff[3] * j +
                    coeff[4] * i + coeff[5]);

            if (imageType == CV_8UC3) {
                auto rgb8 = sourceMat.at<Vec3b>(i, j);
                if (val > 0.0) {
                    auto frgb0 = static_cast<double>(rgb8[0]) * 1.05 / val;  // push background to saturation
                    auto frgb1 = static_cast<double>(rgb8[1]) * 1.05 / val;
                    auto frgb2 = static_cast<double>(rgb8[2]) * 1.05 / val;

                    rgb8[0] = (frgb0 < 255 ? static_cast<uchar>(frgb0) : 255);
                    rgb8[1] = (frgb1 < 255 ? static_cast<uchar>(frgb1) : 255);
                    rgb8[2] = (frgb2 < 255 ? static_cast<uchar>(frgb2) : 255);
                }
                resultMat.at<Vec3b>(i, j) = rgb8;
            } else if (imageType == CV_8UC4) {
                auto rgba8 = sourceMat.at<Vec4b>(i, j);
                if (val > 0.0) {
                    auto frgb0 = static_cast<double>(rgba8[0]) * 1.05 / val;  // push background to saturation
                    auto frgb1 = static_cast<double>(rgba8[1]) * 1.05 / val;
                    auto frgb2 = static_cast<double>(rgba8[2]) * 1.05 / val;
                    rgba8[0] = (frgb0 < 255 ? static_cast<uchar>(frgb0) : 255);
                    rgba8[1] = (frgb1 < 255 ? static_cast<uchar>(frgb1) : 255);
                    rgba8[2] = (frgb2 < 255 ? static_cast<uchar>(frgb2) : 255);
                }
                resultMat.at<Vec4b>(i, j) = rgba8;
            }
        }
    }
}

/***********************************************************************************/

std::shared_ptr<IlluminationCorrectionData> ImageFilterPrivate::illuminationCorrectionInit(
        const QSize& imageSize, QGenericMatrix<1, 6, float> illuminationCoefficients) {
    auto data = std::make_shared<IlluminationCorrectionData>();
    data->rows = std::vector<int>(static_cast<size_t>(imageSize.height()));
    std::iota(data->rows.begin(), data->rows.end(), 0);

    const auto mapSize = imageSize.height() * imageSize.width();
    data->map = std::vector<float>(static_cast<size_t>(mapSize));

    QtConcurrent::blockingMap(
                data->rows.begin(), data->rows.end(), [illuminationCoefficients, imageSize, data](int i) {
        auto const rowStart = i * imageSize.width();

        for (int j = 0; j < imageSize.width(); j++) {
            auto val = illuminationCoefficients(0, 0) * j * j * i +
                    illuminationCoefficients(1, 0) * j * i +
                    illuminationCoefficients(2, 0) * j * j + illuminationCoefficients(3, 0) * j +
                    illuminationCoefficients(4, 0) * i + illuminationCoefficients(5, 0);

            if (val > 0.0f) {
                val = 1.05f / val;  // push background to saturation
            }

            data->map[static_cast<size_t>(rowStart + j)] = val;
        }
    });

    return data;
}

/***********************************************************************************/

void ImageFilterPrivate::illuminationCorrection(
        const SourceImage& sourceImage, uchar* outputData,
        const std::shared_ptr<IlluminationCorrectionData>& data, bool performAutoWhiteBalance) {
    QVector3D whiteBalanceScale;

    if (performAutoWhiteBalance) {
        whiteBalanceScale = getWhiteBalanceScale(sourceImage);
    }

    const int channelCount = getChannelCount(sourceImage);

    QtConcurrent::blockingMap(
                data->rows.begin(), data->rows.end(), [whiteBalanceScale, performAutoWhiteBalance,
                sourceImage, &outputData, data, channelCount](int i) {
        float frgb[3];
        auto const rowStart = i * sourceImage.size.width();

        for (int j = 0; j < sourceImage.size.width(); j++) {
            auto const offset = (rowStart + j);
            auto const pixelOffset = channelCount * offset;
            auto const& val = data->map[static_cast<size_t>(offset)];

            if (val > 0.0f) {
                frgb[0] = static_cast<float>(sourceImage.data[pixelOffset + 0]) * val;
                frgb[1] = static_cast<float>(sourceImage.data[pixelOffset + 1]) * val;
                frgb[2] = static_cast<float>(sourceImage.data[pixelOffset + 2]) * val;

                if (performAutoWhiteBalance) {
                    frgb[0] = frgb[0] * whiteBalanceScale[0];
                    frgb[1] = frgb[1] * whiteBalanceScale[1];
                    frgb[2] = frgb[2] * whiteBalanceScale[2];
                }

                outputData[pixelOffset + 0] = (frgb[0] < 255 ? static_cast<uchar>(frgb[0]) : 255);
                outputData[pixelOffset + 1] = (frgb[1] < 255 ? static_cast<uchar>(frgb[1]) : 255);
                outputData[pixelOffset + 2] = (frgb[2] < 255 ? static_cast<uchar>(frgb[2]) : 255);

                if (channelCount == 4) {
                    outputData[pixelOffset + 3] = sourceImage.data[pixelOffset + 3];
                }
            }
        }
    });
}

/***********************************************************************************/

void ImageFilterPrivate::legacyKeystoneCorrection(const SourceImage& sourceImage, uchar* outputData,
                                                  QTransform transformation) {
    cv::Mat tMat(3, 3, CV_64F);

    tMat.at<double>(0, 0) = transformation.m11();
    tMat.at<double>(0, 1) = transformation.m12();
    tMat.at<double>(0, 2) = transformation.m13();
    tMat.at<double>(1, 0) = transformation.m21();
    tMat.at<double>(1, 1) = transformation.m22();
    tMat.at<double>(1, 2) = transformation.m23();
    tMat.at<double>(2, 0) = transformation.m31();
    tMat.at<double>(2, 1) = transformation.m32();
    tMat.at<double>(2, 2) = transformation.m33();

    cv::Mat sourceMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), sourceImage.data);
    cv::Mat resultMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), outputData);

    cv::warpPerspective(sourceMat, resultMat, tMat, resultMat.size(), INTER_NEAREST);
}

/***********************************************************************************/

std::shared_ptr<KeystoneCorrectionData> ImageFilterPrivate::keystoneCorrectionInit(
        const SourceImage& sourceImage, QTransform transformation, QRect destinationRect,
        InterpolationType type) {
    int numChannels = getChannelCount(sourceImage);

    auto data = std::make_shared<KeystoneCorrectionData>();
    data->sourceRoi = IppiRect{0, 0, sourceImage.size.width(), sourceImage.size.height()};
    data->destinationRoi = destinationRect.isEmpty()
            ? data->sourceRoi
            : IppiRect{destinationRect.left(), destinationRect.top(),
              destinationRect.width(), destinationRect.height()};
    data->sourceStep = data->sourceRoi.width * numChannels;
    data->destinationStep = data->destinationRoi.width * numChannels;

    data->channelCount = numChannels;
    data->size = IppiSize{sourceImage.size.width(), sourceImage.size.height()};
    ;
    data->type = type;

    data->coefficients[0][0] = transformation.m11();
    data->coefficients[0][1] = transformation.m12();
    data->coefficients[0][2] = transformation.m13();
    data->coefficients[1][0] = transformation.m21();
    data->coefficients[1][1] = transformation.m22();
    data->coefficients[1][2] = transformation.m23();
    data->coefficients[2][0] = transformation.m31();
    data->coefficients[2][1] = transformation.m32();
    data->coefficients[2][2] = transformation.m33();

    return data;
}

/***********************************************************************************/

void ImageFilterPrivate::keystoneCorrection(
        const SourceImage& sourceImage, uchar* outputData,
        std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionData) {
    IppStatus result = ippStsNoErr;

    if (keystoneCorrectionData->channelCount == 4) {
        result = ippiWarpPerspective_8u_C4R(
                    sourceImage.data, keystoneCorrectionData->size, keystoneCorrectionData->sourceStep,
                    keystoneCorrectionData->sourceRoi, outputData, keystoneCorrectionData->destinationStep,
                    keystoneCorrectionData->destinationRoi, keystoneCorrectionData->coefficients,
                    static_cast<int>(keystoneCorrectionData->type));
    } else if (keystoneCorrectionData->channelCount == 3) {
        result = ippiWarpPerspective_8u_C3R(
                    sourceImage.data, keystoneCorrectionData->size, keystoneCorrectionData->sourceStep,
                    keystoneCorrectionData->sourceRoi, outputData, keystoneCorrectionData->destinationStep,
                    keystoneCorrectionData->destinationRoi, keystoneCorrectionData->coefficients,
                    static_cast<int>(keystoneCorrectionData->type));
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("keystoneCorrection", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void ImageFilterPrivate::legacySharpen(const SourceImage& sourceImage, uchar* outputData) {
    const float amount = 0.5f;
    cv::Mat sourceMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), sourceImage.data);
    cv::Mat resultMat(sourceImage.size.height(), sourceImage.size.width(),
                      getOpenCVType(sourceImage.format), outputData);

    Mat labimg = Mat(sourceMat.size(), CV_8UC3);
    Mat limg = Mat(sourceMat.size(), CV_8UC1);
    Mat blurlimg = limg.clone();
    int from_to[] = {0, 0};
    float v1, v2, v3;

    if (sourceMat.depth() != CV_8U)  // only 8U is supported
    {
        resultMat = sourceMat.clone();  // do nothing
        return;
        // return INVALID_PIXEL_FORMAT error
    }

    cvtColor(sourceMat, labimg, CV_RGBA2BGR);
    cvtColor(labimg, labimg, CV_BGR2Lab);

    mixChannels(&labimg, 1, &limg, 1, from_to, 1);
    GaussianBlur(limg, blurlimg, Size(), 1.0);

    // limg = limg*(1 + amount) + blurlimg*(-amount);
    for (int i = 0; i < sourceMat.rows * sourceMat.cols; i++) {
        v1 = limg.at<uchar>(i) * (1 + amount);
        v2 = blurlimg.at<uchar>(i) * (-amount);
        v3 = v1 + v2;
        if (v3 < 0) v3 = 0.0;
        if (v3 > 255) v3 = 255.0;
        limg.at<uchar>(i) = static_cast<uchar>(v3);
    }
    mixChannels(&limg, 1, &labimg, 1, from_to, 1);

    cvtColor(labimg, labimg, CV_Lab2BGR);
    cvtColor(labimg, resultMat, CV_BGR2RGBA);
}

/***********************************************************************************/

std::shared_ptr<SharpenData> ImageFilterPrivate::sharpenInit(const SourceImage& sourceImage) {
    auto result = std::make_shared<SharpenData>();
    result->step = getIntelIppImageStep(sourceImage);
    result->channelCount = getChannelCount(sourceImage);

    /* The kernel size of sharping filter is3x3 so we need to start at (1,1) and end at (width - 1,
   * height -1) */
    result->size = IppiSize{sourceImage.size.width() - 2, sourceImage.size.height() - 2};

    return result;
}

/***********************************************************************************/

void ImageFilterPrivate::sharpen(const SourceImage& sourceImage, uchar* outputData,
                                 std::shared_ptr<SharpenData> sharpenData) {
    IppStatus result;

    /* The kernel size of sharping filter is3x3 so we need to start at (1,1) */
    const auto sourceStart = sourceImage.data + sharpenData->step + 1;
    auto outputStart = outputData + sharpenData->step + 1;

    // Copy borders to avoid fringes
    crop(sourceImage, outputData, QRect(QPoint(), sourceImage.size));

    if (sharpenData->channelCount == 4) {
        result = ippiFilterSharpen_8u_C4R(sourceStart, sharpenData->step, outputStart,
                                          sharpenData->step, sharpenData->size);
    } else if (sharpenData->channelCount == 3) {
        result = ippiFilterSharpen_8u_C3R(sourceStart, sharpenData->step, outputStart,
                                          sharpenData->step, sharpenData->size);
    } else {
        throw ImageFilterException("sharpen", "Only images with 3 or 4 channels are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("sharpen", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void ImageFilterPrivate::crop(const SourceImage& sourceImage, uchar* outputData,
                              QRect destinationRect) {
    const auto channelCount = getChannelCount(sourceImage);

    IppStatus result;

    const auto sourceStep = getIntelIppImageStep(sourceImage);
    const auto destinationStep = destinationRect.width() * channelCount;
    auto offset = sourceImage.data +
            (destinationRect.top() * sourceStep + destinationRect.left() * channelCount);

    if (channelCount == 3) {
        result = ippiCopy_8u_C3R(offset, sourceStep, outputData, destinationStep,
        {destinationRect.width(), destinationRect.height()});
    } else if (channelCount == 4) {
        result = ippiCopy_8u_C4R(offset, sourceStep, outputData, destinationStep,
        {destinationRect.width(), destinationRect.height()});
    } else {
        throw ImageFilterException("crop", "Only images with 3 or 4 channels are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("crop", ippGetStatusString(result));
    }
}

/***********************************************************************************/

std::shared_ptr<ResizeData> ImageFilterPrivate::resizeInit(const SourceImage& sourceImage,
                                                           QRect destinationRect,
                                                           InterpolationType type) {
    auto resizeData = std::make_shared<ResizeData>();

    resizeData->channelCount = getChannelCount(sourceImage);
    resizeData->destinationSize =
            IppiSize{destinationRect.size().width(), destinationRect.size().height()};

    if (sourceImage.size != destinationRect.size()) {
        resizeData->type = type;

        resizeData->sourceStep = getIntelIppImageStep(sourceImage);
        resizeData->destinationStep = destinationRect.size().width() * resizeData->channelCount;
        resizeData->offset = IppiPoint{destinationRect.left(), destinationRect.top()};

        const auto interpolation = static_cast<IppiInterpolationType>(type);

        IppiSize sourceSize = {sourceImage.size.width(), sourceImage.size.height()};

        int pSpecSize, pInitBufSize;

        auto result = ippiResizeGetSize_8u(sourceSize, resizeData->destinationSize, interpolation, 0,
                                           &pSpecSize, &pInitBufSize);

        if (result != ippStsNoErr) {
            throw ImageFilterException("resizeInit", ippGetStatusString(result));
        }

        resizeData->spec = reinterpret_cast<IppiResizeSpec_32f*>(ippsMalloc_8u(pSpecSize));

        switch (type) {
        case InterpolationType::Linear:
            result = ippiResizeLinearInit_8u(sourceSize, resizeData->destinationSize, resizeData->spec);
            resizeData->border = ippBorderRepl;
            break;
        case InterpolationType::Nearest:
            result =
                    ippiResizeNearestInit_8u(sourceSize, resizeData->destinationSize, resizeData->spec);
            break;
        default:
            throw ImageFilterException(
                        "resizeInit", QString("Unsupported resize type %1").arg(type).toStdString().c_str());
        }

        int bufferSize = 0;
        result = ippiResizeGetBufferSize_8u(resizeData->spec, resizeData->destinationSize,
                                            static_cast<Ipp32u>(resizeData->channelCount), &bufferSize);

        if (result != ippStsNoErr) {
            throw ImageFilterException("resizeInit", ippGetStatusString(result));
        }

        resizeData->buffer = ippsMalloc_8u(bufferSize);
    }

    return resizeData;
}

/***********************************************************************************/

void ImageFilterPrivate::resize(const SourceImage& sourceImage, uchar* outputData,
                                std::shared_ptr<ResizeData> data) {
    if (sourceImage.size.width() == data->destinationSize.width &&
            sourceImage.size.height() == data->destinationSize.height) {
        // No work needed, just copy data from one location to another. We can use IPP to perform copy,
        // it's faster ...
        crop(sourceImage, outputData, QRect(QPoint(), sourceImage.size));
    } else {
        IppStatus result = ippStsNoErr;

        if (data->channelCount == 4) {
            switch (data->type) {
            case InterpolationType::Linear:
                result = ippiResizeLinear_8u_C4R(
                            sourceImage.data, data->sourceStep, outputData, data->destinationStep, data->offset,
                            data->destinationSize, data->border, data->borderValue, data->spec, data->buffer);
                break;
            case InterpolationType::Nearest:
                result = ippiResizeNearest_8u_C4R(sourceImage.data, data->sourceStep, outputData,
                                                  data->destinationStep, data->offset,
                                                  data->destinationSize, data->spec, data->buffer);
                break;
            }
        } else if (data->channelCount == 3) {
            switch (data->type) {
            case InterpolationType::Linear:
                result = ippiResizeLinear_8u_C3R(
                            sourceImage.data, data->sourceStep, outputData, data->destinationStep, data->offset,
                            data->destinationSize, data->border, data->borderValue, data->spec, data->buffer);
                break;
            case InterpolationType::Nearest:
                result = ippiResizeNearest_8u_C3R(sourceImage.data, data->sourceStep, outputData,
                                                  data->destinationStep, data->offset,
                                                  data->destinationSize, data->spec, data->buffer);
                break;
            }
        }

        if (result != ippStsNoErr) {
            throw ImageFilterException("resize", ippGetStatusString(result));
        }
    }
}

/***********************************************************************************/

void ImageFilterPrivate::convertBGRtoRGB(const SourceImage& sourceImage, uchar* outputData) {
    IppStatus result;

    const auto channelCount = getChannelCount(sourceImage);
    const auto step = getIntelIppImageStep(sourceImage);
    const int dstOrder[] = {2, 1, 0};
    IppiSize destinationRoi = {sourceImage.size.width(), sourceImage.size.height()};

    if (channelCount == 3) {
        result =
                ippiSwapChannels_8u_C3R(sourceImage.data, step, outputData, step, destinationRoi, dstOrder);
    } else {
        throw ImageFilterException("convertBGRtoRGB", "Only 3 channels per pixel are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("convertBGRtoRGB", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void ImageFilterPrivate::paste(const SourceImage& sourceImage, const SourceImage& destinationImage,
                               QSize point) {
    IppStatus result;

    if (sourceImage.format != destinationImage.format) {
        throw ImageFilterException("paste", "Both images must be in same format");
    }

    const auto channelCount = getChannelCount(sourceImage);
    const auto sourceStep = getIntelIppImageStep(sourceImage);
    const auto destinationStep = getIntelIppImageStep(destinationImage);
    auto destination =
            destinationImage.data + (point.height() * destinationStep + point.width() * channelCount);

    if (channelCount == 3) {
        result = ippiCopy_8u_C3R(sourceImage.data, sourceStep, destination, destinationStep,
        {sourceImage.size.width(), sourceImage.size.height()});
    } else if (channelCount == 4) {
        result = ippiCopy_8u_C4R(sourceImage.data, sourceStep, destination, destinationStep,
        {sourceImage.size.width(), sourceImage.size.height()});
    } else {
        throw ImageFilterException("paste", "Only images with 3 or 4 channels are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("convertBGRtoRGB", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void ImageFilterPrivate::convertRGBtoRGBA(const SourceImage& sourceImage, uchar* outputData) {
    IppStatus result;

    const auto channelCount = getChannelCount(sourceImage);
    const auto step = getIntelIppImageStep(sourceImage);
    const auto dstStep = sourceImage.size.width() * 4;
    IppiSize destinationRoi = {sourceImage.size.width(), sourceImage.size.height()};

    if (channelCount == 3) {
        result = ippiCopy_8u_C3AC4R(sourceImage.data, step, outputData, dstStep, destinationRoi);
    } else {
        throw ImageFilterException("convertRGBtoRGBA", "Only 3 channels per pixel are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("convertRGBtoRGBA", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void ImageFilterPrivate::colorCorrection(const SourceImage& sourceImage, uchar* outputData,
                                         const std::shared_ptr<ColorCorrectionData>& data) {
    const int channelCount = getChannelCount(sourceImage);

    QtConcurrent::blockingMap(
                data->rows.begin(), data->rows.end(), [sourceImage, &outputData, data, channelCount](int i) {
        float frgb[3];
        auto const rowStart = i * sourceImage.size.width();

        for (int j = 0; j < sourceImage.size.width(); j++) {
            auto const offset = (rowStart + j);
            auto const pixelOffset = channelCount * offset;

            auto const& val = data->map[static_cast<size_t>(offset)];

            frgb[0] = sourceImage.data[pixelOffset + 0] * val.x();
            frgb[1] = sourceImage.data[pixelOffset + 1] * val.y();
            frgb[2] = sourceImage.data[pixelOffset + 2] * val.z();

            outputData[pixelOffset + 0] = frgb[0] > 255.0f ? 255 : static_cast<uchar>(frgb[0]);
            outputData[pixelOffset + 1] = frgb[1] > 255.0f ? 255 : static_cast<uchar>(frgb[1]);
            outputData[pixelOffset + 2] = frgb[2] > 255.0f ? 255 : static_cast<uchar>(frgb[2]);

            if (channelCount == 4) {
                outputData[pixelOffset + 3] = sourceImage.data[pixelOffset + 3];
            }
        }
    });
}

/***********************************************************************************/

float ImageFilterPrivate::calculateChannelColorCorrection(
        int i, int j, int channel, QGenericMatrix<3, 8, float> colorCoefficients) {
    return colorCoefficients(0, channel) * i * i * i + colorCoefficients(1, channel) * j * j * j +
            colorCoefficients(2, channel) * i * i * j + colorCoefficients(3, channel) * i * j * j +
            colorCoefficients(4, channel) * i * j + colorCoefficients(5, channel) * i +
            colorCoefficients(6, channel) * j + colorCoefficients(7, channel);
}

/***********************************************************************************/

std::shared_ptr<ColorCorrectionData> ImageFilterPrivate::colorCorrectionInit(
        const QSize& imageSize, QGenericMatrix<3, 8, float> colorCoefficients) {
    auto data = std::make_shared<ColorCorrectionData>();
    data->rows = std::vector<int>(static_cast<size_t>(imageSize.height()));
    std::iota(data->rows.begin(), data->rows.end(), 0);

    const auto mapSize = imageSize.height() * imageSize.width();
    data->map = std::vector<QVector3D>(static_cast<size_t>(mapSize));

    QtConcurrent::blockingMap(
                data->rows.begin(), data->rows.end(), [this, colorCoefficients, imageSize, data](int i) {
        auto const rowStart = i * imageSize.width();

        for (int j = 0; j < imageSize.width(); j++) {
            auto r = calculateChannelColorCorrection(j, i, 0, colorCoefficients);
            auto g = calculateChannelColorCorrection(j, i, 1, colorCoefficients);
            auto b = calculateChannelColorCorrection(j, i, 2, colorCoefficients);

            r = r > 0.0f ? 1.0f / r : 255.0f;
            g = g > 0.0f ? 1.0f / g : 255.0f;
            b = b > 0.0f ? 1.0f / b : 255.0f;

            data->map[static_cast<size_t>(rowStart + j)] = QVector3D(r, g, b);
        }
    });

    return data;
}

/***********************************************************************************/

void ImageFilterPrivate::mirror(const SourceImage& sourceImage, uchar* outputData,
                                const MirrorType type) {
    IppStatus result;
    const auto channelCount = getChannelCount(sourceImage);
    const auto step = getIntelIppImageStep(sourceImage);
    IppiSize destinationRoi = {sourceImage.size.width(), sourceImage.size.height()};

    if (channelCount == 3) {
        result = ippiMirror_8u_C3R(sourceImage.data, step, outputData, step, destinationRoi,
                                   MirrorToAxisTranslationTable[type]);
    } else if (channelCount == 4) {
        result = ippiMirror_8u_AC4R(sourceImage.data, step, outputData, step, destinationRoi,
                                    MirrorToAxisTranslationTable[type]);
    } else {
        throw ImageFilterException("mirror", "Only images with 3 or 4 channels are supported");
    }

    if (result != ippStsNoErr) {
        throw ImageFilterException("convertRGBtoRGBA", ippGetStatusString(result));
    }
}

/***********************************************************************************/

void glfwErrorCallback(int error, const char* description)
{
    qCritical() << "GLFW error:" << error << description;
}

/*****************************************************************************/

std::shared_ptr<CombinedFilterData> ImageFilterPrivate::combinedInit(const QSize& imageSize, const CombinedFilterSettings& settings) {
    auto data = std::make_shared<CombinedFilterData>();

    data->imageSize = imageSize;
    data->pixelFormat = settings.pixelFormat;

    data->filtersProgram = createAndCompileShaderProgram(":/shaders/filtersShader");
    data->autoWhiteBalanceScaleProgram = createAndCompileShaderProgram(":/shaders/autoWhiteBalanceScaleShader");
    data->sharpenProgram = createAndCompileShaderProgram(":/shaders/sharpenShader");
    data->mirrorProgram = createAndCompileShaderProgram(":/shaders/mirrorShader");

    buildVertexBuffer(data);

    QOpenGLFramebufferObjectFormat format;
    format.setInternalTextureFormat(QOpenGLTexture::RGB32F);
    data->autoWhiteBalanceFrameBuffer.reset(new QOpenGLFramebufferObject(QSize(1, 1), format));

    data->projectionMatrix.ortho(0, 1, 0, 1, -1, 1);

    for (int i = 0; i < 6; i++) {
        data->illuminationCoefficients[i] = settings.illuminationCoefficients(i, 0);
    }

    data->keystoneCorrectedSize = settings.keystoneCorrectedSize;
    const auto invertedHomography = settings.keystoneCorrectionTransformation.inverted();

    data->textureMatrix(0, 0) = static_cast<GLfloat>(invertedHomography.m11());
    data->textureMatrix(1, 0) = static_cast<GLfloat>(invertedHomography.m12());
    data->textureMatrix(2, 0) = static_cast<GLfloat>(invertedHomography.m13());
    data->textureMatrix(0, 1) = static_cast<GLfloat>(invertedHomography.m21());
    data->textureMatrix(1, 1) = static_cast<GLfloat>(invertedHomography.m22());
    data->textureMatrix(2, 1) = static_cast<GLfloat>(invertedHomography.m23());
    data->textureMatrix(0, 2) = static_cast<GLfloat>(invertedHomography.m31());
    data->textureMatrix(1, 2) = static_cast<GLfloat>(invertedHomography.m32());
    data->textureMatrix(2, 2) = static_cast<GLfloat>(invertedHomography.m33());

    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 8; j++) {
            auto offset = i * 8;
            data->colorCorrectionCoefficientsLampOn[offset + j] = settings.colorCorrectionLampOnCoefficients(j, i);
            data->colorCorrectionCoefficientsLampOff[offset + j] = settings.colorCorrectionLampOffCoefficients(j, i);
        }
    }

    return data;
}

/*****************************************************************************/

QSharedPointer<QOpenGLTexture> ImageFilterPrivate::createTexture(QSize size,
                                                                 InterpolationType interpolationType,
                                                                 QOpenGLTexture::TextureFormat format) {

    auto result = QSharedPointer<QOpenGLTexture>::create(QOpenGLTexture::Target2D);
    result->setSize(size.width(), size.height());
    result->setFormat(format);

    result->setMagnificationFilter(interpolationType == InterpolationType::Nearest ? QOpenGLTexture::Nearest : QOpenGLTexture::Linear);
    result->setMinificationFilter(interpolationType == InterpolationType::Nearest ? QOpenGLTexture::Nearest : QOpenGLTexture::Linear);

    if (!result->create())
        throw new std::exception("Failed to create texture");

    result->allocateStorage();

    return result;
}

/*****************************************************************************/

void ImageFilterPrivate::readAndCompileShaderFile(QOpenGLShader* shader, QString shaderFileName)
{
    QFile shaderFile(shaderFileName);
    if (!shaderFile.open(QIODevice::ReadOnly)) {
        throw new std::exception("Cannot open shader file");
    }

    if (!shader->compileSourceFile(shaderFileName))
    {
        qCritical() << this << "Failed to compile shader" << shaderFileName << "with following error:";
        qCritical() << this << shader->log();
        throw new std::exception(shader->log().toStdString().c_str());
    }
    else
    {
        qDebug() << this << "Shader" << shaderFileName << "compiled succesfully";
    }
}

/*****************************************************************************/

QSharedPointer<QOpenGLShaderProgram> ImageFilterPrivate::createAndCompileShaderProgram(QString programName)
{
    QSharedPointer<QOpenGLShaderProgram> result(new QOpenGLShaderProgram);

    QOpenGLShader *vertexShader = new QOpenGLShader(QOpenGLShader::Vertex, result.data());
    readAndCompileShaderFile(vertexShader, programName + ".vert");

    QOpenGLShader *fragmentShader = new QOpenGLShader(QOpenGLShader::Fragment, result.data());
    readAndCompileShaderFile(fragmentShader, programName + ".frag");

    result->addShader(vertexShader);
    result->addShader(fragmentShader);

    if (!result->link()) {
        throw std::exception("Failed to link shader program");
    }

    qDebug() << this << "Shader program" << programName << "linked succesfully";

    return result;
}

/*****************************************************************************/

void ImageFilterPrivate::buildVertexBuffer(std::shared_ptr<CombinedFilterData> data) {
    static const float coords[12] = { 0, 0, 0 ,
                                      1, 0, 0,
                                      1, 1, 0 ,
                                      0, 1, 0  };

    data->vertexArrayObject.reset(new QOpenGLVertexArrayObject);
    data->vertexArrayObject->bind();

    data->vertexBuffer = QSharedPointer<QOpenGLBuffer>::create(QOpenGLBuffer::VertexBuffer);
    data->vertexBuffer->create();
    data->vertexBuffer->bind();
    data->vertexBuffer->setUsagePattern(QOpenGLBuffer::StaticDraw);
    data->vertexBuffer->allocate(coords, 12 * sizeof(float));

    data->filtersProgram->setAttributeBuffer(0, GL_FLOAT, 0, 3);
    data->filtersProgram->enableAttributeArray(0);

    data->vertexArrayObject->release();
}

/*****************************************************************************/

void ImageFilterPrivate::combined(const SourceImage& sourceImage,
                                  QOpenGLFramebufferObject *frameBuffer,
                                  const std::shared_ptr<CombinedFilterData> &data,
                                  ImageFilter::CombinedFilters filters,
                                  ImageFilter::ColorCorrectionMode colorCorrectionMode,
                                  MirrorType mirror) {
    const auto functions = QOpenGLContext::currentContext()->functions();

    GLint viewport[4];

    functions->glGetIntegerv(GL_VIEWPORT, viewport);
    functions->glViewport(0, 0, sourceImage.size.width(), sourceImage.size.height());

    QOpenGLFramebufferObject *finalFrameBuffer = frameBuffer;
    QScopedPointer<QOpenGLFramebufferObject> mirrorFrameBuffer;

    const auto finalImageSize = filters.testFlag(ImageFilter::CombinedFilter::KeystoneCorrection) ? data->keystoneCorrectedSize : sourceImage.size;

    if (filters.testFlag(ImageFilter::CombinedFilter::Mirror)) {
        mirrorFrameBuffer.reset(new QOpenGLFramebufferObject(finalImageSize));
        finalFrameBuffer = mirrorFrameBuffer.data();
    }

    if (filters.testFlag(ImageFilter::CombinedFilter::Sharpen)) {        
        QPointF onePixel(1.0 / finalImageSize.width(), 1.0 / finalImageSize.height());
        QOpenGLFramebufferObject temporaryFrameBuffer(sourceImage.size);

        runCorrectionFiltersProgram(&temporaryFrameBuffer, data, filters, colorCorrectionMode, sourceImage.data);
        runSharpenProgram(&temporaryFrameBuffer, finalFrameBuffer, data, onePixel);
    } else {
        runCorrectionFiltersProgram(finalFrameBuffer, data, filters, colorCorrectionMode, sourceImage.data);
    }

    if (filters.testFlag(ImageFilter::CombinedFilter::Mirror)) {
        runMirrorProgram(finalFrameBuffer, data, frameBuffer, mirror);
    }

    data->vertexArrayObject->release();
    frameBuffer->release();

    functions->glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
}

/***********************************************************************************/

void ImageFilterPrivate::runMirrorProgram(QOpenGLFramebufferObject *sourceFrameBuffer,
                                          const std::shared_ptr<CombinedFilterData> &data, QOpenGLFramebufferObject *targetFrameBuffer,
                                          MirrorType mirrorType) {
    const auto functions = QOpenGLContext::currentContext()->functions();

    glBindTexture(GL_TEXTURE_2D, sourceFrameBuffer->texture());
    CHECK_OPENGL_ERROR("Failed to bind input texture");

    targetFrameBuffer->bind();

    functions->glClear(GL_COLOR_BUFFER_BIT);

    data->mirrorProgram->bind();
    data->mirrorProgram->setUniformValue("projectionMatrix", data->projectionMatrix);
    data->mirrorProgram->setUniformValue("tex", 0);
    data->mirrorProgram->setUniformValue("flipVertical", mirrorType == MirrorType::Vertical || mirrorType == MirrorType::Both);
    data->mirrorProgram->setUniformValue("flipHorizontal", mirrorType == MirrorType::Horizontal || mirrorType == MirrorType::Both);

    data->vertexArrayObject->bind();
    functions->glDrawArrays(GL_QUADS, 0, 4);
    functions->glFlush();
}

/***********************************************************************************/

void ImageFilterPrivate::runCorrectionFiltersProgram(QOpenGLFramebufferObject *frameBuffer,
                                                     const std::shared_ptr<CombinedFilterData> &data,
                                                     ImageFilter::CombinedFilters filters,
                                                     ImageFilter::ColorCorrectionMode colorCorrectionMode,
                                                     const void * inputBuffer) {
    const auto functions = QOpenGLContext::currentContext()->functions();

    auto inputTexture = createTexture(data->imageSize, data->interpolationType);
    auto colorCorrectionCoefficients = colorCorrectionMode == ImageFilter::ColorCorrectionMode::LampOff ?
                data->colorCorrectionCoefficientsLampOff : data->colorCorrectionCoefficientsLampOn;

    auto const imageSize = data->imageSize;

    inputTexture->setData(data->pixelFormat, QOpenGLTexture::UInt8, inputBuffer);

    auto autoWhiteBalanceScale = runAutoWhiteBalanceScaleProgram(data, filters, inputTexture);

    frameBuffer->bind();
    inputTexture->bind();

    const auto textureMatrix = filters.testFlag(ImageFilter::CombinedFilter::KeystoneCorrection) ?
                data->textureMatrix : data->invariantTextureMatrix;

    data->filtersProgram->bind();
    data->filtersProgram->setUniformValue("projectionMatrix", data->projectionMatrix);
    data->filtersProgram->setUniformValue("textureMatrix", textureMatrix);
    data->filtersProgram->setUniformValue("imageSize", QVector2D(imageSize.width(), imageSize.height()));
    data->filtersProgram->setUniformValue("tex", 0);
    data->filtersProgram->setUniformValue("autoWhiteBalanceScale", autoWhiteBalanceScale);
    data->filtersProgram->setUniformValueArray("illuminationCoefficients", data->illuminationCoefficients, 6, 1);
    data->filtersProgram->setUniformValue("useIlluminationCorrection", filters.testFlag(ImageFilter::CombinedFilter::IlluminationCorrection));
    data->filtersProgram->setUniformValue("useColorCorrection", filters.testFlag(ImageFilter::CombinedFilter::ColorCorrection));
    data->filtersProgram->setUniformValueArray("colorCorrectionCoefficients", colorCorrectionCoefficients, 24, 1);

    data->vertexArrayObject->bind();
    functions->glDrawArrays(GL_QUADS, 0, 4);
    functions->glFlush();
}

/***********************************************************************************/

QVector3D ImageFilterPrivate::runAutoWhiteBalanceScaleProgram(const std::shared_ptr<CombinedFilterData> &data,
                                                              ImageFilter::CombinedFilters filters,
                                                              QSharedPointer<QOpenGLTexture> inputTexture) {
    QVector3D autoWhiteBalanceScale(1.0f, 1.0f, 1.0f);

    if (filters.testFlag(ImageFilter::CombinedFilter::AutoWhiteBalance)) {
        const auto functions = QOpenGLContext::currentContext()->functions();
        inputTexture->bind();

        data->autoWhiteBalanceFrameBuffer->bind();

        functions->glClear(GL_COLOR_BUFFER_BIT);

        data->autoWhiteBalanceScaleProgram->bind();
        data->autoWhiteBalanceScaleProgram->setUniformValue("projectionMatrix", data->projectionMatrix);
        data->autoWhiteBalanceScaleProgram->setUniformValue("tex", 0);

        data->vertexArrayObject->bind();
        functions->glDrawArrays(GL_QUADS, 0, 4);
        functions->glFlush();

        GLfloat result[3];

        // QImage doesn't support floating points so we read it out directly
        glReadPixels(0, 0, 1, 1, GL_RGB, GL_FLOAT, &result);
        CHECK_OPENGL_ERROR("Failed to read pixels", autoWhiteBalanceScale);

        autoWhiteBalanceScale = QVector3D(result[0], result[1], result[2]);

        data->autoWhiteBalanceFrameBuffer->release();
        data->autoWhiteBalanceScaleProgram->release();
    }

    return autoWhiteBalanceScale;
}

/***********************************************************************************/

void ImageFilterPrivate::runSharpenProgram(QOpenGLFramebufferObject *sourceFrameBuffer, QOpenGLFramebufferObject *targetFrameBuffer,
                                           const std::shared_ptr<CombinedFilterData> &data, QPointF onePixel) {
    const auto functions = QOpenGLContext::currentContext()->functions();

    glBindTexture(GL_TEXTURE_2D, sourceFrameBuffer->texture());
    CHECK_OPENGL_ERROR("Failed to bind input texture");

    GLfloat sharpenOffsets[9 * 2];

    sharpenOffsets[ 0] = static_cast<GLfloat>(-onePixel.x()); sharpenOffsets[ 1] = static_cast<GLfloat>(-onePixel.y());
    sharpenOffsets[ 2] = static_cast<GLfloat>(0);             sharpenOffsets[ 3] = static_cast<GLfloat>(-onePixel.y());
    sharpenOffsets[ 4] = static_cast<GLfloat>(onePixel.x());  sharpenOffsets[ 5] = static_cast<GLfloat>(-onePixel.y());

    sharpenOffsets[ 6] = static_cast<GLfloat>(-onePixel.x()); sharpenOffsets[ 7] = static_cast<GLfloat>(0);
    sharpenOffsets[ 8] = static_cast<GLfloat>(0);             sharpenOffsets[ 9] = static_cast<GLfloat>(0);
    sharpenOffsets[10] = static_cast<GLfloat>(onePixel.x());  sharpenOffsets[11] = static_cast<GLfloat>(0);

    sharpenOffsets[12] = static_cast<GLfloat>(-onePixel.x()); sharpenOffsets[13] =  static_cast<GLfloat>(onePixel.y());
    sharpenOffsets[14] = static_cast<GLfloat>(0);             sharpenOffsets[15] =  static_cast<GLfloat>(onePixel.y());
    sharpenOffsets[16] = static_cast<GLfloat>(onePixel.x());  sharpenOffsets[17] =  static_cast<GLfloat>(onePixel.y());

    targetFrameBuffer->bind();

    functions->glClear(GL_COLOR_BUFFER_BIT);

    data->sharpenProgram->bind();
    data->sharpenProgram->setUniformValue("projectionMatrix", data->projectionMatrix);
    data->sharpenProgram->setUniformValue("tex", 0);
    data->sharpenProgram->setUniformValueArray("offsets", sharpenOffsets, 9, 2);

    data->vertexArrayObject->bind();
    functions->glDrawArrays(GL_QUADS, 0, 4);
    functions->glFlush();
}
