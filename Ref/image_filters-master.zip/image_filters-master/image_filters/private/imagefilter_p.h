/*! \file imagefilter_p.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_IMAGEFILTER_P_H_
#define IMAGE_FILTERS_PRIVATE_IMAGEFILTER_P_H_

#include <QGenericMatrix>
#include <QPointer>
#include <QVector3D>
#include <QMutex>
#include <QOpenGLContext>
#include <QOffscreenSurface>
#include <QOpenGLTexture>

#include <memory>

#include "image_filters/imagefilter.h"
#include "image_filters/interpolationtype.h"
#include "image_filters/sourceimage.h"

#include "image_filters/private/colorcorrectiondata.h"
#include "image_filters/private/illuminationcorrectiondata.h"
#include "image_filters/private/keystonecorrectiondata.h"
#include "image_filters/private/resizedata.h"
#include "image_filters/private/sharpendata.h"
#include "image_filters/private/combinedfilterdata.h"

namespace image_filters {

/*!
 * \brief The ImageFilter class wraps various image filters from providers like OpenCL or Intel IPP.
 * \details This class should be treated as normal Qt class which means that it can and will throw
 * \details QExceptions if any operation fails!
 */
class ImageFilterPrivate : public QObject {
  Q_OBJECT

 public:
    /*!
     * \brief Default ImageFilter constructor.
     * \param parent Pointer to parent object.
     */
  explicit ImageFilterPrivate(QObject* parent = nullptr);

  /*!
    * \brief ImageFilter destructor.
    */
  ~ImageFilterPrivate();

  /*!
   * \brief Performs auto white balance using legacy OpenCV execution on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   */
  void legacyAutoWhiteBalance(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs auto white balance using parallelized execution on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   */
  void autoWhiteBalance(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs illumination correction using legacy OpenCV algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param coeff Illumination correction coefficients.
   */
  void legacyIlluminationCorrection(const SourceImage& sourceImage, uchar* outputData,
                                    const QVarLengthArray<float, 6>& coeff);

  /*!
   * \brief Performs illumination correction using parallelized algorithm on provided source image
   * \details with precalculated illumnination map.
   * \details Optionally caller can also request to perform auto white balance algoritm in same pass
   * \details to achieve better performance.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param illuminationCorrectionData Pointer to illumination correction data structure obtained
   * \details using illuminationCorrectionInit.
   * \param performAutoWhiteBalance Flag indicating if auto white balance should be performed as
   * \details well.
   * \sa illuminationCorrectionInit
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void illuminationCorrection(
      const SourceImage& sourceImage, uchar* outputData,
      const std::shared_ptr<IlluminationCorrectionData>& illuminationCorrectionData,
      bool performAutoWhiteBalance = false);

  /*!
   * \brief Initializes internal data for illumination correction algorithm.
   * \param imageSize Size of the image
   * \param illuminationCoefficients Illumination correction coefficients.
   * \return Pointer to illumination correction data.
   * \sa illuminationCorrection
   */
  std::shared_ptr<IlluminationCorrectionData> illuminationCorrectionInit(
      const QSize& imageSize, QGenericMatrix<1, 6, float> illuminationCoefficients);

  /*!
   * \brief Performs keystone correction using legacy OpenCV algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param transformation Homography data.
   */
  void legacyKeystoneCorrection(const SourceImage& sourceImage, uchar* outputData,
                                QTransform transformation);

  /*!
   * \brief Initializes internal data for keystone correction algorithm.
   * \param sourceImage Reference to source image data
   * \param transformation Homography data.
   * \param destinationRect Destination image rectangle.
   * \param type Interpolation type.
   * \return Pointer to keystone correction data.
   */
  std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionInit(const SourceImage& sourceImage,
                                                                 QTransform transformation,
                                                                 QRect destinationRect,
                                                                 InterpolationType type);

  /*!
   * \brief Performs keystone correction using Intel IPP algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param keystoneCorrectionData Pointer to keystone correction algorithm data obtained using
   * keystoneCorrectionInit.
   */
  void keystoneCorrection(const SourceImage& sourceImage, uchar* outputData,
                          std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionData);

  /*!
   * \brief Performs sharpening using legacy OpenCV algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   */
  void legacySharpen(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs sharpening using Intel IPP algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param sharpenData Pointer to sharpen algorithm data obtained using sharpenInit.
   */
  void sharpen(const SourceImage& sourceImage, uchar* outputData,
               std::shared_ptr<SharpenData> sharpenData);

  /*!
   * \brief Initializes internal data for sharpen algorithm.
   * \param sourceImage Reference to source image data.
   * \return Pointer to sharpen data.
   */
  std::shared_ptr<SharpenData> sharpenInit(const SourceImage& sourceImage);

  /*!
   * \brief Crops the source image to rectangle provided as parameter.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \param destinationRect Cropping area.
   */
  void crop(const SourceImage& sourceImage, uchar* outputData, QRect destinationRect);

  /*!
   * \brief Initializes internal data for resize algorithm.
   * \param sourceImage sourceImage Reference to source image data.
   * \param destinationRect Destination image rectangle.
   * \param type Interpolation type.
   * \return Pointer to resize data.
   */
  std::shared_ptr<ResizeData> resizeInit(const SourceImage& sourceImage, QRect destinationRect,
                                         InterpolationType type);

  /*!
   * \brief Resizes the source image to rectangle provided as parameter.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \param data Pointer to resize data obtained by usign method resizeInit.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void resize(const SourceImage& sourceImage, uchar* outputData, std::shared_ptr<ResizeData> data);

  /*!
   * \brief Copies source image to destination position provided as parameter.
   * \param sourceImage Reference to source image data.
   * \param destinationImage Reference to destination image data.
   * \param destination Target point.
   */
  void paste(const SourceImage& sourceImage, const SourceImage& destinationImage,
             QSize destination);

  /*!
   * \brief Returns channel count for given source image.
   * \param sourceImage Reference to source image data.
   * \return Channel count.
   */
  static int getChannelCount(const SourceImage& sourceImage);

  /*!
   * \brief Converts image color space from BGR to RGB layout.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void convertBGRtoRGB(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Expands color space from RGB to RGBA layout.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void convertRGBtoRGBA(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs color correction using parallelized algorithm on provided source image with
   * \details precalculated color map.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param colorCorrectionData Pointer to illumination correction data structure obtained using
   * \details colorCorrectionInit.
   * \sa colorCorrectionInit
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void colorCorrection(const SourceImage& sourceImage, uchar* outputData,
                       const std::shared_ptr<ColorCorrectionData>& colorCorrectionData);

  /*!
   * \brief Initializes internal data for color correction algorithm.
   * \param imageSize Size of the image
   * \param colorCoefficients Color correction coefficients.
   * \return Pointer to color correction data.
   * \sa colorCorrection
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<ColorCorrectionData> colorCorrectionInit(
      const QSize& imageSize, QGenericMatrix<3, 8, float> colorCoefficients);

  /*!
   * \brief Performs image mirroring based on given axis.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param type Type of mirroring to perform.
   */
  void mirror(const SourceImage& sourceImage, uchar* outputData, const MirrorType type);

  /*!
   * \brief Initializes internal data for combined filters.
   * \param imageSize Size of the image
   * \param settings Pointer to combined filter settings.
   */
  std::shared_ptr<CombinedFilterData> combinedInit(const QSize &imageSize, const CombinedFilterSettings& settings);

  /*!
   * \brief Performs all filters flagged for execution
   * \param sourceImage Reference to source image data
   * \param frameBuffer Pointer to output frame buffer.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   * \param filters Declares which filters should be executed.
   * \param colorCorrectionMode Indicates which set of color correction coefficients should be used.
   */
  void combined(const SourceImage& sourceImage, QOpenGLFramebufferObject *frameBuffer,
                const std::shared_ptr<CombinedFilterData> &data, ImageFilter::CombinedFilters filters,
                ImageFilter::ColorCorrectionMode colorCorrectionMode, MirrorType mirror);

 protected:
  /*!
   * \brief Pre-calculates color correction factor for given position and channel.
   * \param i X-axis coordinate.
   * \param j Y-axis coordinate.
   * \param channel Color channel index.
   * \param colorCoefficients Color correction coefficients.
   * \return
   */
  inline float calculateChannelColorCorrection(int i, int j, int channel,
                                               QGenericMatrix<3, 8, float> colorCoefficients);

  /*!
   * \brief Returns image step value for Intel IPP algorithms.
   * \param sourceImage Reference to source image data.
   * \return Image step value.
   */
  int getIntelIppImageStep(const SourceImage& sourceImage);

  /*!
   * \brief Calculates white balance scale for given image.
   * \param sourceImage Reference to source image data.
   * \return White balance scale.
   */
  QVector3D getWhiteBalanceScale(const SourceImage& sourceImage);

  /*!
   * \brief Converts QImage format into OpenCV image format.
   * \param format QImage format.
   * \return OpenCV image format.
   */
  int getOpenCVType(QImage::Format format);

  /*!
   * \brief Initializes OpenGL subsystem.
   */
  void initializeOpenGL();

  /*!
   * \brief Builds vertex buffer for combined filter.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   */
  void buildVertexBuffer(std::shared_ptr<CombinedFilterData> data);

  /*!
   * \brief Creates OpenGL RGB texture with given data type.
   * \param size Size of the texture.
   * \param type Data type of color channel.
   */
  QSharedPointer<QOpenGLTexture> createTexture(QSize size, InterpolationType interpolationType, QOpenGLTexture::TextureFormat format = QOpenGLTexture::RGB8_UNorm);

  /*!
   * \brief Creates shader and compiles fragment and vertex programs.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   * \param programName File name of the shader programs.
   * \return
   */
  QSharedPointer<QOpenGLShaderProgram> createAndCompileShaderProgram(QString programName);

  /*!
   * \brief Reads shader program from resource and compiles it.
   * \param shader OpenGL Shader ID
   * \param shaderFileName File name in resources.
   */
  void readAndCompileShaderFile(QOpenGLShader *shader, QString shaderFileName);

  /*!
   * \brief Runs shader program to find out auto white balance scale for given texture.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   * \param filters Declares which filters should be executed.
   * \param inputTexture OpenGL texture ID which will be used as source of pixels.
   */
  QVector3D runAutoWhiteBalanceScaleProgram(const std::shared_ptr<CombinedFilterData> &data, ImageFilter::CombinedFilters filters, QSharedPointer<QOpenGLTexture> inputTexture);

  /*!
   * \brief Runs shader sharpen algorithm.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   */
  void runSharpenProgram(QOpenGLFramebufferObject *sourceFrameBuffer, QOpenGLFramebufferObject *targetFrameBuffer,
                         const std::shared_ptr<CombinedFilterData> &data, QPointF onePixel);

  /*!
   * \brief Runs shader mirror algorithm.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   */
  void runMirrorProgram(QOpenGLFramebufferObject *sourceFrameBuffer, const std::shared_ptr<CombinedFilterData> &data,
                        QOpenGLFramebufferObject *targetFrameBuffer, MirrorType mirrorType);

  /*!
   * \brief Runs shader to execute correction algorithms (color, illumination and keystone corrections)
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   * \param filters Declares which filters should be executed.
   * \param colorCorrectionMode Indicates which set of color correction coefficients should be used.
   * \param inputBuffer Pointer to data that will be used as source of pixels.
   */
  void runCorrectionFiltersProgram(QOpenGLFramebufferObject *targetFrameBuffer, const std::shared_ptr<CombinedFilterData> &data,
                                     ImageFilter::CombinedFilters filters,
                                     ImageFilter::ColorCorrectionMode colorCorrectionMode, const void * inputBuffer);
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_IMAGEFILTER_P_H_
