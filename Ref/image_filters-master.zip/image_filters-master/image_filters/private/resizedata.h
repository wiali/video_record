/*! \file resizedata.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_PRIVATE_RESIZEDATA_H_
#define IMAGE_FILTERS_PRIVATE_RESIZEDATA_H_

#include <ipps.h>
#include <ippi.h>

#include "image_filters//interpolationtype.h"

namespace image_filters {

/*!
 * \brief This structure contains internal information for resizeing algorithm.
 * \details This structure can be obtained by calling ImageFilter::resizeInit method.
 */
struct ResizeData {
  ResizeData() : borderValue(nullptr), spec(nullptr), buffer(nullptr) {}

  ~ResizeData() {
    ippsFree(spec);
    ippsFree(buffer);
    ippsFree(borderValue);

    spec = nullptr;
    buffer = nullptr;
    borderValue = nullptr;
  }

  /*!
   * \brief Type of the border copy operation.
   */
  IppiBorderType border;

  /*!
   * \brief Border copy operation coefficients.
   */
  Ipp8u* borderValue;

  /*!
   * \brief Step (stride) of source image.
   */
  int sourceStep;

  /*!
   * \brief Step (stride) of destination image.
   */
  int destinationStep;

  /*!
   * \brief Count of channels per pixel.
   */
  int channelCount;

  /*!
   * \brief Size of the destination image.
   */
  IppiSize destinationSize;

  /*!
   * \brief Offset where to start resize operation.
   */
  IppiPoint offset;

  /*!
   * \brief Internal Intel IPP specification values.
   */
  IppiResizeSpec_32f* spec;

  /*!
   * \brief Internal Intel IPP algorithm buffer.
   */
  Ipp8u* buffer;

  /*!
   * \brief Type of the interpolation.
   */
  InterpolationType type;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_PRIVATE_RESIZEDATA_H_
