#ifndef IMAGE_FILTERS_COMBINED_FILTER_SETTINGS_H_
#define IMAGE_FILTERS_COMBINED_FILTER_SETTINGS_H_

#include <QObject>
#include <QGenericMatrix>
#include <QTransform>
#include <QOpenGLTexture>

#include "image_filters/imagefilters_api.h"
#include "image_filters/interpolationtype.h"

namespace image_filters {

/*! \brief This structure holds information for combined filter.
 */
struct IMAGE_FILTERS_API CombinedFilterSettings {
    Q_GADGET

 public:
    CombinedFilterSettings()
        : interpolationType(InterpolationType::Linear)
        , pixelFormat(QOpenGLTexture::RGB) {}

    /*! \brief Illumination correction coefficients. */
    QGenericMatrix<1, 6, float> illuminationCoefficients;

    /*! \brief Keystone correction coefficients. */
    QTransform keystoneCorrectionTransformation;

    /*! \brief Image size after keystone correction. */
    QSize keystoneCorrectedSize;

    /*! \brief Interpolation type. */
    InterpolationType interpolationType;

    /*! \brief Color correction coefficients for lamp on mode. */
    QGenericMatrix<3, 8, float> colorCorrectionLampOnCoefficients;

    /*! \brief Color correction coefficients for lamp off mode. */
    QGenericMatrix<3, 8, float> colorCorrectionLampOffCoefficients;

    /*! \brief Input source pixel format.
     */
    QOpenGLTexture::PixelFormat pixelFormat;
};

}  // namespace image_filters

#endif // IMAGE_FILTERS_COMBINED_FILTER_SETTINGS_H_
