/*! \file interpolationtype.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_INTERPOLATIONTYPE_H_
#define IMAGE_FILTERS_INTERPOLATIONTYPE_H_

#include "image_filters/imagefilters_api.h"

namespace image_filters {

/*!
 * \brief This enumeration defines possible interpolation options.
 */
enum InterpolationType {
  /*! \brief Interpolate pixel to nearest value.
    */
  Nearest = 1,
  /*! \brief Interpolate pixel to using linear interpolation.
    */
  Linear = 2
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_INTERPOLATIONTYPE_H_
