/*! \file mirrortype.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_MIRRORTYPE_H_
#define IMAGE_FILTERS_MIRRORTYPE_H_

#include "image_filters/imagefilters_api.h"

namespace image_filters {

/*!
 * \brief This enumeration defines possible mirroring options.
 */
enum MirrorType {
  /*! \brief No mirroring.
   */
  None,
  /*! \brief Mirror about horizontal axis.
    */
  Horizontal,
  /*! \brief Mirror about vertical axis.
    */
  Vertical,
  /*! \brief Mirror about both axes.
    */
  Both
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_MIRRORTYPE_H_
