/*! \file imagefilterexception.cpp
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include "image_filters/imagefilterexception.h"

namespace image_filters {

/*****************************************************************************/

ImageFilterException* ImageFilterException::clone() const {
    return new ImageFilterException(*this);
}

/*****************************************************************************/

ImageFilterException::ImageFilterException(const QString& filterName,
                              const char* errorInfo)
    : m_errorInfo(errorInfo)
    , m_filterName(filterName)
{}

/*****************************************************************************/

QString ImageFilterException::errorInfo() const {
    return m_errorInfo;
}

/*****************************************************************************/

QString ImageFilterException::filterName() const {
    return m_filterName;
}

/*****************************************************************************/

void ImageFilterException::raise() const {
    throw *this;
}

}  // namespace image_filters
