/*! \file imagefilters_api.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_IMAGEFILTERS_API_H_
#define IMAGE_FILTERS_IMAGEFILTERS_API_H_

#include <QtCore/qglobal.h>

#if defined(IMAGE_FILTERS_LIBRARY)
#define IMAGE_FILTERS_API Q_DECL_EXPORT
#else
#define IMAGE_FILTERS_API Q_DECL_IMPORT
#endif

#endif  // IMAGE_FILTERS_IMAGEFILTERS_API_H_
