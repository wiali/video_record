/*! \file imagefilterexception.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_IMAGEFILTEREXCEPTION_H_
#define IMAGE_FILTERS_IMAGEFILTEREXCEPTION_H_

#include <QException>
#include <QObject>

#include "image_filters/imagefilters_api.h"

namespace image_filters {

/*! \brief This exception is thrown then update operation failed.
 */
class IMAGE_FILTERS_API ImageFilterException : public QException {
 public:
  /*! \brief Constructor
   *  \param errorInfo Error information.
   *  \param filterName Name of the filter raising the exception.
   */
  explicit ImageFilterException(const QString& filterName, const char* errorInfo);

  /*! \brief Returns error information.
   */
  inline QString errorInfo() const;

  /*! \brief Returns filter name.
   */
  inline QString filterName() const;

  /*! \brief Raises this exception.
   */
  virtual void raise() const override;

  /*! \brief Returns cloned exception.
   */
  virtual ImageFilterException* clone() const override;

 protected:
  /*! \brief Error information.
   */
  QString m_errorInfo;

  /*! \brief Error information.
   */
  QString m_filterName;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_IMAGEFILTEREXCEPTION_H_
