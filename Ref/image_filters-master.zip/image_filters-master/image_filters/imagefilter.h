/*! \file imagefilter.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_IMAGEFILTER_H_
#define IMAGE_FILTERS_IMAGEFILTER_H_

#include <QGenericMatrix>
#include <QObject>
#include <QScopedPointer>
#include <QOpenGLFramebufferObject>
#include <QFlags>

#include <memory>

#include "image_filters/imagefilters_api.h"
#include "image_filters/interpolationtype.h"
#include "image_filters/mirrortype.h"
#include "image_filters/sourceimage.h"
#include "image_filters/combinedfiltersettings.h"

namespace image_filters {

// Forward declarations
class ImageFilterPrivate;
struct KeystoneCorrectionData;
struct SharpenData;
struct IlluminationCorrectionData;
struct ResizeData;
struct ColorCorrectionData;
struct CombinedFilterData;

/*!
 * \brief The ImageFilter class wraps various image filters from providers like OpenCV or Intel IPP.
 */
class IMAGE_FILTERS_API ImageFilter : public QObject {
  Q_OBJECT
  Q_DECLARE_PRIVATE(ImageFilter)
  Q_PLUGIN_METADATA(IID "fortis.image_filters.imagefilter" FILE "../package.json")

  QScopedPointer<ImageFilterPrivate> const d_ptr;

 public:
  /*! \brief Declares possible filter actions.
   */
  enum CombinedFilter {
      /*! \brief No filters will be executed. */
      None                    = 0x0,
      /*! \brief Auto white balance will be performed. */
      AutoWhiteBalance        = 0x1,
      /*! \brief Illumination correction will be performed. */
      IlluminationCorrection  = 0x2,
      /*! \brief Color correction will be performed. */
      ColorCorrection         = 0x4,
      /*! \brief Keystone correction will be performed. */
      KeystoneCorrection      = 0x8,
      /*! \brief Sharpen will be performed. */
      Sharpen                 = 0x10,
      /*! \brief Mirroring will be performed. */
      Mirror                  = 0x20
  };

  Q_DECLARE_FLAGS(CombinedFilters, CombinedFilter)
  Q_FLAG(CombinedFilters)

  /*! \brief Mode represent the possible scenarios that have calibration data available for color-correction.
   */
  enum ColorCorrectionMode
  {
      /*! \brief This mode expects a completely white window projected over the entire Mat.
       *  \details This forces the projector to go to maximum nominal brightness.
       */
      LampOn,

      /*! \brief This mode expects the projector to be off.
       *  \details Projector off is equivalent to having a completely black window projected over the entire Mat.
       *           This forces the projector to go to minimum nominal brightness.
       */
      LampOff
  };

  Q_ENUM(ColorCorrectionMode)

  /*!
   * \brief Default ImageFilter constructor.
   * \param parent Pointer to parent object.
   */
  explicit ImageFilter(QObject* parent = nullptr);

  /*!
    * \brief ImageFilter destructor.
    */
  virtual ~ImageFilter();

  /*!
   * \brief Performs auto white balance using parallelized execution on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void autoWhiteBalance(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs illumination correction using parallelized algorithm on provided source image
   * \details with pre-calculated illumination map.
   * \details Optionally caller can also request to perform auto white balance algorithm in same
   * \details pass to achieve better performance.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \details This function will calculate pixel value map for each channel and each pixel based on
   * the following equation:
   * \details * i - illuminationCoefficient parameter
   * \details * (x,y) - pixel coordinate
   * \details * i - input pixel value for channel x
   * \details * o - input pixel value for channel x
   * \details v<sub>x</sub> = i[0] * x^2 * y + i[1] * x * y + i[2] * x^2 + i[3] * x + i[4] * y +
   * i[5]
   * \details o<sub>x</sub> = i<sub>x</sub> * v<sub>x</sub>
   * \details o<sub>x</sub> = o<sub>x</sub> > 255 ? 255 : o<sub>x</sub>
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param illuminationCorrectionData Pointer to illumination correction data structure obtained
   * using illuminationCorrectionInit.
   * \param performAutoWhiteBalance Flag indicating if auto white balance should be performed as
   * well.
   * \sa illuminationCorrectionInit
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void illuminationCorrection(
      const SourceImage& sourceImage, uchar* outputData,
      const std::shared_ptr<IlluminationCorrectionData>& illuminationCorrectionData,
      bool performAutoWhiteBalance = false);

  /*!
   * \brief Initializes internal data for illumination correction algorithm.
   * \param imageSize Size of the image
   * \param illuminationCoefficients Illumination correction coefficients.
   * \return Pointer to illumination correction data.
   * \sa illuminationCorrection
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<IlluminationCorrectionData> illuminationCorrectionInit(
      const QSize& imageSize, QGenericMatrix<1, 6, float> illuminationCoefficients);

  /*!
   * \brief Initializes internal data for keystone correction algorithm.
   * \param sourceImage Reference to source image data
   * \param transformation Homography data.
   * \param destinationRect Destination image rectangle.
   * \param type Interpolation type.
   * \return Pointer to keystone correction data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionInit(
      const SourceImage& sourceImage, QTransform transformation, QRect destinationRect = QRect(),
      InterpolationType type = InterpolationType::Linear);

  /*!
   * \brief Performs keystone correction using Intel IPP algorithm on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have pixel layout as input image data but size will depend on
   * \details destination rectangle size.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param keystoneCorrectionData Pointer to keystone correction algorithm data obtained using
   * keystoneCorrectionInit.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void keystoneCorrection(const SourceImage& sourceImage, uchar* outputData,
                          std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionData);

  /*!
   * \brief Performs sharpening using Intel IPP algorithm with 3x3 kernel on provided source image.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param sharpenData Pointer to sharpen algorithm data obtained using sharpenInit.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void sharpen(const SourceImage& sourceImage, uchar* outputData,
               std::shared_ptr<SharpenData> sharpenData);

  /*!
   * \brief Initializes internal data for sharpen algorithm.
   * \param sourceImage Reference to source image data.
   * \return Pointer to sharpen data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<SharpenData> sharpenInit(const SourceImage& sourceImage);

  /*!
   * \brief Crops the source image to rectangle provided as parameter.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * memory segment.
   * \details Output data will have pixel layout as input image data but size will depend on
   * destination rectangle size.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \param destinationRect Cropping area.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void crop(const SourceImage& sourceImage, uchar* outputData, QRect destinationRect);

  /*!
   * \brief Initializes internal data for resize algorithm.
   * \param sourceImage sourceImage Reference to source image data.
   * \param destinationRect Destination image rectangle.
   * \param type Interpolation type.
   * \return Pointer to resize data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<ResizeData> resizeInit(const SourceImage& sourceImage, QRect destinationRect,
                                         InterpolationType type = InterpolationType::Linear);

  /*!
   * \brief Resizes the source image to rectangle provided as parameter.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have pixel layout as input image data but size will depend on
   * \details destination rectangle size.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \param data Pointer to resize data obtained by usign method resizeInit.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void resize(const SourceImage& sourceImage, uchar* outputData, std::shared_ptr<ResizeData> data);

  /*!
   * \brief Copies source image to destination position provided as parameter.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data.
   * \param destinationImage Reference to destination image data.
   * \param destination Target point.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void paste(const SourceImage& sourceImage, const SourceImage& destinationImage,
             QSize destination);

  /*!
   * \brief Converts image color space from BGR to RGB layout.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size as input image data.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void convertBGRtoRGB(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Expands color space from RGB to RGBA layout.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have extra channel per each pixel compared to input image data.
   * \param sourceImage Reference to source image data.
   * \param outputData Pointer to output image data.
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void convertRGBtoRGBA(const SourceImage& sourceImage, uchar* outputData);

  /*!
   * \brief Performs color correction using parallelized algorithm on provided source image with
   * \details pre-calculated color map.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \details This function will calculate pixel value map for each channel and each pixel based on
   * \details the following equation:
   * \details * c<sub>x</sub> - colorCoefficients parameter for channel x
   * \details * (x,y) - pixel coordinate
   * \details * i<sub>x</sub> - input pixel value for channel x
   * \details * o<sub>x</sub> - input pixel value for channel x
   * \details v<sub>x</sub> = c<sub>x</sub>[0] * x^3 + c<sub>x</sub>[1] * y^3 + c<sub>x</sub>[2] *
   * \details x^2 * y + c<sub>x</sub>[3] * x * y ^2 + c<sub>x</sub>[4] * x * y + c<sub>x</sub>[5] *
   * \details x + c<sub>x</sub>[6] * y + c<sub>x</sub>[7]
   * \details v<sub>x</sub> = v<sub>x</sub> > 0 ? 1 / v<sub>x</sub> : 255
   * \details o<sub>x</sub> = i<sub>x</sub> * v<sub>x</sub>
   * \details o<sub>x</sub> = o<sub>x</sub> > 255 ? 255 : o<sub>x</sub>
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param colorCorrectionData Pointer to illumination correction data structure obtained using
   * colorCorrectionInit.
   * \sa colorCorrectionInit
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  void colorCorrection(const SourceImage& sourceImage, uchar* outputData,
                       const std::shared_ptr<ColorCorrectionData>& colorCorrectionData);

  /*!
   * \brief Initializes internal data for color correction algorithm.
   * \param imageSize Size of the image
   * \param colorCoefficients Color correction coefficients.
   * \return Pointer to color correction data.
   * \sa colorCorrection
   * \exception ImageFilterException Thrown when filter encounters an error.
   */
  std::shared_ptr<ColorCorrectionData> colorCorrectionInit(
      const QSize& imageSize, QGenericMatrix<3, 8, float> colorCoefficients);

  /*!
   * \brief Performs image mirroring based on given axis.
   * \details Caller of this method is responsible for allocating outputData pointer to big enough
   * \details memory segment.
   * \details Output data will have same size and follow same pixel layout as input image data.
   * \param sourceImage Reference to source image data
   * \param outputData Pointer to output image data.
   * \param type Type of mirroring to perform.
   */
  void mirror(const SourceImage& sourceImage, uchar* outputData, const MirrorType type);

  /*!
   * \brief Initializes internal data for combined filters.
   * \details Valid OpenGL context *MUST* be available at the time of calling this method.
   * \details Valid OpenGL context *MUST* be available at the time of destruction of return value.
   * \param imageSize Size of the image
   * \param settings Pointer to combined filter settings.
   */
  std::shared_ptr<CombinedFilterData> combinedInit(const QSize &imageSize, const CombinedFilterSettings& settings);

  /*!
   * \brief Performs all filters flagged for execution
   * \details Valid OpenGL context *MUST* be available at the time of calling this method.
   * \param sourceImage Reference to source image data
   * \param frameBuffer Pointer to output frame buffer.
   * \param data Pointer to combined filter data structure obtained by calling combinedInit.
   * \param filters Declares which filters should be executed.
   * \param colorCorrectionMode Indicates which set of color correction coefficients should be used.
   * \param mirror Indicated which mirroring should be used.
   */
  void combined(const SourceImage& sourceImage, QOpenGLFramebufferObject *frameBuffer,
                const std::shared_ptr<CombinedFilterData>& data,
                ImageFilter::CombinedFilters filters = ImageFilter::CombinedFilter::None,
                ImageFilter::ColorCorrectionMode colorCorrectionMode = ImageFilter::ColorCorrectionMode::LampOff,
                MirrorType mirror = MirrorType::None);
};

}  // namespace image_filters

Q_DECLARE_OPERATORS_FOR_FLAGS(image_filters::ImageFilter::CombinedFilters)
Q_DECLARE_METATYPE(image_filters::ImageFilter::ColorCorrectionMode)

#endif  // IMAGE_FILTERS_IMAGEFILTER_H_
