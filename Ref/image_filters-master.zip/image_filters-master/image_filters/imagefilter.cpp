/*! \file imagefilter.cpp
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#include "image_filters/imagefilter.h"

#include <opencv2/core.hpp>
#include <opencv2/imgproc.hpp>

#include "image_filters/imagefilterexception.h"
#include "image_filters/private/imagefilter_p.h"

namespace image_filters {

/*****************************************************************************/

ImageFilter::ImageFilter(QObject* parent)
    : QObject(parent), d_ptr(new ImageFilterPrivate) {}

/*****************************************************************************/

ImageFilter::~ImageFilter() {}

/*****************************************************************************/

void ImageFilter::autoWhiteBalance(const SourceImage& sourceImage, uchar* outputData) {
  Q_D(ImageFilter);
  d->autoWhiteBalance(sourceImage, outputData);
}

/*****************************************************************************/

std::shared_ptr<IlluminationCorrectionData> ImageFilter::illuminationCorrectionInit(
    const QSize& imageSize, QGenericMatrix<1, 6, float> illuminationCoefficients) {
  Q_D(ImageFilter);
  return d->illuminationCorrectionInit(imageSize, illuminationCoefficients);
}

/*****************************************************************************/

void ImageFilter::illuminationCorrection(const SourceImage& sourceImage, uchar* outputData,
                                         const std::shared_ptr<IlluminationCorrectionData>& data,
                                         bool performAutoWhiteBalance) {
  Q_D(ImageFilter);
  d->illuminationCorrection(sourceImage, outputData, data, performAutoWhiteBalance);
}

/*****************************************************************************/

std::shared_ptr<KeystoneCorrectionData> ImageFilter::keystoneCorrectionInit(
    const SourceImage& sourceImage, QTransform transformation, QRect destinationRect,
    InterpolationType type) {
  Q_D(ImageFilter);
  return d->keystoneCorrectionInit(sourceImage, transformation, destinationRect, type);
}

/*****************************************************************************/

void ImageFilter::keystoneCorrection(
    const SourceImage& sourceImage, uchar* outputData,
    std::shared_ptr<KeystoneCorrectionData> keystoneCorrectionData) {
  Q_D(ImageFilter);
  d->keystoneCorrection(sourceImage, outputData, keystoneCorrectionData);
}

/*****************************************************************************/

std::shared_ptr<SharpenData> ImageFilter::sharpenInit(const SourceImage& sourceImage) {
  Q_D(ImageFilter);
  return d->sharpenInit(sourceImage);
}

/*****************************************************************************/

void ImageFilter::sharpen(const SourceImage& sourceImage, uchar* outputData,
                          std::shared_ptr<SharpenData> sharpenData) {
  Q_D(ImageFilter);
  d->sharpen(sourceImage, outputData, sharpenData);
}

/*****************************************************************************/

void ImageFilter::crop(const SourceImage& sourceImage, uchar* outputData, QRect destinationRect) {
  Q_D(ImageFilter);
  d->crop(sourceImage, outputData, destinationRect);
}

/*****************************************************************************/

std::shared_ptr<ResizeData> ImageFilter::resizeInit(const SourceImage& sourceImage,
                                                    QRect destinationRect, InterpolationType type) {
  Q_D(ImageFilter);
  return d->resizeInit(sourceImage, destinationRect, type);
}

/*****************************************************************************/

void ImageFilter::resize(const SourceImage& sourceImage, uchar* outputData,
                         std::shared_ptr<ResizeData> data) {
  Q_D(ImageFilter);
  return d->resize(sourceImage, outputData, data);
}

/*****************************************************************************/

void ImageFilter::convertBGRtoRGB(const SourceImage& sourceImage, uchar* outputData) {
  Q_D(ImageFilter);
  return d->convertBGRtoRGB(sourceImage, outputData);
}

/*****************************************************************************/

void ImageFilter::paste(const SourceImage& sourceImage, const SourceImage& destinationImage,
                        QSize point) {
  Q_D(ImageFilter);
  return d->paste(sourceImage, destinationImage, point);
}

/*****************************************************************************/

void ImageFilter::convertRGBtoRGBA(const SourceImage& sourceImage, uchar* outputData) {
  Q_D(ImageFilter);
  return d->convertRGBtoRGBA(sourceImage, outputData);
}

/*****************************************************************************/

void ImageFilter::colorCorrection(const SourceImage& sourceImage, uchar* outputData,
                                  const std::shared_ptr<ColorCorrectionData>& colorCorrectionData) {
  Q_D(ImageFilter);
  d->colorCorrection(sourceImage, outputData, colorCorrectionData);
}

/*****************************************************************************/

std::shared_ptr<ColorCorrectionData> ImageFilter::colorCorrectionInit(
    const QSize& imageSize, QGenericMatrix<3, 8, float> colorCoefficients) {
  Q_D(ImageFilter);
  return d->colorCorrectionInit(imageSize, colorCoefficients);
}

/*****************************************************************************/

void ImageFilter::mirror(const SourceImage& sourceImage, uchar* outputData, const MirrorType type) {
  Q_D(ImageFilter);
  return d->mirror(sourceImage, outputData, type);
}

/*****************************************************************************/

std::shared_ptr<CombinedFilterData> ImageFilter::combinedInit(const QSize& imageSize, const CombinedFilterSettings& settings) {
    Q_D(ImageFilter);
    return d->combinedInit(imageSize, settings);
}

/*****************************************************************************/

void ImageFilter::combined(const SourceImage& sourceImage,
                           QOpenGLFramebufferObject *frameBuffer,
                           const std::shared_ptr<CombinedFilterData> &data,
                           CombinedFilters filters,
                           ImageFilter::ColorCorrectionMode colorCorrectionMode, MirrorType mirror) {
  Q_D(ImageFilter);
  return d->combined(sourceImage, frameBuffer, data, filters, colorCorrectionMode, mirror);
}

}  // namespace image_filters
