/*! \file sourceimage.h
 *  \date April, 2017
 *  \copyright © Copyright 2017 Hewlett-Packard Development Company, L.P.
 */

#ifndef IMAGE_FILTERS_SOURCEIMAGE_H_
#define IMAGE_FILTERS_SOURCEIMAGE_H_

#include <QImage>
#include <QObject>
#include <QSize>

#include "image_filters/imagefilters_api.h"

namespace image_filters {

/*!
 * \brief The SourceImage struct wraps image information into single structure.
 * \details This structure allows accessing image data with stride equal to channel count * width.
 */
struct IMAGE_FILTERS_API SourceImage {
  Q_GADGET

  Q_PROPERTY(QSize size MEMBER size)
  Q_PROPERTY(QImage::Format format MEMBER format)
  Q_PROPERTY(uchar *data MEMBER data)

 public:
  /*!
   * \brief Size of the image.
   */
  QSize size;

  /*!
   * \brief Image pixel format.
   */
  QImage::Format format;

  /*!
   * \brief Pointer to raw image data.
   */
  uchar *data;
};

}  // namespace image_filters

#endif  // IMAGE_FILTERS_SOURCEIMAGE_H_
